"""Document import for Smart Notes: validation, private storage and text extraction.

Safety rules:
  * Only .txt, .md, .pdf and .docx are accepted, checked by extension AND by content.
  * The original file is kept under instance/uploads/<user_id>/<random name> (outside static/).
  * Nothing is ever executed. DOCX is read with python-docx (macros live in .docm/vbaProject.bin
    and are ignored); PDFs are read with pypdf (no JavaScript or embedded files are run).
  * Scanned PDFs have no text layer. OCR is NOT implemented, so they yield no text.
"""
import io
import os
import secrets
import zipfile

MAX_UPLOAD = 5 * 1024 * 1024          # bytes
MAX_UNZIPPED = 40 * 1024 * 1024       # guards against zip bombs in .docx
MAX_PDF_PAGES = 100
ALLOWED = {"txt": "Plain text", "md": "Markdown", "pdf": "PDF", "docx": "Word (.docx)"}

try:
    from pypdf import PdfReader
except ImportError:  # pragma: no cover - depends on the installation
    PdfReader = None
try:
    import docx as python_docx
except ImportError:  # pragma: no cover
    python_docx = None


class DocumentError(ValueError):
    """A problem the student can fix; the message is safe to display."""


def upload_dir(instance_path, user_id):
    path = os.path.join(instance_path, "uploads", str(int(user_id)))
    os.makedirs(path, exist_ok=True)
    return path


def detect_kind(filename, data):
    """Return the document kind or raise DocumentError. Extension and content must agree."""
    ext = os.path.splitext(filename or "")[1].lower().lstrip(".")
    if ext not in ALLOWED:
        raise DocumentError("Unsupported file type. Upload a .txt, .md, .pdf or .docx file.")
    if not data:
        raise DocumentError("That file is empty.")
    if len(data) > MAX_UPLOAD:
        raise DocumentError(f"Files are limited to {MAX_UPLOAD // (1024 * 1024)} MB.")
    if ext == "pdf" and not data.lstrip()[:5] == b"%PDF-":
        raise DocumentError("This file is named .pdf but is not a PDF.")
    if ext == "docx":
        if not zipfile.is_zipfile(io.BytesIO(data)):
            raise DocumentError("This file is named .docx but is not a Word document.")
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            if "word/document.xml" not in names:
                raise DocumentError("This file is not a valid .docx document.")
            if sum(i.file_size for i in z.infolist()) > MAX_UNZIPPED:
                raise DocumentError("This document expands to an unsafe size and was rejected.")
    if ext in ("txt", "md") and b"\x00" in data:
        raise DocumentError("This looks like a binary file, not text.")
    return ext


def save_original(instance_path, user_id, kind, data):
    """Write the bytes under a random name; the student's filename is never used on disk."""
    stored = secrets.token_hex(16) + "." + kind
    with open(os.path.join(upload_dir(instance_path, user_id), stored), "wb") as f:
        f.write(data)
    return stored


def extract_text(kind, data):
    """Return (text, warnings). Never raises for ordinary bad files: it reports a warning."""
    warnings = []
    try:
        if kind in ("txt", "md"):
            try:
                text = data.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = data.decode("latin-1")
                warnings.append("The file is not UTF-8; it was read as Latin-1, so check special characters.")
        elif kind == "pdf":
            if PdfReader is None:
                raise DocumentError("PDF import needs the 'pypdf' package (see requirements.txt).")
            reader = PdfReader(io.BytesIO(data))
            if reader.is_encrypted:
                raise DocumentError("This PDF is password-protected and cannot be read.")
            pages = reader.pages[:MAX_PDF_PAGES]
            if len(reader.pages) > MAX_PDF_PAGES:
                warnings.append(f"Only the first {MAX_PDF_PAGES} pages were read.")
            text = "\n\n".join((p.extract_text() or "").strip() for p in pages)
            if not text.strip():
                warnings.append("No text could be extracted. This PDF may be scanned images; "
                                "OCR is not implemented, so scanned PDFs cannot be imported.")
        elif kind == "docx":
            if python_docx is None:
                raise DocumentError("DOCX import needs the 'python-docx' package (see requirements.txt).")
            document = python_docx.Document(io.BytesIO(data))
            parts = []
            for p in document.paragraphs:
                style = (p.style.name if p.style is not None else "") or ""
                line = p.text.strip()
                if not line:
                    parts.append("")
                elif style.startswith("Heading"):
                    level = style.split()[-1]
                    parts.append("#" * (int(level) if level.isdigit() else 1) + " " + line)
                elif "List" in style:
                    parts.append("- " + line)
                else:
                    parts.append(line)
            for table in document.tables:
                for row in table.rows:
                    parts.append(" | ".join(c.text.strip() for c in row.cells))
            text = "\n".join(parts)
            if not text.strip():
                warnings.append("No text was found in this document.")
        else:
            raise DocumentError("Unsupported file type.")
    except DocumentError:
        raise
    except Exception:  # malformed files raise many library-specific errors
        raise DocumentError("This file could not be read. It may be damaged or in an unsupported format.")
    text = text.replace("\r\n", "\n").replace("\x00", "")
    return text.strip(), warnings
