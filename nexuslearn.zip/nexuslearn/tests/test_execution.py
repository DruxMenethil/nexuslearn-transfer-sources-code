import glob
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
import execution  # noqa: E402
from test_tasks import Client  # noqa: E402

NODE_OK = execution.node_info()[1] is not None
GCC_OK = execution.find_compiler("c") is not None
GXX_OK = execution.find_compiler("cpp") is not None
SECRET = os.path.join(nexus.app.instance_path, "secret_key")
UNSAFE = {execution.UNSANDBOXED_ENV: "1"}   # lets C/C++ run for tests here (no bubblewrap in this environment)


class ArgvTests(unittest.TestCase):
    """bubblewrap itself is not installed where these tests were written, so its command line is
    checked as data: the isolation flags must be present and the app directory must not be mounted."""

    def test_bubblewrap_command_line(self):
        argv = execution.bwrap_argv("/usr/bin/bwrap", "/tmp/run1", ["./main"])
        for flag in ("--unshare-all", "--die-with-parent", "--new-session", "--clearenv"):
            self.assertIn(flag, argv)
        self.assertEqual(argv[argv.index("--bind") + 1:argv.index("--bind") + 3], ["/tmp/run1", "/work"])
        self.assertEqual(argv.count("--bind"), 1)                       # only the run directory is writable
        self.assertNotIn("--share-net", argv)
        self.assertNotIn(execution.HERE, " ".join(argv))                # the app directory is never visible
        self.assertEqual(argv[-1], "./main")
        i = argv.index("--ro-bind")
        self.assertEqual(argv[i + 1:i + 3], ["/usr", "/usr"])


class CapabilityTests(unittest.TestCase):
    def test_report_has_a_reason_whenever_unavailable(self):
        for lang, cap in execution.capabilities().items():
            self.assertIn(lang, ("javascript", "c", "cpp"))
            self.assertTrue(cap["available"] or cap["reason"], lang)

    def test_native_code_is_refused_without_an_os_sandbox(self):
        with mock.patch("execution.bwrap_path", return_value=None), mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop(execution.UNSANDBOXED_ENV, None)
            for lang in ("c", "cpp"):
                cap = execution.capabilities()[lang]
                self.assertFalse(cap["available"])
                self.assertIn("bubblewrap", cap["reason"])
                result = execution.run_native(lang, "int main(void){return 0;}", "")
                self.assertEqual(result["status"], "unavailable")

    def test_opt_in_switch_enables_native_with_honest_label(self):
        if not GCC_OK:
            self.skipTest("no C compiler")
        with mock.patch("execution.bwrap_path", return_value=None), mock.patch.dict(os.environ, UNSAFE):
            cap = execution.capabilities()["c"]
            self.assertTrue(cap["available"])
            self.assertIn("none", cap["sandbox"])

    def test_missing_tools_are_reported_not_faked(self):
        with mock.patch("execution.shutil.which", return_value=None), mock.patch("execution.bwrap_path", return_value=None):
            execution.node_info.cache_clear()
            try:
                caps = execution.capabilities()
            finally:
                execution.node_info.cache_clear()
        self.assertFalse(caps["javascript"]["available"])
        self.assertIn("Node.js was not found", caps["javascript"]["reason"])
        self.assertIn("No C compiler", caps["c"]["reason"])
        self.assertIn("No C++ compiler", caps["cpp"]["reason"])


@unittest.skipUnless(NODE_OK, "Node.js with the permission model is not available")
class JavaScriptTests(unittest.TestCase):
    def setUp(self):
        self.old = execution.RUN_TIMEOUT
        execution.RUN_TIMEOUT = 2

    def tearDown(self):
        execution.RUN_TIMEOUT = self.old

    def js(self, code, stdin=""):
        return execution.run_javascript(code, stdin)

    def test_output_input_and_errors(self):
        self.assertEqual(self.js("console.log('hi', 1 + 2)")["stdout"], "hi 3\n")
        self.assertEqual(self.js("console.log(require('fs').readFileSync(0, 'utf8').trim().toUpperCase())", "ada\n")["stdout"], "ADA\n")
        r = self.js("console.log('before');\nthrow new Error('boom');")
        self.assertEqual((r["status"], r["stdout"]), ("error", "before\n"))
        self.assertIn("Error: boom", r["stderr"])
        self.assertIn("main.js:2", r["stderr"])
        self.assertNotIn(tempfile.gettempdir(), r["stderr"])           # the run directory is not leaked
        r = self.js("function (")
        self.assertEqual(r["status"], "error")
        self.assertIn("SyntaxError", r["stderr"])

    def test_limits(self):
        self.assertEqual(self.js("while (true) {}")["status"], "timeout")
        r = self.js("while (true) console.log('x'.repeat(1000))")
        self.assertEqual(r["status"], "output_limit")
        self.assertLessEqual(len(r["stdout"]), execution.MAX_OUTPUT)
        self.assertEqual(self.js("const a = []; while (true) a.push(new Array(1e6).fill(1));")["status"], "error")
        self.assertEqual(self.js("console.log(Buffer.alloc(2e9).length)")["status"], "error")

    def test_cannot_touch_the_app_or_the_machine(self):
        attacks = {
            "secret key": f"console.log(require('fs').readFileSync({SECRET!r}, 'utf8'))",
            "etc/passwd": "console.log(require('fs').readFileSync('/etc/passwd', 'utf8'))",
            "list app dir": f"console.log(require('fs').readdirSync({execution.HERE!r}))",
            "write outside": "require('fs').writeFileSync('/tmp/nl_js_escape.txt', 'x')",
            "child process": "require('child_process').execSync('echo hi')",
            "worker": "new (require('worker_threads').Worker)('1', {eval: true})",
            "network module": "require('net').connect(80, '1.1.1.1')",
            "http": "require('node:https').get('https://example.com')",
            "fetch": "fetch('http://1.1.1.1').then(() => console.log('FETCHED'))",
        }
        for name, code in attacks.items():
            r = self.js(code)
            self.assertEqual(r["status"], "error", name)
            self.assertNotIn("FETCHED", r["stdout"], name)
        self.assertFalse(os.path.exists("/tmp/nl_js_escape.txt"))

    def test_files_in_the_run_directory_work_and_environment_is_empty(self):
        self.assertEqual(self.js("const fs = require('fs'); fs.writeFileSync('a.txt', 'ok'); console.log(fs.readFileSync('a.txt', 'utf8'))")["stdout"], "ok\n")
        with mock.patch.dict(os.environ, {"SECRET_KEY": "from-the-server-env"}):
            r = self.js("console.log(Object.keys(process.env).sort().join(','), process.env.SECRET_KEY)")
        self.assertNotIn("from-the-server-env", r["stdout"])
        self.assertEqual(r["stdout"].strip(), "HOME,LANG,PATH undefined")

    def test_run_directories_are_cleaned_up(self):
        pattern = os.path.join(tempfile.gettempdir(), "nexuslearn_js_*")
        before = len(glob.glob(pattern))
        self.js("console.log(1)"); self.js("while (true) {}")
        self.assertEqual(len(glob.glob(pattern)), before)


@unittest.skipUnless(GCC_OK and GXX_OK, "C/C++ compilers are not available")
class NativeTests(unittest.TestCase):
    def setUp(self):
        self.old = execution.RUN_TIMEOUT
        execution.RUN_TIMEOUT = 2
        patches = [mock.patch("execution.bwrap_path", return_value=None), mock.patch.dict(os.environ, UNSAFE)]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self):
        execution.RUN_TIMEOUT = self.old

    def c(self, code, stdin=""):
        return execution.run_native("c", code, stdin)

    def cpp(self, code, stdin=""):
        return execution.run_native("cpp", code, stdin)

    def test_hello_and_input(self):
        r = self.c('#include <stdio.h>\nint main(void){ printf("Hello C\\n"); return 0; }')
        self.assertEqual((r["status"], r["stdout"], r["exit_code"]), ("ok", "Hello C\n", 0))
        r = self.c('#include <stdio.h>\nint main(void){ int a, b; scanf("%d %d", &a, &b); printf("%d\\n", a + b); return 0; }', "20 22\n")
        self.assertEqual(r["stdout"], "42\n")
        r = self.cpp('#include <iostream>\n#include <string>\nint main(){ std::string n; std::getline(std::cin, n); std::cout << "Hi " << n << "\\n"; }', "Ada\n")
        self.assertEqual((r["status"], r["stdout"]), ("ok", "Hi Ada\n"))

    def test_compile_errors_are_real_and_nothing_runs(self):
        r = self.c('#include <stdio.h>\n\nint main(void)\n{\n    printf("hi")\n    return 0;\n}\n')
        self.assertEqual(r["status"], "compile_error")
        self.assertRegex(r["compile_output"], r"main\.c:\d+:\d+: error")
        self.assertEqual((r["stdout"], r["exit_code"] != 0), ("", True))
        r = self.cpp("int main(){ int x = ; }")
        self.assertEqual(r["status"], "compile_error")
        self.assertIn("main.cpp:1", r["compile_output"])
        self.assertNotIn(tempfile.gettempdir(), r["compile_output"])

    def test_warnings_are_shown_when_the_program_still_runs(self):
        r = self.c('#include <stdio.h>\nint main(void){ int unused; printf("ok\\n"); return 0; }')
        self.assertEqual(r["status"], "ok")
        self.assertIn("warning", r["compile_output"])

    def test_runtime_crashes_are_reported(self):
        r = self.c("int main(void){ int *p = 0; *p = 1; return 0; }")
        self.assertEqual((r["status"], r["signal"]), ("error", "SIGSEGV"))
        self.assertIn("Segmentation fault", r["stderr"])
        r = self.c("int main(void){ volatile int z = 0; return 5 / z; }")
        self.assertEqual(r["signal"], "SIGFPE")
        r = self.c("int main(void){ return 3; }")
        self.assertEqual((r["status"], r["exit_code"]), ("error", 3))

    def test_limits(self):
        self.assertEqual(self.c("int main(void){ for (;;) {} }")["status"], "timeout")
        r = self.c("#include <stdio.h>\nint main(void){ for (;;) putchar('x'); }")
        self.assertEqual(r["status"], "output_limit")
        self.assertLessEqual(len(r["stdout"]), execution.MAX_OUTPUT)
        r = self.c("#include <stdlib.h>\nint main(void){ return malloc(2000000000) == NULL; }")
        self.assertEqual(r["exit_code"], 1)                              # the allocation was refused

    def test_environment_is_empty_and_directories_cleaned(self):
        with mock.patch.dict(os.environ, {"SECRET_KEY": "from-the-server-env"}):
            r = self.c('#include <stdio.h>\n#include <stdlib.h>\nint main(void){ char *s = getenv("SECRET_KEY"); printf("%s\\n", s ? s : "none"); return 0; }')
        self.assertEqual(r["stdout"], "none\n")
        pattern = os.path.join(tempfile.gettempdir(), "nexuslearn_native_*")
        before = len(glob.glob(pattern))
        self.c("int main(void){ return 0; }"); self.c("int main(void){ for(;;){} }")
        self.assertEqual(len(glob.glob(pattern)), before)


class RouteTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(DATABASE=self.path, PRACTICE_DIR=self.practice, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.a = Client("alice")

    def tearDown(self):
        os.remove(self.path)

    def run_lang(self, lang, code="x", stdin=""):
        r = self.a.post(f"/codelab/run/{lang}", code=code, stdin=stdin)
        return r.status_code, r.get_json()

    @unittest.skipUnless(NODE_OK, "no node")
    def test_javascript_route(self):
        code, r = self.run_lang("javascript", "console.log(6 * 7)")
        self.assertEqual((code, r["status"], r["stdout"]), (200, "ok", "42\n"))

    @unittest.skipUnless(GCC_OK, "no gcc")
    def test_native_route_when_enabled(self):
        with mock.patch("execution.bwrap_path", return_value=None), mock.patch.dict(os.environ, UNSAFE):
            code, r = self.run_lang("c", '#include <stdio.h>\nint main(void){puts("routed");return 0;}')
        self.assertEqual((code, r["stdout"]), (200, "routed\n"))

    def test_unavailable_languages_return_a_clear_503_and_the_editor_still_works(self):
        with mock.patch("execution.bwrap_path", return_value=None), mock.patch.dict(os.environ, {}):
            os.environ.pop(execution.UNSANDBOXED_ENV, None)
            code, r = self.run_lang("c", "int main(void){return 0;}")
            page = self.a.get("/codelab").data.decode()
        self.assertEqual((code, r["status"]), (503, "unavailable"))
        self.assertIn("bubblewrap", r["error"])
        self.assertEqual(self.a.get("/codelab").status_code, 200)
        self.assertIn('"caps"', page.replace('"caps":', '"caps"'))

    def test_validation_login_and_csrf(self):
        for lang in ("javascript", "c", "cpp"):
            self.assertEqual(self.run_lang(lang, "   ")[0], 400)
            self.assertEqual(self.run_lang(lang, "x" * 50_001)[0], 400)
            anon = nexus.app.test_client()
            with anon.session_transaction() as s:
                s["csrf_token"] = "t"
            self.assertEqual(anon.post(f"/codelab/run/{lang}", data={"code": "x", "csrf_token": "t"}).status_code, 302)
            self.assertEqual(self.a.c.post(f"/codelab/run/{lang}", data={"code": "x", "csrf_token": "bad"}).status_code, 400)

    def test_projects_and_snippets_in_the_new_languages(self):
        for lang, fname in (("javascript", "main.js"), ("c", "main.c"), ("cpp", "main.cpp")):
            r = self.a.post("/projects/new", name=f"P-{lang}", language=lang)
            self.assertEqual(r.status_code, 302)
            page = self.a.get("/codelab?project=" + r.headers["Location"].rsplit("/", 1)[1]).data.decode()
            self.assertIn(fname, page)
            saved = self.a.post("/projects/from-codelab", name=f"S-{lang}", language=lang, files='{"%s": "x"}' % fname)
            self.assertEqual(saved.status_code, 201)
            self.a.post("/snippets/new", title=f"Snip {lang}", language=lang, code="x")
        self.assertIn("snippet=", self.a.get("/snippets").data.decode())


if __name__ == "__main__":
    unittest.main()
