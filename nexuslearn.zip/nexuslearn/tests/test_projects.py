import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
from test_tasks import Client  # noqa: E402


class Base(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        nexus.app.config.update(DATABASE=self.path, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.a, self.b = Client("alice"), Client("bobby")

    def tearDown(self):
        os.remove(self.path)

    def q(self, sql, *args):
        with nexus.app.app_context():
            return nexus.get_db().execute(sql, args).fetchall()

    def new_project(self, who=None, **kw):
        kw.setdefault("name", "Proj")
        kw.setdefault("language", "python")
        r = (who or self.a).post("/projects/new", **kw)
        return int(r.headers["Location"].rsplit("/", 1)[1]) if r.status_code == 302 else None

    def file_id(self, pid, name):
        return self.q("SELECT id FROM project_files WHERE project_id = ? AND filename = ?", pid, name)[0]["id"]


class ProjectTests(Base):
    def test_create_gets_starter_file(self):
        pid = self.new_project(name="Calc", language="python")
        self.assertEqual([r["filename"] for r in self.q("SELECT filename FROM project_files WHERE project_id = ?", pid)], ["main.py"])
        self.assertIn(b"Calc", self.a.get(f"/projects/{pid}").data)

    def test_html_project_gets_two_files(self):
        pid = self.new_project(language="html")
        names = {r["filename"] for r in self.q("SELECT filename FROM project_files WHERE project_id = ?", pid)}
        self.assertEqual(names, {"index.html", "style.css"})

    def test_validation(self):
        for bad in ({"name": ""}, {"name": "x" * 81}, {"language": "cobol"}, {"task_id": "abc"}, {"task_id": "9999"}):
            self.assertIsNone(self.new_project(**bad), bad)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM projects")[0]["n"], 0)

    def test_cannot_link_another_users_task(self):
        tid = self.b.add(title="Bobs task")
        self.assertIsNone(self.new_project(task_id=str(tid)))

    def test_task_link_shows_on_task_and_survives_task_delete(self):
        tid = self.a.add(title="Essay")
        pid = self.new_project(name="EssayCode", task_id=str(tid))
        self.assertIn(b"EssayCode", self.a.get(f"/tasks/{tid}").data)
        self.a.post(f"/tasks/{tid}/delete")
        self.assertIsNone(self.q("SELECT task_id FROM projects WHERE id = ?", pid)[0]["task_id"])

    def test_edit_and_rename(self):
        pid = self.new_project(name="Old")
        r = self.a.post(f"/projects/{pid}/edit", name="New", language="sql", description="d", task_id="")
        self.assertEqual(r.status_code, 302)
        row = self.q("SELECT name, language FROM projects WHERE id = ?", pid)[0]
        self.assertEqual((row["name"], row["language"]), ("New", "sql"))

    def test_list_search_and_filter(self):
        self.new_project(name="Alpha", language="python")
        self.new_project(name="Beta", language="sql")
        page = lambda qs: self.a.get("/projects?" + qs).data
        self.assertIn(b"Alpha", page("q=alph"))
        self.assertNotIn(b"Beta", page("q=alph"))
        self.assertNotIn(b"Alpha", page("language=sql"))
        self.assertNotIn(b"Alpha", page("q=%25"))

    def test_delete_cascades_files(self):
        pid = self.new_project()
        self.a.post(f"/projects/{pid}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM project_files")[0]["n"], 0)

    def test_dashboard_lists_recent_projects(self):
        self.new_project(name="DashProject")
        self.assertIn(b"DashProject", self.a.get("/dashboard").data)
        self.assertNotIn(b"DashProject", self.b.get("/dashboard").data)


class FileTests(Base):
    def test_add_rename_delete_file(self):
        pid = self.new_project()
        self.assertEqual(self.a.post(f"/projects/{pid}/files/new", filename="utils.py").status_code, 302)
        fid = self.file_id(pid, "utils.py")
        self.a.post(f"/projects/{pid}/files/{fid}/rename", filename="helpers.py")
        self.assertEqual(self.file_id(pid, "helpers.py"), fid)
        self.a.post(f"/projects/{pid}/files/{fid}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM project_files WHERE id = ?", fid)[0]["n"], 0)

    def test_bad_and_duplicate_filenames_rejected(self):
        pid = self.new_project()
        for name in ("../evil.py", "a/b.py", "run.exe", ".hidden.py", "", "x" * 61 + ".py", "MAIN.PY"):
            self.a.post(f"/projects/{pid}/files/new", filename=name)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM project_files WHERE project_id = ?", pid)[0]["n"], 1)

    def test_save_persists_across_logout_and_login(self):
        pid = self.new_project()
        fid = self.file_id(pid, "main.py")
        r = self.a.post(f"/projects/{pid}/files/{fid}/save", content="print('saved')\n")
        self.assertEqual(r.get_json()["status"], "saved")
        c2 = nexus.app.test_client()
        with c2.session_transaction() as s:
            s["csrf_token"] = "t"
        c2.post("/login", data={"username": "alice", "password": "password1", "csrf_token": "t"})
        page = c2.get(f"/codelab?project={pid}").data.decode()
        self.assertIn("print(\\u0027saved\\u0027)", page)

    def test_save_size_limit(self):
        pid = self.new_project()
        fid = self.file_id(pid, "main.py")
        r = self.a.post(f"/projects/{pid}/files/{fid}/save", content="x" * 100_001)
        self.assertEqual(r.status_code, 400)

    def test_from_codelab(self):
        r = self.a.post("/projects/from-codelab", name="FromLab", language="html",
                        files=json.dumps({"index.html": "<p>hi</p>", "style.css": "p{}"}))
        self.assertEqual(r.status_code, 201)
        pid = r.get_json()["id"]
        self.assertEqual(self.q("SELECT content FROM project_files WHERE project_id = ? AND filename = 'index.html'", pid)[0]["content"], "<p>hi</p>")
        for bad in (dict(name="", language="python", files='{"a.py":"x"}'),
                    dict(name="x", language="c", files='{"a.c":"x"}'),
                    dict(name="x", language="python", files="not json"),
                    dict(name="x", language="python", files='{"../a.py":"x"}'),
                    dict(name="x", language="python", files="{}")):
            self.assertEqual(self.a.post("/projects/from-codelab", **bad).status_code, 400, bad)

    def test_codelab_opens_project_and_snippet_only_for_owner(self):
        pid = self.new_project(name="Mine")
        page = self.a.get(f"/codelab?project={pid}")
        self.assertEqual(page.status_code, 200)
        self.assertIn(b"Mine", page.data)
        self.assertEqual(self.b.get(f"/codelab?project={pid}").status_code, 404)


class AuthorizationTests(Base):
    def test_other_user_gets_404_everywhere(self):
        pid = self.new_project(name="Secret")
        fid = self.file_id(pid, "main.py")
        for method, url in (("get", f"/projects/{pid}"), ("get", f"/projects/{pid}/edit"),
                            ("post", f"/projects/{pid}/edit"), ("post", f"/projects/{pid}/delete"),
                            ("post", f"/projects/{pid}/files/new"),
                            ("post", f"/projects/{pid}/files/{fid}/save"),
                            ("post", f"/projects/{pid}/files/{fid}/rename"),
                            ("post", f"/projects/{pid}/files/{fid}/delete")):
            r = getattr(self.b, method)(url) if method == "get" else self.b.post(url, name="x", language="python", filename="z.py", content="HACK")
            self.assertEqual(r.status_code, 404, url)
        self.assertNotIn(b"Secret", self.b.get("/projects").data)
        self.assertEqual(self.q("SELECT content FROM project_files WHERE id = ?", fid)[0]["content"], 'print("Hello, NexusLearn!")\n')

    def test_cannot_reach_file_through_own_project_id(self):
        pa = self.new_project(who=self.a, name="A")
        pb = self.new_project(who=self.b, name="B")
        fa = self.file_id(pa, "main.py")
        r = self.b.post(f"/projects/{pb}/files/{fa}/save", content="HACK")
        self.assertEqual(r.status_code, 404)
        self.assertNotEqual(self.q("SELECT content FROM project_files WHERE id = ?", fa)[0]["content"], "HACK")

    def test_login_required(self):
        anon = nexus.app.test_client()
        for url in ("/projects", "/projects/new", "/projects/1", "/snippets", "/snippets/new"):
            self.assertEqual(anon.get(url).status_code, 302, url)


if __name__ == "__main__":
    unittest.main()
