import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
import exercises_data  # noqa: E402
import grading  # noqa: E402
from test_projects import Base  # noqa: E402


class ExerciseContentTests(unittest.TestCase):
    """Every exercise must be solvable by its reference solution and NOT by its starter code."""

    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(DATABASE=self.path, PRACTICE_DIR=self.practice, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()

    def tearDown(self):
        os.remove(self.path)

    def exercises(self):
        db = nexus.get_db()
        return db.execute("SELECT * FROM exercises ORDER BY id").fetchall()

    def test_seeded_and_reseeding_is_safe(self):
        with nexus.app.app_context():
            self.assertEqual(len(self.exercises()), len(exercises_data.EXERCISES))
            nexus.init_db()
            self.assertEqual(len(self.exercises()), len(exercises_data.EXERCISES))

    def test_reference_solutions_pass_and_starters_fail(self):
        with nexus.app.app_context():
            for ex in self.exercises():
                tests = json.loads(ex["tests"])
                good = grading.grade(ex, ex["solution"], tests)
                self.assertTrue(good["passed"], f"{ex['slug']} solution failed: {good['tests']}")
                starter = grading.grade(ex, ex["starter_code"], tests)
                self.assertFalse(starter["passed"], f"{ex['slug']} starter already passes")

    def test_every_exercise_has_hidden_tests_or_varied_cases(self):
        for ex in exercises_data.EXERCISES:
            self.assertGreaterEqual(len(ex["tests"]), 1)
            if ex["language"] == "python":
                self.assertTrue(any(t.get("hidden") for t in ex["tests"]), ex["slug"])


class GradingTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(DATABASE=self.path, PRACTICE_DIR=self.practice, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()

    def tearDown(self):
        os.remove(self.path)

    def grade(self, slug, code):
        with nexus.app.app_context():
            ex = nexus.get_db().execute("SELECT * FROM exercises WHERE slug = ?", (slug,)).fetchone()
            return grading.grade(ex, code, json.loads(ex["tests"]))

    def test_running_without_errors_is_not_enough(self):
        self.assertFalse(self.grade("py-hello-name", "print('anything')")["passed"])
        self.assertFalse(self.grade("py-hello-name", "pass")["passed"])

    def test_hardcoding_the_examples_fails_hidden_tests(self):
        r = self.grade("py-sum-two", "a = input(); b = input()\nprint(5)")
        self.assertFalse(r["passed"])
        r = self.grade("py-hello-name", "print('Hello, Ada!')")
        self.assertEqual(r["tests_passed"], 1)
        self.assertTrue(r["tests"][2]["hidden"] and not r["tests"][2]["passed"])
        self.assertNotIn("expected", r["tests"][2])   # hidden tests never reveal the answer

    def test_whitespace_tolerance_but_exact_otherwise(self):
        self.assertTrue(self.grade("py-hello-name", "print('Hello, ' + input() + '!   ')\nprint()")["passed"])
        self.assertFalse(self.grade("py-hello-name", "print('hello, ' + input() + '!')")["passed"])  # case matters

    def test_runtime_error_is_explained(self):
        r = self.grade("py-sum-two", "print(int(input()) + undefined_name)")
        self.assertFalse(r["passed"])
        self.assertIn("NameError", r["tests"][0]["error"])

    def test_infinite_loop_stops_grading(self):
        r = self.grade("py-hello-name", "while True: pass")
        self.assertIn("Time limit", r["tests"][0]["error"])
        self.assertTrue(all(t.get("skipped") for t in r["tests"][1:]))

    def test_function_mode_ignores_noise_at_top_level(self):
        code = "print('debugging output')\ndef average(numbers):\n    return sum(numbers) / len(numbers) if numbers else 0.0\nprint(average([1, 2]))\n"
        self.assertTrue(self.grade("py-average", code)["passed"])

    def test_function_mode_catches_wrong_and_missing_functions(self):
        self.assertFalse(self.grade("py-average", "def average(numbers):\n    return sum(numbers) / len(numbers)\n")["passed"])  # empty list
        self.assertFalse(self.grade("py-average", "def mean(numbers):\n    return 0\n")["passed"])
        self.assertFalse(self.grade("py-average", "def average(:\n")["passed"])

    def test_sql_correct_answers_and_variants(self):
        self.assertTrue(self.grade("sql-high-gpa", "SELECT name FROM students WHERE gpa >= 3.7 ORDER BY gpa DESC;")["passed"])
        self.assertFalse(self.grade("sql-high-gpa", "SELECT name FROM students WHERE gpa >= 3.7 ORDER BY gpa ASC;")["passed"])  # order matters
        self.assertFalse(self.grade("sql-high-gpa", "SELECT name FROM students WHERE gpa > 3.7 ORDER BY gpa DESC;")["passed"])
        # unordered exercise: any row order, but exact column names
        self.assertTrue(self.grade("sql-major-counts", "SELECT major, COUNT(*) AS students FROM students GROUP BY major ORDER BY major DESC;")["passed"])
        r = self.grade("sql-major-counts", "SELECT major, COUNT(*) AS n FROM students GROUP BY major;")
        self.assertFalse(r["passed"])
        self.assertIn("Column names", r["tests"][0]["error"])

    def test_sql_errors_and_no_result(self):
        self.assertIn("syntax", self.grade("sql-course-list", "SELEC code FROM courses;")["tests"][0]["error"].lower())
        self.assertIn("did not return", self.grade("sql-course-list", "CREATE TABLE x (a INTEGER);")["tests"][0]["error"])

    def test_sql_data_changes_are_checked(self):
        ins = self.grade("sql-insert-student", "INSERT INTO students (name, major, year, gpa) VALUES ('Katherine Johnson', 'Mathematics', 2, 4.0);")
        self.assertTrue(ins["passed"])
        twice = "INSERT INTO students (name, major, year, gpa) VALUES ('Katherine Johnson', 'Mathematics', 2, 4.0);" * 2
        self.assertFalse(self.grade("sql-insert-student", twice)["passed"])
        wide = "UPDATE students SET gpa = gpa + 0.1;"   # changes everyone, not just Information Tech
        self.assertFalse(self.grade("sql-raise-gpa", wide)["passed"])


class LearnRouteTests(Base):
    def setUp(self):
        super().setUp()
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(PRACTICE_DIR=self.practice)

    def submit(self, slug, code, who=None):
        r = (who or self.a).post(f"/learn/exercises/{slug}/submit", code=code)
        return r.status_code, r.get_json()

    GOOD = 'name = input()\nprint(f"Hello, {name}!")\n'

    def test_failed_then_passed_attempts_are_tracked(self):
        code, r = self.submit("py-hello-name", "print('nope')")
        self.assertEqual((code, r["passed"], r["newly_completed"]), (200, False, False))
        code, r = self.submit("py-hello-name", self.GOOD)
        self.assertEqual((r["passed"], r["newly_completed"], r["tests_passed"], r["tests_total"]), (True, True, 3, 3))
        _, r = self.submit("py-hello-name", self.GOOD)
        self.assertFalse(r["newly_completed"])
        rows = self.q("SELECT passed FROM exercise_attempts ORDER BY id")
        self.assertEqual([x["passed"] for x in rows], [0, 1, 1])

    def test_completion_time_is_the_first_pass(self):
        self.submit("py-hello-name", self.GOOD)
        first = self.q("SELECT MIN(created_at) AS t FROM exercise_attempts WHERE passed = 1")[0]["t"]
        self.q("SELECT 1")
        self.submit("py-hello-name", self.GOOD)
        with nexus.app.app_context():
            db = nexus.get_db()
            db.execute("UPDATE exercise_attempts SET created_at = '2099-01-01 00:00:00' WHERE id = (SELECT MAX(id) FROM exercise_attempts)")
            db.commit()
        self.assertIn("Completed", self.a.get("/learn").data.decode())
        self.assertEqual(self.q("SELECT MIN(created_at) AS t FROM exercise_attempts WHERE passed = 1")[0]["t"], first)

    def test_submit_validation(self):
        self.assertEqual(self.submit("py-hello-name", "   ")[0], 400)
        self.assertEqual(self.submit("py-hello-name", "x" * 50_001)[0], 400)
        self.assertEqual(self.submit("no-such-exercise", "x")[0], 404)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM exercise_attempts")[0]["n"], 0)

    def test_sql_exercise_never_changes_the_practice_database(self):
        ins = "INSERT INTO students (name, major, year, gpa) VALUES ('Katherine Johnson', 'Mathematics', 2, 4.0);"
        self.assertTrue(self.submit("sql-insert-student", ins)[1]["passed"])
        r = self.a.post("/codelab/run/sql", code="SELECT COUNT(*) FROM students;").get_json()
        self.assertEqual(r["results"][0]["rows"][0][0], 8)
        # scratch trials (used in exercise mode) are also isolated
        self.a.post("/codelab/run/sql", code="DELETE FROM enrollments; DELETE FROM students;", scratch="1")
        r = self.a.post("/codelab/run/sql", code="SELECT COUNT(*) FROM students;").get_json()
        self.assertEqual(r["results"][0]["rows"][0][0], 8)

    def test_hub_filters_and_progress(self):
        self.submit("py-hello-name", self.GOOD)
        self.submit("py-sum-two", "print(0)")
        page = lambda qs: self.a.get("/learn?" + qs).data.decode()
        self.assertIn("1 / 19", page(""))
        self.assertIn("Greet by name", page("status=completed"))
        self.assertNotIn("Add two numbers", page("status=completed"))
        self.assertIn("Add two numbers", page("status=in_progress"))
        self.assertNotIn("Greet by name", page("status=not_started"))
        self.assertIn("List the courses", page("language=sql"))
        self.assertNotIn("Greet by name", page("language=sql"))
        self.assertIn("Factorial", page("difficulty=intermediate"))
        self.assertNotIn("Greet by name", page("difficulty=intermediate"))
        self.assertIn("Lists", page("topic=Lists") + "Lists")
        self.assertIn("Prime check", page("q=prime"))
        self.assertNotIn("Prime check", page("q=%25"))

    def test_progress_is_private_to_each_user(self):
        self.submit("py-hello-name", self.GOOD)
        self.assertIn("0 / 19", self.b.get("/learn").data.decode())
        self.assertNotIn(b"Passed", self.b.get("/learn/exercises/py-hello-name").data)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM exercise_attempts WHERE user_id = (SELECT id FROM users WHERE username='bobby')")[0]["n"], 0)

    def test_exercise_page_does_not_leak_solutions_or_hidden_answers(self):
        page = self.a.get("/learn/exercises/py-sum-two").data.decode()
        self.assertIn("Add two numbers", page)
        self.assertIn("hidden test", page)
        self.assertNotIn("print(a + b)", page)       # reference solution
        self.assertNotIn("350", page)                # a hidden expected value
        sql_page = self.a.get("/learn/exercises/sql-high-gpa").data.decode()
        solution = self.q("SELECT solution FROM exercises WHERE slug = 'sql-high-gpa'")[0]["solution"]
        self.assertNotIn(solution, sql_page)
        self.assertNotIn(solution.replace(">", "&gt;"), sql_page)

    def test_codelab_exercise_mode_loads_only_your_last_attempt(self):
        self.submit("py-hello-name", "print('my private attempt')")
        mine = self.a.get("/codelab?exercise=py-hello-name").data.decode()
        theirs = self.b.get("/codelab?exercise=py-hello-name").data.decode()
        self.assertIn("my private attempt", mine)
        self.assertNotIn("my private attempt", theirs)
        self.assertEqual(self.a.get("/codelab?exercise=nope").status_code, 404)
        self.assertNotIn("print(f", theirs)           # starter only, never the solution

    def test_login_and_csrf(self):
        anon = nexus.app.test_client()
        with anon.session_transaction() as s:
            s["csrf_token"] = "t"
        for url in ("/learn", "/learn/exercises/py-hello-name", "/learn/notes", "/learn/notes/new"):
            self.assertEqual(anon.get(url).status_code, 302, url)
        self.assertEqual(anon.post("/learn/exercises/py-hello-name/submit", data={"code": "x", "csrf_token": "t"}).status_code, 302)
        self.assertEqual(self.a.c.post("/learn/exercises/py-hello-name/submit", data={"code": "x", "csrf_token": "bad"}).status_code, 400)

    def test_dashboard_shows_recent_results(self):
        self.submit("py-hello-name", "print('x')")
        page = self.a.get("/dashboard").data.decode()
        self.assertIn("Greet by name", page)
        self.assertNotIn("Greet by name", self.b.get("/dashboard").data.decode())


class NoteTests(Base):
    def add(self, who=None, **kw):
        kw.setdefault("title", "Note")
        r = (who or self.a).post("/learn/notes/new", **kw)
        return self.q("SELECT MAX(id) AS i FROM notes")[0]["i"] if r.status_code == 302 else None

    def test_crud(self):
        nid = self.add(title="Joins", topic="SQL", body="INNER JOIN keeps matches")
        self.assertIn(b"INNER JOIN", self.a.get("/learn/notes").data)
        self.a.post(f"/learn/notes/{nid}/edit", title="Joins v2", topic="SQL", body="LEFT JOIN too")
        self.assertEqual(self.q("SELECT title FROM notes WHERE id = ?", nid)[0]["title"], "Joins v2")
        self.a.post(f"/learn/notes/{nid}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM notes")[0]["n"], 0)

    def test_validation(self):
        for bad in ({"title": ""}, {"title": "x" * 101}, {"topic": "x" * 41}, {"body": "x" * 20_001}):
            self.assertIsNone(self.add(**bad), bad)

    def test_search_and_topic_filter(self):
        self.add(title="Big O", topic="Algorithms", body="Time complexity basics")
        self.add(title="Pointers", topic="C", body="An address in memory")
        page = lambda qs: self.a.get("/learn/notes?" + qs).data
        self.assertIn(b"Big O", page("q=complexity"))
        self.assertNotIn(b"Pointers", page("q=complexity"))
        self.assertIn(b"Pointers", page("topic=C"))
        self.assertNotIn(b"Big O", page("topic=C"))
        self.assertNotIn(b"Big O", page("q=%25"))
        self.assertIn(b"No notes match", page("q=zzzz"))

    def test_private_and_escaped(self):
        nid = self.add(title="<b>Secret</b>", body="<script>alert(1)</script>")
        page = self.a.get("/learn/notes").data.decode()
        self.assertNotIn("<script>alert(1)</script>", page)
        self.assertNotIn(b"Secret", self.b.get("/learn/notes").data)
        self.assertEqual(self.b.get(f"/learn/notes/{nid}/edit").status_code, 404)
        self.assertEqual(self.b.post(f"/learn/notes/{nid}/edit", title="x").status_code, 404)
        self.assertEqual(self.b.post(f"/learn/notes/{nid}/delete").status_code, 404)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM notes")[0]["n"], 1)


if __name__ == "__main__":
    unittest.main()
