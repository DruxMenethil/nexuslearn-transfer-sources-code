import os
import re
import sys
import tempfile
import unittest
from datetime import date, timedelta
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
import focus  # noqa: E402
import progress  # noqa: E402
from test_projects import Base  # noqa: E402

T0 = 1_800_000_000.0   # Fri 2027-01-15 08:00 UTC


def day(offset_days, hour=12):
    """UTC timestamp text for T0's date shifted by whole days."""
    base = focus.utc_str(T0)[:10]
    d = date.fromisoformat(base) + timedelta(days=offset_days)
    return f"{d.isoformat()} {hour:02d}:00:00"


class P7Base(Base):
    def setUp(self):
        super().setUp()
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(PRACTICE_DIR=self.practice)
        p = mock.patch("focus.clock", lambda: T0)
        p.start()
        self.addCleanup(p.stop)

    def exec(self, sql, *args):
        with nexus.app.app_context():
            db = nexus.get_db()
            db.execute(sql, args)
            db.commit()

    def uid(self, name="alice"):
        return self.q("SELECT id FROM users WHERE username = ?", name)[0]["id"]

    def add_session(self, ended, seconds, who="alice", kind="focus"):
        self.exec("""INSERT INTO focus_sessions (user_id, kind, status, planned_seconds, duration_seconds, started_at, ended_at)
                     VALUES (?, ?, 'completed', ?, ?, ?, ?)""", self.uid(who), kind, max(seconds, 60), seconds, ended, ended)


class ProgressTests(P7Base):
    def test_empty_account_shows_guidance_and_no_charts(self):
        page = self.a.get("/progress").data.decode()
        self.assertIn("No activity to show yet", page)
        self.assertIn("No study time recorded", page)
        self.assertNotIn("<canvas", page)
        self.assertNotIn("improv", page.lower())

    def test_numbers_come_from_records(self):
        self.a.add(title="Done1"); self.a.add(title="Done2"); self.a.add(title="Open", due_date="2020-01-01")
        for tid in (1, 2):
            self.a.post(f"/tasks/{tid}/toggle")
        self.add_session(day(0), 1500)
        self.add_session(day(-1), 900)
        self.add_session(day(0), 300, kind="break")          # breaks never count
        self.add_session(day(0), 600, who="bobby")           # other users never count
        s = progress.__dict__  # noqa: F841
        with nexus.app.app_context():
            pass
        page = self.a.get("/progress?days=7").data.decode()
        self.assertIn("40 min", page)                        # 1500 + 900 s
        self.assertIn("67%", page)                           # 2 of 3 tasks completed
        self.assertIn("2 focus sessions".replace("2 focus sessions", "Focus sessions"), page)
        self.assertNotIn("50 min", page)

    def test_period_selector_and_bad_values(self):
        self.add_session(day(-20), 3600)                     # inside 30 days, outside 7
        total = lambda qs: re.search(r'nl-stat-n">([^<]+)</div><div>Total in (\d+) days', self.a.get("/progress" + qs).data.decode()).groups()
        self.assertEqual(total("?days=30"), ("1 h 00 min", "30"))
        self.assertEqual(total("?days=7"), ("0 s", "7"))
        for bad in ("abc", "0", "-5", "1000", ""):
            self.assertEqual(self.a.get(f"/progress?days={bad}").status_code, 200)
        self.assertEqual(total("?days=abc"), ("1 h 00 min", "30"))                    # falls back to 30

    def test_comparison_is_neutral_and_needs_previous_data(self):
        self.add_session(day(-1), 1200)
        self.assertIn("no study time in the previous period", self.a.get("/progress?days=7").data.decode())
        self.add_session(day(-10), 600)                      # previous 7-day window
        page = self.a.get("/progress?days=7").data.decode()
        self.assertIn("100% more study time", page)
        self.assertIn("not proof of progress", page)
        self.assertNotIn("improved", page.lower())

    def test_small_sample_warning(self):
        self.add_session(day(-1), 1200)
        self.assertIn("too little to read a trend", self.a.get("/progress?days=7").data.decode())

    def test_compare_text_unit(self):
        self.assertIn("less", progress.compare_text(50, 100, 7))
        self.assertIn("About the same", progress.compare_text(100, 100, 7))
        self.assertIn("no study time", progress.compare_text(100, 0, 7))

    def test_exercise_stats(self):
        self.a.post("/learn/exercises/py-hello-name/submit", code="print('x')")
        self.a.post("/learn/exercises/py-hello-name/submit", code='print(f"Hello, {input()}!")')
        self.exec("UPDATE exercise_attempts SET created_at = ?", day(0))       # the page's clock is fixed at T0
        page = self.a.get("/progress").data.decode()
        self.assertIn("50%", page)                           # 1 of 2 submissions passed
        self.assertIn("1 of 19 exercises completed", page)
        self.assertIn("<canvas", page)
        self.assertIn("—", self.b.get("/progress").data.decode())   # no submissions: no rate

    def test_project_activity_and_privacy(self):
        self.new_project(name="Visible")
        self.new_project(who=self.b, name="Hidden")
        page = self.a.get("/progress").data.decode()
        self.assertIn("Visible", page)
        self.assertNotIn("Hidden", page)

    def test_time_zone_buckets(self):
        self.add_session("2027-01-15 23:30:00", 1800)        # 01:30 on the 16th for UTC+2
        data = lambda tz: self.a.c.set_cookie("tz_offset", str(tz)) or self.a.get("/progress?days=7").data.decode()
        self.assertEqual(self.a.get("/progress?days=7").status_code, 200)
        page = data(-120)
        self.assertIn("30 min", page)

    def test_login_required(self):
        for url in ("/progress", "/settings", "/search?q=ab"):
            self.assertEqual(nexus.app.test_client().get(url).status_code, 302, url)


class SearchTests(P7Base):
    def setUp(self):
        super().setUp()
        self.a.add(title="Calculus homework", description="limits and derivatives")
        self.new_project(name="Calculator app")
        self.a.post("/snippets/new", title="Limit helper", language="python", code="def limit(): pass", tags="math")
        self.a.post("/learn/notes/new", title="Limits note", topic="Math", body="epsilon delta")
        self.b.add(title="Calculus secret")

    def page(self, qs, who=None):
        return (who or self.a).get("/search?" + qs).data.decode()

    def test_finds_every_type(self):
        page = self.page("q=calc")
        self.assertIn("Calculus homework", page)
        self.assertIn("Calculator app", page)
        page = self.page("q=limit")
        self.assertIn("Limit helper", page)
        self.assertIn("Limits note", page)
        self.assertIn("Calculus homework", page)             # matched by description

    def test_matches_snippet_code_note_body_and_file_names(self):
        self.assertIn("Limit helper", self.page("q=def+limit"))
        self.assertIn("Limits note", self.page("q=epsilon"))
        self.assertIn("Calculator app", self.page("q=main.py"))

    def test_type_filter(self):
        page = self.page("q=limit&type=notes")
        self.assertIn("Limits note", page)
        self.assertNotIn("Limit helper", page)

    def test_private_to_each_user(self):
        self.assertNotIn("Calculus secret", self.page("q=calculus"))
        self.assertNotIn("Calculus homework", self.page("q=calculus", self.b))
        self.assertIn("Calculus secret", self.page("q=calculus", self.b))

    def test_short_missing_and_empty_results(self):
        self.assertIn("at least 2 characters", self.page("q=a"))
        self.assertIn("at least 2 characters", self.page(""))
        self.assertIn("Nothing found", self.page("q=zzzzzz"))
        self.assertIn("Nothing found", self.page("q=%25%25"))      # '%' is literal, not a wildcard
        self.assertEqual(self.page("q=1%27%3B+DROP+TABLE+tasks%3B--").count("Nothing found"), 1)

    def test_output_is_escaped(self):
        self.a.add(title="<script>alert(7)</script> trick")
        page = self.page("q=trick")
        self.assertNotIn("<script>alert(7)</script>", page)


class SettingsTests(P7Base):
    def row(self, who="alice"):
        return self.q("SELECT * FROM users WHERE username = ?", who)[0]

    def test_profile_and_display_name(self):
        self.a.post("/settings/profile", display_name="  Ada   L  ")
        self.assertEqual(self.row()["display_name"], "Ada L")
        self.assertIn("<strong>Ada L</strong>", self.a.get("/dashboard").data.decode())
        self.a.post("/settings/profile", display_name="x" * 51)
        self.assertEqual(self.row()["display_name"], "Ada L")

    def test_theme_applies_and_validates(self):
        self.a.post("/settings/preferences", theme="light", default_language="sql")
        self.assertIn('data-bs-theme="light"', self.a.get("/dashboard").data.decode())
        self.assertIn('data-bs-theme="dark"', self.b.get("/dashboard").data.decode())
        for bad in (dict(theme="neon", default_language="sql"), dict(theme="dark", default_language="cobol")):
            self.a.post("/settings/preferences", **bad)
        self.assertEqual((self.row()["theme"], self.row()["default_language"]), ("light", "sql"))

    def test_default_language_opens_codelab(self):
        self.a.post("/settings/preferences", theme="dark", default_language="sql")
        self.assertIn('"default_lang": "sql"', self.a.get("/codelab").data.decode().replace('"default_lang":"sql"', '"default_lang": "sql"'))

    def test_timer_settings(self):
        self.a.post("/settings/timer", focus_minutes="30", break_minutes="7", long_break_minutes="20", long_break_every="3")
        self.assertEqual(tuple(self.row())[5:9], (30, 7, 20, 3))
        self.a.post("/settings/timer", focus_minutes="0", break_minutes="7", long_break_minutes="20", long_break_every="3")
        self.assertEqual(self.row()["focus_minutes"], 30)
        self.assertIn('value="30"', self.a.get("/focus").data.decode())

    def test_password_change(self):
        for form in (dict(current_password="wrong", new_password="newpassword1", confirmation="newpassword1"),
                     dict(current_password="password1", new_password="short", confirmation="short"),
                     dict(current_password="password1", new_password="newpassword1", confirmation="different1"),
                     dict(current_password="password1", new_password="password1", confirmation="password1")):
            self.a.post("/settings/password", **form)
        old_hash = self.row()["password_hash"]
        self.a.post("/settings/password", current_password="password1", new_password="newpassword1", confirmation="newpassword1")
        self.assertNotEqual(self.row()["password_hash"], old_hash)
        self.assertNotIn("newpassword1", self.row()["password_hash"])
        c = nexus.app.test_client()
        with c.session_transaction() as s:
            s["csrf_token"] = "t"
        bad = c.post("/login", data={"username": "alice", "password": "password1", "csrf_token": "t"})
        self.assertEqual(bad.status_code, 200)
        with c.session_transaction() as s:
            s["csrf_token"] = "t"
        ok = c.post("/login", data={"username": "alice", "password": "newpassword1", "csrf_token": "t"})
        self.assertEqual(ok.status_code, 302)

    def test_account_deletion_requires_password_and_username(self):
        self.a.add(title="Mine")
        self.b.add(title="Bobs")
        self.a.post("/settings/delete", password="wrong", confirm="alice")
        self.a.post("/settings/delete", password="password1", confirm="nope")
        self.assertEqual(len(self.q("SELECT * FROM users WHERE username = 'alice'")), 1)

    def test_account_deletion_removes_everything_for_that_user_only(self):
        uid = self.uid()
        self.a.add(title="Mine"); self.b.add(title="Bobs")
        self.new_project(name="AlicesProject"); self.new_project(who=self.b, name="BobsProject")
        self.a.post("/snippets/new", title="S", language="python", code="x=1")
        self.a.post("/learn/notes/new", title="N")
        self.a.post("/learn/exercises/py-hello-name/submit", code="print(1)")
        self.a.post("/codelab/run/sql", code="SELECT 1;")        # creates the practice database
        practice = os.path.join(self.practice, f"user_{uid}.db")
        self.assertTrue(os.path.exists(practice))
        r = self.a.post("/settings/delete", password="password1", confirm="ALICE")
        self.assertEqual(r.status_code, 302)
        self.assertFalse(os.path.exists(practice))
        for table in ("tasks", "projects", "code_snippets", "notes", "exercise_attempts", "subjects"):
            self.assertEqual(self.q(f"SELECT COUNT(*) AS n FROM {table} WHERE user_id = ?", uid)[0]["n"], 0, table)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM project_files WHERE project_id NOT IN (SELECT id FROM projects)")[0]["n"], 0)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM tasks")[0]["n"], 1)         # Bob's task survives
        self.assertEqual(self.a.get("/dashboard").status_code, 302)                    # logged out
        self.assertIn(b"BobsProject", self.b.get("/projects").data)

    def test_csrf_and_login_required(self):
        self.assertEqual(self.a.c.post("/settings/profile", data={"display_name": "x", "csrf_token": "bad"}).status_code, 400)
        anon = nexus.app.test_client()
        with anon.session_transaction() as s:
            s["csrf_token"] = "t"
        for name in ("profile", "preferences", "timer", "password", "delete"):
            self.assertEqual(anon.post(f"/settings/{name}", data={"csrf_token": "t"}).status_code, 302, name)


class PolishTests(P7Base):
    def test_deadline_reminders(self):
        today = date.today()
        self.a.add(title="Late", due_date=(today - timedelta(days=2)).isoformat())
        self.a.add(title="Soon", due_date=(today + timedelta(days=1)).isoformat())
        self.a.add(title="Far", due_date=(today + timedelta(days=30)).isoformat())
        page = self.a.get("/dashboard").data.decode()
        self.assertIn("1 overdue task", page)
        self.assertIn("1 due within 2 days", page)
        self.assertIn("no background notifications", page)
        self.assertIn("1<span class=\"visually-hidden\"> overdue", page)         # nav badge
        quiet = self.b.get("/dashboard").data.decode()
        self.assertNotIn("Deadline reminders", quiet)

    def test_completed_tasks_do_not_trigger_reminders(self):
        tid = self.a.add(title="Late", due_date="2020-01-01")
        self.a.post(f"/tasks/{tid}/toggle")
        self.assertNotIn("Deadline reminders", self.a.get("/dashboard").data.decode())

    def test_accessibility_basics_on_every_page(self):
        pages = ["/dashboard", "/planner", "/codelab", "/projects", "/snippets", "/focus", "/learn", "/learn/notes",
                 "/progress", "/settings", "/search?q=ab", "/tasks/new", "/projects/new", "/snippets/new"]
        for url in pages:
            html = self.a.get(url).data.decode()
            self.assertIn('<html lang="en"', html, url)
            self.assertIn('href="#main"', html, url)                 # skip link
            self.assertIn('id="main"', html, url)
            self.assertIn('name="viewport"', html, url)
            self.assertEqual(len(re.findall(r"<h1\b", html)), 1, f"{url} should have exactly one h1")
            self.assertIn('aria-label="Search your tasks', html, url)

    def test_nav_marks_current_page(self):
        self.assertIn('aria-current="page" href="/progress"', self.a.get("/progress").data.decode())
        self.assertIn('aria-current="page" href="/settings"', self.a.get("/settings").data.decode())

    def test_every_list_page_has_a_helpful_empty_state(self):
        for url, text in (("/planner", "No tasks yet"), ("/projects", "No projects yet"), ("/snippets", "library is empty"),
                          ("/learn/notes", "No notes yet"), ("/focus", "No completed sessions yet"),
                          ("/progress", "No activity to show yet")):
            self.assertIn(text, self.a.get(url).data.decode(), url)

    def test_form_fields_have_labels(self):
        for url in ("/tasks/new", "/projects/new", "/snippets/new", "/learn/notes/new", "/settings"):
            html = self.a.get(url).data.decode()
            ids = set(re.findall(r'<(?:input|select|textarea)[^>]*\bid="([^"]+)"', html))
            labelled = set(re.findall(r'<label[^>]*\bfor="([^"]+)"', html))
            self.assertTrue(ids <= labelled | {"username"} | {i for i in ids if i.startswith("t-")}, f"{url}: unlabeled {ids - labelled}")


if __name__ == "__main__":
    unittest.main()
