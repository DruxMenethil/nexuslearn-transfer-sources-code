import os
import sys
import tempfile
import unittest
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402


class Client:
    """A browser-like test client for one registered user."""
    def __init__(self, name):
        self.c = nexus.app.test_client()
        self.post("/register", username=name, password="password1", confirmation="password1")

    def post(self, url, **data):
        with self.c.session_transaction() as s:
            s["csrf_token"] = "t"
        data["csrf_token"] = "t"
        return self.c.post(url, data=data)

    def get(self, url):
        return self.c.get(url)

    def add(self, **kw):
        kw.setdefault("title", "Task")
        r = self.post("/tasks/new", **kw)
        return int(r.headers["Location"].rsplit("/", 1)[1]) if r.status_code == 302 else None


class TaskTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        nexus.app.config.update(DATABASE=self.path, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.a = Client("alice")
        self.b = Client("bobby")

    def tearDown(self):
        os.remove(self.path)

    def row(self, task_id):
        with nexus.app.app_context():
            return nexus.get_db().execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()

    def test_create_and_view(self):
        tid = self.a.add(title="Pset 1", subject="CS50", due_date="2030-01-05", priority="high")
        self.assertIsNotNone(tid)
        page = self.a.get(f"/tasks/{tid}").data
        self.assertIn(b"Pset 1", page)
        self.assertIn(b"CS50", page)

    def test_validation_rejects_bad_input(self):
        for bad in ({"title": ""}, {"title": "x" * 121}, {"title": "ok", "due_date": "2026-02-30"},
                    {"title": "ok", "due_date": "tomorrow"}, {"title": "ok", "priority": "urgent"},
                    {"title": "ok", "due_date": "1850-01-01"}):
            self.assertIsNone(self.a.add(**bad), bad)
        with nexus.app.app_context():
            n = nexus.get_db().execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        self.assertEqual(n, 0)

    def test_subject_reused_case_insensitively(self):
        self.a.add(subject="Math")
        self.a.add(subject="math")
        with nexus.app.app_context():
            n = nexus.get_db().execute("SELECT COUNT(*) FROM subjects").fetchone()[0]
        self.assertEqual(n, 1)

    def test_edit(self):
        tid = self.a.add(title="Old")
        r = self.a.post(f"/tasks/{tid}/edit", title="New", priority="low", subject="", due_date="")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.row(tid)["title"], "New")

    def test_toggle_sets_and_clears_completed_at(self):
        tid = self.a.add()
        self.a.post(f"/tasks/{tid}/toggle")
        r = self.row(tid)
        self.assertEqual((r["status"], r["completed_at"] is not None), ("completed", True))
        self.a.post(f"/tasks/{tid}/toggle")
        r = self.row(tid)
        self.assertEqual((r["status"], r["completed_at"]), ("pending", None))

    def test_delete(self):
        tid = self.a.add()
        self.a.post(f"/tasks/{tid}/delete")
        self.assertIsNone(self.row(tid))

    def test_authorization_between_users(self):
        tid = self.a.add(title="Secret")
        self.assertEqual(self.b.get(f"/tasks/{tid}").status_code, 404)
        self.assertEqual(self.b.get(f"/tasks/{tid}/edit").status_code, 404)
        self.assertEqual(self.b.post(f"/tasks/{tid}/edit", title="Hacked").status_code, 404)
        self.assertEqual(self.b.post(f"/tasks/{tid}/toggle").status_code, 404)
        self.assertEqual(self.b.post(f"/tasks/{tid}/delete").status_code, 404)
        self.assertNotIn(b"Secret", self.b.get("/planner").data)
        r = self.row(tid)
        self.assertEqual((r["title"], r["status"]), ("Secret", "pending"))

    def test_login_required(self):
        anon = nexus.app.test_client()
        for url in ("/planner", "/tasks/new", "/tasks/1"):
            self.assertEqual(anon.get(url).status_code, 302)

    def test_filters_and_search(self):
        today = date.today()
        past = (today - timedelta(days=3)).isoformat()
        self.a.add(title="Alpha essay", priority="high", due_date=past, subject="English")
        self.a.add(title="Beta lab", priority="low", subject="CS50")
        done = self.a.add(title="Gamma quiz")
        self.a.post(f"/tasks/{done}/toggle")
        page = lambda qs: self.a.get("/planner?" + qs).data
        self.assertIn(b"Alpha essay", page("status=overdue"))
        self.assertNotIn(b"Beta lab", page("status=overdue"))
        self.assertIn(b"Gamma quiz", page("status=completed"))
        self.assertNotIn(b"Alpha essay", page("priority=low"))
        self.assertIn(b"Beta lab", page("q=beta"))
        self.assertIn(b"Overdue", page(""))

    def test_search_is_injection_and_wildcard_safe(self):
        self.a.add(title="Plain task")
        self.assertEqual(self.a.get("/planner?q=%27%3B+DROP+TABLE+tasks%3B--").status_code, 200)
        self.assertNotIn(b"Plain task", self.a.get("/planner?q=%25").data)  # '%' is literal, not a wildcard
        self.assertEqual(self.a.get("/planner?sort=1;DROP").status_code, 200)

    def test_deadline_sort_order(self):
        self.a.add(title="LaterTask", due_date="2031-01-01")
        self.a.add(title="SoonerTask", due_date="2030-01-01")
        self.a.add(title="NoDateTask")
        html = self.a.get("/planner").data.decode()
        self.assertLess(html.index("SoonerTask"), html.index("LaterTask"))
        self.assertLess(html.index("LaterTask"), html.index("NoDateTask"))

    def test_dashboard_matches_database(self):
        past = (date.today() - timedelta(days=1)).isoformat()
        self.a.add(title="Late", due_date=past)
        t2 = self.a.add(title="Done")
        self.a.post(f"/tasks/{t2}/toggle")
        self.b.add(title="Bobs")
        html = self.a.get("/dashboard").data.decode()
        nums = [int(x.split("<")[0]) for x in html.split('nl-stat-n')[1:]
                if x.split(">", 1)[1].split("<")[0].isdigit() for x in [x.split(">", 1)[1]]]
        self.assertEqual(nums, [1, 1, 1, 2])  # pending, completed, overdue, total (alice only)


if __name__ == "__main__":
    unittest.main()
