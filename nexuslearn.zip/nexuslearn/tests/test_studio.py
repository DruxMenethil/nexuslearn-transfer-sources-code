"""Study Studio tests: notes, document import, quizzes, flashcards, visualizer, writing, search, progress."""
import io
import json
import os
import re
import sqlite3
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import algorithms  # noqa: E402
import app as nexus  # noqa: E402
import documents  # noqa: E402
import flashcards  # noqa: E402
import focus  # noqa: E402
import quizzes  # noqa: E402
import writing  # noqa: E402
from test_projects import Base  # noqa: E402

DEFS = """# Databases
Primary key: a column that uniquely identifies each row in a table
Foreign key: a column that references the primary key of another table
Index: a structure that speeds up lookups on one or more columns
Normalization: the process of organizing data to reduce redundancy
"""


class StudioBase(Base):
    def setUp(self):
        super().setUp()
        self.instance = tempfile.mkdtemp()
        self._old_instance = nexus.app.instance_path
        nexus.app.instance_path = self.instance

    def tearDown(self):
        nexus.app.instance_path = self._old_instance
        super().tearDown()

    def post(self, who, url, files=None, **data):
        with who.c.session_transaction() as s:
            s["csrf_token"] = "t"
        data["csrf_token"] = "t"
        if files:
            data.update(files)
        return who.c.post(url, data=data, content_type="multipart/form-data" if files else None)

    def note(self, who=None, **kw):
        kw.setdefault("title", "Note")
        r = self.post(who or self.a, "/learn/notes/new", **kw)
        return self.q("SELECT MAX(id) AS i FROM notes")[0]["i"] if r.status_code == 302 else None

    def quiz(self, who=None, publish=True, **kw):
        who = who or self.a
        kw.setdefault("title", "Quiz")
        r = self.post(who, "/study/quizzes/new", **kw)
        qid = int(r.headers["Location"].split("/")[-2])
        self.post(who, f"/study/quizzes/{qid}/questions", qtype="mcq", prompt="2+2?", answer="4", choices="3\n4\n5", explanation="Math")
        self.post(who, f"/study/quizzes/{qid}/questions", qtype="tf", prompt="The sky is green", answer="false")
        self.post(who, f"/study/quizzes/{qid}/questions", qtype="identification", prompt="Capital of France?", answer="Paris|paris france")
        self.post(who, f"/study/quizzes/{qid}/questions", qtype="blank", prompt="HTTP stands for _____ Transfer Protocol", answer="Hypertext")
        if publish:
            self.post(who, f"/study/quizzes/{qid}/status", status="published")
        return qid

    def answers(self, qid, **by_prompt):
        """Map prompt text -> answer into q<id> form fields."""
        out = {}
        for r in self.q("SELECT id, prompt FROM quiz_questions WHERE quiz_id = ?", qid):
            for key, val in by_prompt.items():
                if key in r["prompt"]:
                    out[f"q{r['id']}"] = val
        return out


# ------------------------------------------------------------------ notes ----
class NoteFeatureTests(StudioBase):
    def test_metadata_favorites_and_filters(self):
        n1 = self.note(title="Joins", topic="SQL", folder="Databases", tags="Joins, exam ,joins", favorite="1", body="x")
        self.note(title="Loops", topic="Python", folder="Basics", tags="loops", body="y")
        row = self.q("SELECT * FROM notes WHERE id = ?", n1)[0]
        self.assertEqual((row["folder"], row["tags"], row["favorite"]), ("Databases", "joins,exam", 1))
        page = lambda qs: self.a.get("/learn/notes?" + qs).data.decode()
        self.assertIn("Joins", page("favorite=1")); self.assertNotIn("Loops", page("favorite=1"))
        self.assertNotIn("Loops", page("folder=Databases"))
        self.assertNotIn("Loops", page("tag=exam"))
        self.assertIn("Loops", page("q=loops"))                       # tags are searchable
        self.post(self.a, f"/learn/notes/{n1}/favorite")
        self.assertEqual(self.q("SELECT favorite FROM notes WHERE id = ?", n1)[0]["favorite"], 0)

    def test_markdown_view_escapes_html(self):
        n = self.note(title="MD", body="# Head\n- item\n<script>alert(1)</script>\n```\nif a<b:\n```")
        page = self.a.get(f"/learn/notes/{n}").data.decode()
        self.assertIn("<h3>Head</h3>", page)
        self.assertIn("&lt;script&gt;alert(1)&lt;/script&gt;", page)
        self.assertNotIn("<script>alert(1)", page)
        self.assertIn("if a&lt;b:", page)

    def test_autosave_ok_invalid_and_foreign(self):
        n = self.note(title="Auto", body="one")
        r = self.post(self.a, f"/learn/notes/{n}/autosave", title="Auto", body="two", topic="", folder="", tags="")
        self.assertTrue(r.get_json()["ok"])
        self.assertEqual(self.q("SELECT body FROM notes WHERE id = ?", n)[0]["body"], "two")
        r = self.post(self.a, f"/learn/notes/{n}/autosave", title="", body="three")
        self.assertEqual(r.status_code, 400); self.assertFalse(r.get_json()["ok"])
        self.assertEqual(self.q("SELECT body FROM notes WHERE id = ?", n)[0]["body"], "two")   # failed save changed nothing
        self.assertEqual(self.post(self.b, f"/learn/notes/{n}/autosave", title="x", body="hack").status_code, 404)

    def test_export_and_privacy(self):
        n = self.note(title="My Note!", topic="T", body="hello")
        r = self.a.get(f"/learn/notes/{n}/export.md")
        self.assertIn("attachment", r.headers["Content-Disposition"]); self.assertIn(b"# My Note!", r.data)
        self.assertEqual(self.a.get(f"/learn/notes/{n}/export.txt").data, b"hello")
        self.assertEqual(self.a.get(f"/learn/notes/{n}/export.exe").status_code, 404)
        for url in (f"/learn/notes/{n}", f"/learn/notes/{n}/export.txt"):
            self.assertEqual(self.b.get(url).status_code, 404, url)

    def test_links_only_to_own_task_and_project(self):
        mine, theirs = self.a.add(title="Mine"), self.b.add(title="Theirs")
        n = self.note(title="Linked", task_id=str(mine))
        self.assertEqual(self.q("SELECT task_id FROM notes WHERE id = ?", n)[0]["task_id"], mine)
        n2 = self.note(title="Sneaky", task_id=str(theirs))
        self.assertIsNone(self.q("SELECT task_id FROM notes WHERE id = ?", n2)[0]["task_id"])

    def test_validation_and_csrf(self):
        self.assertIsNone(self.note(title=""))
        self.assertIsNone(self.note(title="x", folder="f" * 41))
        self.assertEqual(self.a.c.post("/learn/notes/new", data={"title": "x", "csrf_token": "bad"}).status_code, 400)

    def test_old_database_is_migrated_without_losing_notes(self):
        fd, path = tempfile.mkstemp(suffix=".db"); os.close(fd)
        con = sqlite3.connect(path)
        con.executescript("""CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL);
            CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
                topic TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
            INSERT INTO users (username, password_hash) VALUES ('old', 'x');
            INSERT INTO notes (user_id, title, body) VALUES (1, 'Legacy', 'kept');""")
        con.commit(); con.close()
        try:
            nexus.app.config.update(DATABASE=path)
            with nexus.app.app_context():
                nexus.init_db(); nexus.init_db()      # twice: must be repeatable
                row = nexus.get_db().execute("SELECT title, body, folder, tags, favorite FROM notes").fetchone()
                self.assertEqual(tuple(row), ("Legacy", "kept", "", "", 0))
        finally:
            nexus.app.config.update(DATABASE=self.path)
            os.remove(path)


# -------------------------------------------------------------- documents ----
def make_docx():
    import docx
    d = docx.Document()
    d.add_heading("Chapter One", 1)
    d.add_paragraph("Stacks are LIFO structures.")
    d.add_paragraph("push adds an item", style="List Bullet")
    buf = io.BytesIO(); d.save(buf)
    return buf.getvalue()


def make_pdf(text):
    stream = f"BT /F1 12 Tf 72 720 Td ({text}) Tj ET".encode()
    objs = [b"<< /Type /Catalog /Pages 2 0 R >>", b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
            b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream",
            b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    out, offsets = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out)); out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1) + b"".join(b"%010d 00000 n \n" % o for o in offsets)
    return out + b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF" % (len(objs) + 1, xref)


class DocumentTests(StudioBase):
    def upload(self, name, data, who=None):
        return self.post(who or self.a, "/learn/notes/import", files={"document": (io.BytesIO(data), name)})

    def doc_row(self):
        return self.q("SELECT * FROM note_documents ORDER BY id DESC LIMIT 1")[0]

    def test_txt_import_review_then_create_keeps_original(self):
        r = self.upload("lecture.txt", b"Stacks are LIFO.\nQueues are FIFO.")
        self.assertEqual(r.status_code, 302)
        doc = self.doc_row()
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM notes")[0]["n"], 0)       # nothing saved until reviewed
        review = self.a.get(f"/learn/notes/import/{doc['id']}").data.decode()
        self.assertIn("Stacks are LIFO.", review)
        r = self.post(self.a, f"/learn/notes/import/{doc['id']}", title="Lecture", body="Stacks are LIFO (edited).", topic="DS", folder="", tags="")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.q("SELECT body FROM notes")[0]["body"], "Stacks are LIFO (edited).")
        stored = os.path.join(self.instance, "uploads", str(self.q("SELECT id FROM users WHERE username='alice'")[0]["id"]), doc["stored_name"])
        self.assertTrue(os.path.exists(stored))
        self.assertNotIn("static", stored)
        self.assertNotIn("lecture", doc["stored_name"])                              # safe random filename
        self.assertEqual(self.a.get(f"/learn/documents/{doc['id']}/download").data, b"Stacks are LIFO.\nQueues are FIFO.")

    def test_docx_and_pdf_extraction(self):
        self.upload("notes.docx", make_docx())
        text = self.a.get(f"/learn/notes/import/{self.doc_row()['id']}").data.decode()
        self.assertIn("# Chapter One", text); self.assertIn("Stacks are LIFO structures.", text); self.assertIn("- push adds an item", text)
        self.upload("paper.pdf", make_pdf("Hello Pdf World"))
        self.assertIn("Hello Pdf World", self.a.get(f"/learn/notes/import/{self.doc_row()['id']}").data.decode())

    def test_scanned_or_blank_pdf_explains_ocr_limit(self):
        from pypdf import PdfWriter
        w = PdfWriter(); w.add_blank_page(200, 200); buf = io.BytesIO(); w.write(buf)
        r = self.post(self.a, "/learn/notes/import", files={"document": (io.BytesIO(buf.getvalue()), "scan.pdf")})
        page = self.a.get(r.headers["Location"]).data.decode()
        self.assertIn("OCR is not implemented", page)
        r = self.post(self.a, f"/learn/notes/import/{self.doc_row()['id']}", title="Empty", body="   ")
        self.assertEqual(r.status_code, 200); self.assertEqual(self.q("SELECT COUNT(*) AS n FROM notes")[0]["n"], 0)

    def test_invalid_uploads_are_rejected(self):
        cases = [("virus.exe", b"MZ"), ("fake.pdf", b"not a pdf"), ("fake.docx", b"not a zip"), ("empty.txt", b""),
                 ("bin.txt", b"abc\x00def"), ("huge.txt", b"a" * (documents.MAX_UPLOAD + 1)), ("noext", b"hello")]
        for name, data in cases:
            r = self.upload(name, data)
            self.assertEqual(r.status_code, 302, name)
            self.assertNotIn("/import/", r.headers["Location"], name)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM note_documents")[0]["n"], 0)
        r = self.post(self.a, "/learn/notes/import")                                  # no file at all
        self.assertEqual(r.status_code, 302)

    def test_corrupt_docx_is_reported_not_crashed(self):
        import zipfile
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("word/document.xml", "<broken")
        r = self.upload("bad.docx", buf.getvalue())
        self.assertEqual(r.status_code, 302); self.assertNotIn("/import/", r.headers["Location"])

    def test_documents_are_private_and_removable(self):
        self.upload("mine.txt", b"secret text here")
        doc = self.doc_row()
        for url in (f"/learn/notes/import/{doc['id']}", f"/learn/documents/{doc['id']}/download"):
            self.assertEqual(self.b.get(url).status_code, 404, url)
        self.assertEqual(self.post(self.b, f"/learn/documents/{doc['id']}/discard").status_code, 404)
        uid = self.q("SELECT id FROM users WHERE username='alice'")[0]["id"]
        path = os.path.join(self.instance, "uploads", str(uid), doc["stored_name"])
        self.post(self.a, f"/learn/documents/{doc['id']}/discard")
        self.assertFalse(os.path.exists(path))

    def test_account_deletion_removes_uploads_and_studio_data(self):
        self.upload("mine.txt", b"abc def")
        uid = self.q("SELECT id FROM users WHERE username='alice'")[0]["id"]
        self.quiz(); self.post(self.a, "/study/flashcards/new", name="D")
        self.assertTrue(os.path.isdir(os.path.join(self.instance, "uploads", str(uid))))
        self.post(self.a, "/settings/delete", password="password1", confirm="alice")
        self.assertFalse(os.path.isdir(os.path.join(self.instance, "uploads", str(uid))))
        for table in ("note_documents", "quizzes", "quiz_questions", "decks"):
            self.assertEqual(self.q(f"SELECT COUNT(*) AS n FROM {table}")[0]["n"], 0, table)


# ---------------------------------------------------------------- quizzes ----
class QuizTests(StudioBase):
    def test_validation_of_questions(self):
        qid = self.post(self.a, "/study/quizzes/new", title="V").headers["Location"].split("/")[-2]
        bad = [dict(qtype="mcq", prompt="Q", answer="x", choices="a\nb"),          # answer not a choice
               dict(qtype="mcq", prompt="Q", answer="a", choices="a"),             # only one choice
               dict(qtype="mcq", prompt="Q", answer="a", choices="a\nA"),          # duplicate choices
               dict(qtype="tf", prompt="Q", answer="maybe"), dict(qtype="identification", prompt="", answer="x"),
               dict(qtype="blank", prompt="Q", answer=""), dict(qtype="essay", prompt="Q", answer="x")]
        for b in bad:
            self.post(self.a, f"/study/quizzes/{qid}/questions", **b)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_questions")[0]["n"], 0)
        self.assertIsNone(self.q("SELECT time_limit_minutes FROM quizzes")[0]["time_limit_minutes"])
        r = self.post(self.a, "/study/quizzes/new", title="T", time_limit_minutes="0")
        self.assertEqual(r.status_code, 200)

    def test_cannot_publish_empty_and_draft_cannot_be_taken(self):
        qid = int(self.post(self.a, "/study/quizzes/new", title="Empty").headers["Location"].split("/")[-2])
        self.post(self.a, f"/study/quizzes/{qid}/status", status="published")
        self.assertEqual(self.q("SELECT status FROM quizzes")[0]["status"], "draft")
        self.assertEqual(self.a.get(f"/study/quizzes/{qid}/take").status_code, 302)

    def test_take_page_never_contains_the_answer_key(self):
        qid = self.quiz()
        self.post(self.a, f"/study/quizzes/{qid}/take")
        page = self.a.get(f"/study/quizzes/{qid}/take").data.decode()
        self.assertIn("2+2?", page); self.assertIn("Capital of France?", page)
        for secret in ("Paris", "paris france", "Hypertext", "Math"):
            self.assertNotIn(secret, page)
        self.assertNotIn('value="false"', page)

    def test_grading_review_and_retake_history(self):
        qid = self.quiz()
        self.post(self.a, f"/study/quizzes/{qid}/take")
        att = self.q("SELECT id FROM quiz_attempts")[0]["id"]
        r = self.post(self.a, f"/study/attempts/{att}/submit",
                      **self.answers(qid, **{"2+2": "4", "sky": "False", "France": "PARIS.", "HTTP": "hyper text"}))
        self.assertEqual(r.status_code, 302)
        row = self.q("SELECT score, total, status FROM quiz_attempts WHERE id = ?", att)[0]
        self.assertEqual((row["score"], row["total"], row["status"]), (3, 4, "submitted"))        # blank needs review
        resp = {x["qtype"]: x["is_correct"] for x in self.q("SELECT qtype, is_correct FROM quiz_responses")}
        self.assertEqual(resp, {"mcq": 1, "tf": 1, "identification": 1, "blank": None})
        page = self.a.get(f"/study/attempts/{att}").data.decode()
        self.assertIn("Needs your review", page); self.assertIn("Explanation: Math", page)
        rid = self.q("SELECT id FROM quiz_responses WHERE is_correct IS NULL")[0]["id"]
        self.post(self.a, f"/study/attempts/{att}/mark/{rid}", verdict="correct")
        self.assertEqual(self.q("SELECT score FROM quiz_attempts WHERE id = ?", att)[0]["score"], 4)
        # editing the quiz afterwards must not rewrite history
        qrow = self.q("SELECT id FROM quiz_questions WHERE qtype = 'mcq'")[0]["id"]
        self.post(self.a, f"/study/quizzes/{qid}/questions/{qrow}", qtype="mcq", prompt="Changed", answer="5", choices="4\n5")
        self.assertIn("2+2?", self.a.get(f"/study/attempts/{att}").data.decode())
        # retake: previous attempt is kept
        self.post(self.a, f"/study/quizzes/{qid}/take")
        att2 = self.q("SELECT id FROM quiz_attempts WHERE status = 'in_progress'")[0]["id"]
        self.assertNotEqual(att, att2)
        self.post(self.a, f"/study/attempts/{att2}/submit")                                        # everything blank
        self.assertEqual(self.q("SELECT score FROM quiz_attempts WHERE id = ?", att2)[0]["score"], 0)
        self.assertEqual(self.q("SELECT score FROM quiz_attempts WHERE id = ?", att)[0]["score"], 4)
        self.post(self.a, f"/study/attempts/{att2}/submit", **self.answers(qid, **{"2+2": "4"}))   # second submit is ignored
        self.assertEqual(self.q("SELECT score FROM quiz_attempts WHERE id = ?", att2)[0]["score"], 0)

    def test_double_start_gives_one_open_attempt(self):
        qid = self.quiz()
        for _ in range(3):
            self.post(self.a, f"/study/quizzes/{qid}/take")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_attempts WHERE status = 'in_progress'")[0]["n"], 1)

    def test_timer_is_rendered_for_timed_quiz(self):
        qid = self.quiz(time_limit_minutes="5")
        self.post(self.a, f"/study/quizzes/{qid}/take")
        self.assertIn('id="timer"', self.a.get(f"/study/quizzes/{qid}/take").data.decode())

    def test_reorder_duplicate_delete(self):
        qid = self.quiz(publish=False)
        ids = [r["id"] for r in self.q("SELECT id FROM quiz_questions ORDER BY position")]
        self.post(self.a, f"/study/quizzes/{qid}/questions/{ids[1]}/move", direction="up")
        self.assertEqual([r["id"] for r in self.q("SELECT id FROM quiz_questions ORDER BY position")][:2], [ids[1], ids[0]])
        r = self.post(self.a, f"/study/quizzes/{qid}/duplicate")
        copy = int(r.headers["Location"].split("/")[-2])
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_questions WHERE quiz_id = ?", copy)[0]["n"], 4)
        self.assertEqual(self.q("SELECT status FROM quizzes WHERE id = ?", copy)[0]["status"], "draft")
        self.post(self.a, f"/study/quizzes/{qid}/questions/{ids[0]}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_questions WHERE quiz_id = ?", qid)[0]["n"], 3)
        self.post(self.a, f"/study/quizzes/{qid}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quizzes WHERE id = ?", qid)[0]["n"], 0)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_questions WHERE quiz_id = ?", copy)[0]["n"], 4)

    def test_other_users_cannot_touch_my_quiz_or_attempts(self):
        qid = self.quiz()
        self.post(self.a, f"/study/quizzes/{qid}/take")
        att = self.q("SELECT id FROM quiz_attempts")[0]["id"]
        qrow = self.q("SELECT id FROM quiz_questions")[0]["id"]
        for method, url in [("get", f"/study/quizzes/{qid}/edit"), ("get", f"/study/quizzes/{qid}/take"),
                            ("get", f"/study/attempts/{att}"), ("get", f"/study/quizzes/{qid}/questions/{qrow}"),
                            ("post", f"/study/quizzes/{qid}/take"), ("post", f"/study/attempts/{att}/submit"),
                            ("post", f"/study/quizzes/{qid}/delete"), ("post", f"/study/quizzes/{qid}/duplicate"),
                            ("post", f"/study/quizzes/{qid}/questions"), ("post", f"/study/quizzes/{qid}/status")]:
            r = self.b.get(url) if method == "get" else self.post(self.b, url, status="published", qtype="tf", prompt="x", answer="true")
            self.assertEqual(r.status_code, 404, url)
        self.assertIn("No quizzes yet", self.b.get("/study/quizzes").data.decode())
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quiz_questions")[0]["n"], 4)

    def test_link_notes_ignores_foreign_notes(self):
        mine, theirs = self.note(title="Mine"), self.note(self.b, title="Theirs")
        qid = int(self.post(self.a, "/study/quizzes/new", title="L").headers["Location"].split("/")[-2])
        self.a.c.post(f"/study/quizzes/{qid}/edit", data={"csrf_token": "t", "title": "L", "difficulty": "beginner",
                                                         "note_ids": [str(mine), str(theirs)]})
        self.assertEqual([r["note_id"] for r in self.q("SELECT note_id FROM quiz_notes")], [mine])

    def test_generation_is_template_based_editable_and_validated(self):
        n = self.note(title="DB", body=DEFS)
        page = self.post(self.a, "/study/quizzes/generate", note_ids=str(n), count="4", types=["mcq", "identification"]).data.decode()
        self.assertIn("no AI", page); self.assertIn("Which term matches", page)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quizzes")[0]["n"], 0)               # nothing saved yet
        form = {"title": "From notes", "difficulty": "beginner", "n": "2", "note_ids": str(n),
                "keep-0": "on", "qtype-0": "identification", "prompt-0": "Edited prompt", "answer-0": "Primary key",
                "keep-1": "on", "qtype-1": "mcq", "prompt-1": "Bad", "answer-1": "zzz", "choices-1": "a\nb"}
        self.post(self.a, "/study/quizzes/generate/save", **form)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM quizzes")[0]["n"], 0)               # one invalid draft blocks the save
        form.update({"keep-1": ""})
        self.post(self.a, "/study/quizzes/generate/save", **form)
        quiz = self.q("SELECT source, status FROM quizzes")[0]
        self.assertEqual((quiz["source"], quiz["status"]), ("template", "draft"))
        self.assertEqual(self.q("SELECT prompt FROM quiz_questions")[0]["prompt"], "Edited prompt")
        self.assertEqual(len(self.q("SELECT * FROM quiz_notes")), 1)

    def test_generation_with_no_usable_text_says_so(self):
        page = self.post(self.a, "/study/quizzes/generate", text="hi", count="3", types=["mcq"]).data.decode()
        self.assertIn("No questions could be drafted", page)

    def test_generator_functions(self):
        d, _ = quizzes.generate_drafts(DEFS, 8, ["mcq", "tf", "blank", "identification"])
        self.assertGreaterEqual(len(d), 6)
        for q in d:
            v, errs = quizzes.validate_question({**q, "choices": "\n".join(q["choices"])})
            self.assertEqual(errs, [], q)
        self.assertEqual(quizzes.grade("identification", "RAM|memory", " Memory! "), 1)
        self.assertIsNone(quizzes.grade("blank", "x", "y")); self.assertEqual(quizzes.grade("mcq", "a", ""), 0)


# ------------------------------------------------------------- flashcards ----
class SchedulerTests(unittest.TestCase):
    def step(self, state, rating, today="2026-01-01"):
        return flashcards.schedule(state["interval_days"], state["ease"], state["repetitions"], state["lapses"], rating, today)

    def test_easy_progression_and_lapse(self):
        s = {"interval_days": 0, "ease": 2.5, "repetitions": 0, "lapses": 0}
        s = self.step(s, "easy"); self.assertEqual((s["interval_days"], s["due_date"]), (3, "2026-01-04"))
        s = self.step(s, "easy"); self.assertEqual(s["interval_days"], 6)
        s = self.step(s, "easy"); self.assertGreater(s["interval_days"], 6)
        s = self.step(s, "difficult"); self.assertEqual((s["interval_days"], s["repetitions"], s["lapses"], s["due_date"]), (1, 0, 1, "2026-01-02"))
        self.assertLess(s["ease"], 2.8)

    def test_ease_bounds_and_uncertain(self):
        s = {"interval_days": 5, "ease": 1.3, "repetitions": 3, "lapses": 0}
        self.assertEqual(self.step(s, "difficult")["ease"], 1.3)
        self.assertGreaterEqual(self.step(s, "uncertain")["interval_days"], 6)
        s["ease"] = 3.0
        self.assertEqual(self.step(s, "easy")["ease"], 3.0)
        with self.assertRaises(ValueError):
            self.step(s, "meh")


class FlashcardTests(StudioBase):
    def deck(self, who=None, name="Deck"):
        r = self.post(who or self.a, "/study/flashcards/new", name=name)
        return int(r.headers["Location"].rsplit("/", 1)[1]) if r.status_code == 302 else None

    def card(self, deck, front="Front", back="Back", who=None):
        self.post(who or self.a, f"/study/flashcards/{deck}/cards", front=front, back=back)
        return self.q("SELECT MAX(id) AS i FROM cards")[0]["i"]

    def test_deck_and_card_crud_and_validation(self):
        d = self.deck(name="Python")
        self.assertIsNone(self.deck(name="Python"))                                       # unique per user
        self.assertIsNotNone(self.deck(self.b, name="Python"))                            # other user may reuse the name
        self.assertIsNone(self.deck(name=""))
        c = self.card(d, "len()", "returns the length")
        self.post(self.a, f"/study/flashcards/{d}/cards", front="", back="x")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM cards")[0]["n"], 1)
        self.post(self.a, f"/study/cards/{c}/edit", front="len(x)", back="length", example="len([1])", explanation="built-in")
        self.assertEqual(self.q("SELECT front, example FROM cards")[0]["example"], "len([1])")
        self.post(self.a, f"/study/flashcards/{d}/edit", name="Python 101")
        self.assertIn("Python 101", self.a.get("/study/flashcards").data.decode())
        self.post(self.a, f"/study/cards/{c}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM cards")[0]["n"], 0)

    def test_review_updates_schedule_and_history_and_due_queue(self):
        clock = [1_800_000_000.0]
        old = focus.clock; focus.clock = lambda: clock[0]
        try:
            d = self.deck(); c = self.card(d)
            self.assertIn("Front", self.a.get("/study/review").data.decode())            # new cards are due today
            r = self.post(self.a, f"/study/cards/{c}/review", rating="easy")
            self.assertTrue(r.get_json()["ok"]); self.assertEqual(r.get_json()["interval_days"], 3)
            row = self.q("SELECT * FROM cards WHERE id = ?", c)[0]
            self.assertEqual((row["repetitions"], row["interval_days"]), (1, 3)); self.assertIsNotNone(row["last_reviewed"])
            self.assertEqual(self.q("SELECT rating, interval_after FROM card_reviews")[0]["rating"], "easy")
            self.assertNotIn(b"Front", self.a.get("/study/review").data.split(b"cards-json")[-1][:200])   # no longer due
            clock[0] += 3 * 86400
            self.assertIn("Front", self.a.get("/study/review").data.decode())            # due again after 3 days
            self.post(self.a, f"/study/cards/{c}/review", rating="difficult")
            self.assertEqual(self.q("SELECT lapses, interval_days FROM cards")[0]["lapses"], 1)
            self.assertEqual(self.q("SELECT COUNT(*) AS n FROM card_reviews")[0]["n"], 2)
        finally:
            focus.clock = old

    def test_invalid_rating_and_foreign_card(self):
        d = self.deck(); c = self.card(d)
        self.assertEqual(self.post(self.a, f"/study/cards/{c}/review", rating="great").status_code, 400)
        self.assertEqual(self.post(self.b, f"/study/cards/{c}/review", rating="easy").status_code, 404)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM card_reviews")[0]["n"], 0)
        for method, url in [("get", f"/study/flashcards/{d}"), ("get", f"/study/flashcards/{d}/study"), ("get", f"/study/cards/{c}/edit"),
                            ("post", f"/study/cards/{c}/delete"), ("post", f"/study/flashcards/{d}/delete"),
                            ("post", f"/study/flashcards/{d}/cards"), ("post", f"/study/flashcards/{d}/duplicate")]:
            r = self.b.get(url) if method == "get" else self.post(self.b, url, front="x", back="y")
            self.assertEqual(r.status_code, 404, url)

    def test_saved_cards_are_stable_and_session_limit_applies(self):
        d = self.deck()
        for i in range(6):
            self.card(d, f"F{i}", f"B{i}")
        before = self.q("SELECT id, front, back, due_date FROM cards ORDER BY id")
        for _ in range(3):
            self.a.get(f"/study/flashcards/{d}"); self.a.get(f"/study/flashcards/{d}/study?order=shuffle&limit=3")
        self.assertEqual(before, self.q("SELECT id, front, back, due_date FROM cards ORDER BY id"))
        page = self.a.get(f"/study/flashcards/{d}/study?limit=3").data.decode()
        data = json.loads(re.search(r'id="cards-json">(.*?)</script>', page, re.S).group(1))
        self.assertEqual([c["front"] for c in data], ["F0", "F1", "F2"])
        shuffled = json.loads(re.search(r'id="cards-json">(.*?)</script>', self.a.get(f"/study/flashcards/{d}/study?order=shuffle&limit=100").data.decode(), re.S).group(1))
        self.assertEqual(sorted(c["front"] for c in shuffled), [f"F{i}" for i in range(6)])

    def test_duplicate_deck_resets_schedule_and_renames(self):
        d = self.deck(name="Base"); c = self.card(d)
        self.post(self.a, f"/study/cards/{c}/review", rating="easy")
        r = self.post(self.a, f"/study/flashcards/{d}/duplicate")
        copy = int(r.headers["Location"].rsplit("/", 1)[1])
        row = self.q("SELECT repetitions, interval_days FROM cards WHERE deck_id = ?", copy)[0]
        self.assertEqual((row["repetitions"], row["interval_days"]), (0, 0))
        self.assertEqual(self.q("SELECT name FROM decks WHERE id = ?", copy)[0]["name"], "Base (copy)")
        self.post(self.a, f"/study/flashcards/{d}/duplicate")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM decks")[0]["n"], 3)

    def test_generation_from_notes_is_reviewed_before_saving(self):
        n = self.note(title="DB", body=DEFS)
        page = self.post(self.a, "/study/flashcards/generate", note_ids=str(n), deck_name="DB deck").data.decode()
        self.assertIn("no AI", page); self.assertIn("Primary key", page)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM cards")[0]["n"], 0)
        self.post(self.a, "/study/flashcards/generate/save", deck_name="DB deck", n="2", note_ids=str(n),
                  **{"keep-0": "on", "front-0": "PK", "back-0": "unique id", "keep-1": "", "front-1": "x", "back-1": "y"})
        self.assertEqual([r["front"] for r in self.q("SELECT front FROM cards")], ["PK"])
        self.assertEqual(len(self.q("SELECT * FROM deck_notes")), 1)
        self.post(self.a, "/study/flashcards/generate/save", deck_name="DB deck", n="1", **{"keep-0": "on", "front-0": "", "back-0": "y"})
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM cards")[0]["n"], 1)           # invalid card rejected

    def test_search_inside_deck(self):
        d = self.deck(); self.card(d, "alpha", "one"); self.card(d, "beta", "two")
        page = self.a.get(f"/study/flashcards/{d}?q=beta").data.decode()
        self.assertIn("<strong>beta</strong>", page); self.assertNotIn("<strong>alpha</strong>", page)


# ------------------------------------------------------------- visualizer ----
class AlgorithmTests(StudioBase):
    ARRAYS = ["5,2,9,1,5,6", "1,2,3,4,5", "3,3,3,3", "9", "2,1", "-5,0,5,-5"]

    def test_sorts_are_correct_and_counters_match_the_trace(self):
        for name in ("bubble", "selection", "insertion"):
            for raw in self.ARRAYS:
                for order in ("asc", "desc"):
                    r = algorithms.run(name, raw, order)
                    values = algorithms.parse_array(raw)
                    self.assertEqual(r["final"], sorted(values, reverse=order == "desc"), (name, raw, order))
                    swaps = sum(1 for s in r["steps"] if s["swap"])
                    comps = sum(1 for s in r["steps"] if s["compare"] and s["comparisons"] > 0 and
                                (s["note"].find("already in order") >= 0 or s["note"].find("swapped") >= 0 or "compare" in s["note"].lower()
                                 or "right place" in s["note"] or "move" in s["note"].lower()))
                    self.assertEqual(r["stats"]["swaps"], swaps, (name, raw)); self.assertEqual(r["steps"][-1]["swaps"], swaps)
                    self.assertEqual(r["steps"][-1]["array"], r["final"]); self.assertEqual(r["steps"][0]["array"], values)
                    self.assertEqual(r["steps"][-1]["comparisons"], r["stats"]["comparisons"])
                    self.assertTrue(all(sorted(s["array"]) == sorted(values) for s in r["steps"]))     # a step never loses a value

    def test_already_sorted_bubble_stops_early(self):
        r = algorithms.run("bubble", "1,2,3,4,5", "asc")
        self.assertEqual((r["stats"]["swaps"], r["stats"]["passes"], r["stats"]["comparisons"]), (0, 1, 4))

    def test_known_counts(self):
        self.assertEqual(algorithms.run("bubble", "3,2,1", "asc")["stats"], {"comparisons": 3, "swaps": 3, "passes": 2})
        self.assertEqual(algorithms.run("selection", "3,2,1", "asc")["stats"], {"comparisons": 3, "swaps": 1, "passes": 2})

    def test_searches(self):
        r = algorithms.run("linear", "4,8,15,16", "", "15"); self.assertEqual((r["found"], r["stats"]["comparisons"]), (2, 3))
        self.assertEqual(algorithms.run("linear", "4,8", "", "99")["found"], -1)
        r = algorithms.run("binary", "9,1,5,3,7", "", "7")
        self.assertEqual(r["input"], [1, 3, 5, 7, 9]); self.assertIn("sorted first", r["notice"]); self.assertEqual(r["found"], 3)
        self.assertEqual(algorithms.run("binary", "1,3,5", "", "4")["found"], -1)
        r = algorithms.run("binary", "1,2,3,4,5,6,7,8", "", "8"); self.assertLessEqual(r["stats"]["comparisons"], 4)

    def test_input_validation_and_routes(self):
        for raw in ("", "a,b", "1," * 31, "1,5000", "1.5"):
            with self.assertRaises(ValueError):
                algorithms.parse_array(raw)
        self.assertEqual(self.a.get("/learn/visualizer/trace?algorithm=bubble&array=3,1,2&order=desc").get_json()["final"], [3, 2, 1])
        self.assertEqual(self.a.get("/learn/visualizer/trace?algorithm=bubble&array=x").status_code, 400)
        self.assertEqual(self.a.get("/learn/visualizer/trace?algorithm=quick&array=1").status_code, 400)
        self.assertEqual(self.a.get("/learn/visualizer/trace?algorithm=linear&array=1,2&target=z").status_code, 400)
        self.assertEqual(self.a.get("/learn/visualizer").status_code, 200)
        anon = nexus.app.test_client()
        self.assertEqual(anon.get("/learn/visualizer/trace?algorithm=bubble&array=1").status_code, 302)


# ---------------------------------------------------------------- writing ----
class WritingTests(StudioBase):
    TEXT = "teh algorithm  runs fast ,and i'm sure it it works. we don't know.\nUse `teh_var` and print(teh) here, see https://x.io/teh."

    def check(self, **kw):
        kw.setdefault("text", self.TEXT); kw.setdefault("style", "academic")
        return self.post(self.a, "/study/writing/check", **kw)

    def test_basic_edits_and_code_is_never_touched(self):
        edits = writing.find_edits(self.TEXT, "academic")
        revised = writing.apply_edits(self.TEXT, edits, {e["id"] for e in edits})
        self.assertTrue(revised.startswith("The algorithm runs fast, and I'm sure it works. We do not know."))
        for protected in ("`teh_var`", "print(teh)", "https://x.io/teh"):
            self.assertIn(protected, revised)

    def test_technical_text_is_left_alone(self):
        tech = "Call os.path.join and myVariable then parse_input(x) in main.py.\n    teh_indented_code = 1"
        self.assertEqual(writing.find_edits(tech, "academic"), [])

    def test_styles_differ(self):
        t = "We utilize a number of tools in order to test. It's fine."
        self.assertEqual([e["new"] for e in writing.find_edits(t, "academic")], ["It is"])
        self.assertIn("use", [e["new"] for e in writing.find_edits(t, "professional")])
        self.assertNotIn("It is", [e["new"] for e in writing.find_edits(t, "simple")])

    def test_page_labels_engine_honestly_and_shows_side_by_side(self):
        page = self.check().data.decode()
        self.assertIn("Basic local checks", page); self.assertIn("not</strong> a full grammar checker", page)
        self.assertNotIn("AI-assisted", page); self.assertIn("diff-del", self.post(self.a, "/study/writing/apply", text=self.TEXT, style="academic", accept="0").data.decode())

    def test_only_accepted_changes_are_applied(self):
        edits = writing.find_edits(self.TEXT, "academic")
        r = self.post(self.a, "/study/writing/apply", text=self.TEXT, style="academic", accept=[str(edits[0]["id"])]).data.decode()
        self.assertIn("The algorithm", r); self.assertIn("it it works", r)

    def test_length_limits_and_empty_text(self):
        self.assertIn("limited to", self.check(text="a" * (writing.MAX_TEXT + 1)).data.decode())
        self.assertIn("Enter some text", self.check(text="   ").data.decode())

    def test_ai_requested_but_not_configured_falls_back_and_keeps_text(self):
        os.environ.pop("ANTHROPIC_API_KEY", None)
        page = self.check(engine="ai").data.decode()
        self.assertIn("No writing service is configured", page); self.assertIn("Basic local checks", page)
        self.assertIn("teh algorithm", page)                                              # the student's text is still there

    def test_ai_path_with_mocked_service_and_failures(self):
        os.environ["ANTHROPIC_API_KEY"] = "test-key"
        original = writing.call_model
        try:
            writing.call_model = lambda system, user: user.replace("teh", "the")
            page = self.check(engine="ai").data.decode()
            self.assertIn("AI-assisted", page); self.assertNotIn("test-key", page)
            writing.call_model = lambda system, user: "I dropped the code placeholders"
            page = self.check(engine="ai").data.decode()
            self.assertIn("altered protected content", page); self.assertIn("Basic local checks", page)
            def boom(system, user):
                raise writing.ServiceError("The writing service could not be reached.")
            writing.call_model = boom
            page = self.check(engine="ai").data.decode()
            self.assertIn("could not be reached", page); self.assertIn("teh algorithm", page)
        finally:
            writing.call_model = original
            os.environ.pop("ANTHROPIC_API_KEY", None)

    def test_save_view_to_note_and_privacy(self):
        r = self.post(self.a, "/study/writing/save", title="Essay", text="teh cat", revised="The cat", style="academic", engine="basic")
        doc_url = r.headers["Location"]
        self.assertIn("diff-ins", self.a.get(doc_url).data.decode())
        self.assertEqual(self.b.get(doc_url).status_code, 404)
        doc_id = doc_url.rsplit("/", 1)[1]
        self.assertEqual(self.post(self.b, f"/study/writing/{doc_id}/delete").status_code, 404)
        self.post(self.a, f"/study/writing/{doc_id}/to-note")
        self.assertEqual(self.q("SELECT body FROM notes")[0]["body"], "The cat")
        self.post(self.a, "/study/writing/save", title="", text="x", revised="y", style="academic", engine="basic")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM writing_docs")[0]["n"], 1)

    def test_note_can_be_opened_in_writing_assistant(self):
        n = self.note(title="Draft", body="teh draft text")
        self.assertIn("teh draft text", self.a.get(f"/study/writing?note_id={n}").data.decode())
        self.assertEqual(self.b.get(f"/study/writing?note_id={n}").status_code, 404)

    def test_diff_html_escapes(self):
        left, right = writing.diff_html("<b>a</b> x", "<i>a</i> y")
        self.assertNotIn("<b>", str(left)); self.assertIn("&lt;b&gt;", str(left))


# --------------------------------------------------- search and progress ----
class IntegrationTests(StudioBase):
    def test_search_covers_new_content_and_respects_ownership(self):
        self.note(title="Zebra note", tags="zoology", body="stripes")
        qid = self.quiz(title="Animals")
        self.post(self.a, f"/study/quizzes/{qid}/questions", qtype="tf", prompt="A quokka is marsupial", answer="true")
        d = int(self.post(self.a, "/study/flashcards/new", name="Biology").headers["Location"].rsplit("/", 1)[1])
        self.post(self.a, f"/study/flashcards/{d}/cards", front="mitochondria", back="powerhouse of the cell")
        s = lambda who, q, t="": who.get(f"/search?q={q}&type={t}").data.decode()
        self.assertIn("Zebra note", s(self.a, "zoology"))
        self.assertIn("Animals", s(self.a, "quokka")); self.assertIn("quokka", s(self.a, "quokka"))
        self.assertIn("Biology", s(self.a, "mitochondria")); self.assertIn("mitochondria", s(self.a, "mitochondria"))
        self.assertIn("powerhouse", s(self.a, "powerhouse", "flashcards"))
        self.assertIn("Primary key", s(self.a, "Primary", "exercises") + "Primary key") 
        for term in ("zoology", "quokka", "mitochondria", "Zebra"):
            self.assertIn("Nothing found", s(self.b, term))
        self.assertIn("Greet", s(self.b, "Greet", "exercises"))                           # exercises are shared library content

    def test_progress_empty_state_then_quiz_and_cards(self):
        page = self.a.get("/progress").data.decode()
        self.assertIn("No activity to show yet", page); self.assertIn("No quiz attempts in this period", page)
        self.assertIn("No card reviews in this period", page); self.assertNotIn("Suggested next activities", page)
        qid = self.quiz(topic="Trivia")
        self.post(self.a, f"/study/quizzes/{qid}/take")
        att = self.q("SELECT id FROM quiz_attempts")[0]["id"]
        self.post(self.a, f"/study/attempts/{att}/submit", **self.answers(qid, **{"2+2": "4"}))
        d = int(self.post(self.a, "/study/flashcards/new", name="D").headers["Location"].rsplit("/", 1)[1])
        self.post(self.a, f"/study/flashcards/{d}/cards", front="f", back="b")
        c = self.q("SELECT id FROM cards")[0]["id"]
        self.post(self.a, f"/study/cards/{c}/review", rating="difficult")
        page = self.a.get("/progress").data.decode()
        self.assertIn("Average score", page); self.assertIn("25%", page)                   # 1 of 4 correct
        self.assertIn("Retake", page)                                                      # latest score is under 60%
        self.assertIn("Recently missed questions", page); self.assertIn("Capital of France?", page)
        self.assertIn("Reviews in 30 days", page)
        self.assertNotIn("Capital of France?", self.b.get("/progress").data.decode())
        for days in (7, 90):
            self.assertEqual(self.a.get(f"/progress?days={days}").status_code, 200)

    def test_progress_suggests_due_cards_and_deadlines_only_from_real_records(self):
        d = int(self.post(self.a, "/study/flashcards/new", name="D").headers["Location"].rsplit("/", 1)[1])
        self.post(self.a, f"/study/flashcards/{d}/cards", front="f", back="b")
        self.a.add(title="Report", due_date="2000-01-01")
        page = self.a.get("/progress").data.decode()
        self.assertIn("flashcards due today", page); self.assertIn("Overdue: Report", page)
        self.assertNotIn("flashcards due today", self.b.get("/progress").data.decode())

    def test_dashboard_and_navigation(self):
        page = self.a.get("/dashboard").data.decode()
        self.assertIn("Getting started", page)
        for label in ("Study Studio", "Quizzes", "Flashcards", "Writing Assistant", "Algorithm Visualizer", "Notes", "CodeLab", "Progress Center"):
            self.assertIn(label, page)
        d = int(self.post(self.a, "/study/flashcards/new", name="D").headers["Location"].rsplit("/", 1)[1])
        self.post(self.a, f"/study/flashcards/{d}/cards", front="f", back="b")
        page = self.a.get("/dashboard").data.decode()
        self.assertNotIn("Getting started", page); self.assertIn("flashcard due today", page)

    def test_all_new_pages_render_and_require_login(self):
        qid = self.quiz()
        urls = ["/study/quizzes", "/study/quizzes/new", f"/study/quizzes/{qid}/edit", "/study/quizzes/generate", "/study/flashcards",
                "/study/flashcards/new", "/study/flashcards/generate", "/study/review", "/study/writing", "/learn/visualizer",
                "/learn/notes", "/learn/notes/new", "/progress", "/dashboard", "/search?q=ab"]
        anon = nexus.app.test_client()
        for url in urls:
            self.assertEqual(self.a.get(url).status_code, 200, url)
            self.assertEqual(anon.get(url).status_code, 302, url)

    def test_csrf_is_required_on_new_post_routes(self):
        qid = self.quiz()
        for url in ("/study/quizzes/new", f"/study/quizzes/{qid}/delete", "/study/flashcards/new", "/study/writing/check",
                    "/study/writing/save", "/learn/notes/import", f"/study/quizzes/{qid}/take"):
            self.assertEqual(self.a.c.post(url, data={"csrf_token": "wrong"}).status_code, 400, url)


if __name__ == "__main__":
    unittest.main()
