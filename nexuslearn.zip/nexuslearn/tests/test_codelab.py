import glob
import os
import shutil
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
import codelab  # noqa: E402
from test_tasks import Client  # noqa: E402

SECRET_PATH = os.path.join(nexus.app.instance_path, "secret_key")


class CodeLabTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.practice = tempfile.mkdtemp()
        nexus.app.config.update(DATABASE=self.path, PRACTICE_DIR=self.practice, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.a, self.b = Client("alice"), Client("bobby")
        self._old = (codelab.PY_TIMEOUT, codelab.SQL_TIMEOUT)
        codelab.PY_TIMEOUT, codelab.SQL_TIMEOUT = 2, 1

    def tearDown(self):
        codelab.PY_TIMEOUT, codelab.SQL_TIMEOUT = self._old
        os.remove(self.path)
        shutil.rmtree(self.practice, ignore_errors=True)

    def py(self, code, stdin="", who=None):
        return (who or self.a).post("/codelab/run/python", code=code, stdin=stdin).get_json()

    def sql(self, code, who=None):
        return (who or self.a).post("/codelab/run/sql", code=code).get_json()

    # ---- page ----
    def test_page_requires_login_and_preview_is_isolated(self):
        self.assertEqual(nexus.app.test_client().get("/codelab").status_code, 302)
        html = self.a.get("/codelab").data.decode()
        self.assertIn('sandbox="allow-scripts"', html)
        self.assertNotIn("allow-same-origin", html)
        self.assertNotIn("Phase 8", html)
        self.assertIn("JavaScript (.js)", html)

    # ---- python ----
    def test_hello_world(self):
        r = self.py("print('Hello')")
        self.assertEqual((r["status"], r["stdout"]), ("ok", "Hello\n"))

    def test_stdin(self):
        r = self.py("name = input('Name? ')\nprint('Hi', name)", stdin="Ada\n")
        self.assertIn("Hi Ada", r["stdout"])

    def test_runtime_error_traceback_is_clean(self):
        r = self.py("print('a')\n1/0")
        self.assertEqual((r["status"], r["stdout"]), ("error", "a\n"))
        self.assertIn("ZeroDivisionError", r["stderr"])
        self.assertIn('main.py", line 2', r["stderr"])
        self.assertNotIn("sandbox_runner", r["stderr"])

    def test_syntax_error(self):
        r = self.py("def f(:\n")
        self.assertEqual(r["status"], "error")
        self.assertIn("SyntaxError", r["stderr"])

    def test_timeout(self):
        r = self.py("while True: pass")
        self.assertEqual(r["status"], "timeout")

    def test_output_limit(self):
        r = self.py("while True: print('x' * 1000)")
        self.assertEqual(r["status"], "output_limit")
        self.assertLessEqual(len(r["stdout"]), codelab.MAX_OUTPUT)

    def test_memory_limit(self):
        r = self.py("x = bytearray(2 * 1024 ** 3)")
        self.assertEqual(r["status"], "error")
        self.assertIn("MemoryError", r["stderr"])

    def test_sandbox_blocks_dangerous_operations(self):
        escape = "/tmp/nl_escape_test.txt"
        if os.path.exists(escape):
            os.remove(escape)
        attacks = {
            "network": "import socket\nsocket.socket().connect(('1.1.1.1', 80))",
            "subprocess": "import subprocess\nsubprocess.run(['ls'])",
            "os.system": "import os\nos.system('echo hi')",
            "fork": "import os\nos.fork()",
            "read secret key": f"print(open({SECRET_PATH!r}).read())",
            "read app database": f"print(open({nexus.app.config['DATABASE']!r}, 'rb').read(10))",
            "read /etc/passwd": "print(open('/etc/passwd').read())",
            "write outside": f"open({escape!r}, 'w').write('x')",
            "list project": f"import os\nprint(os.listdir({codelab.PROJECT_DIR!r}))",
            "ctypes": "import ctypes",
        }
        for name, code in attacks.items():
            r = self.py(code)
            self.assertEqual(r["status"], "error", name)
            self.assertIn("PermissionError", r["stderr"] + r["stdout"], name)
        self.assertFalse(os.path.exists(escape))

    def test_secret_key_never_leaks(self):
        with open(SECRET_PATH) as f:
            secret = f.read().strip()
        with mock.patch.dict(os.environ, {"SECRET_KEY": "topsecret-from-env"}):
            r = self.py("import os\nprint(sorted(os.environ))\nprint(os.environ.get('SECRET_KEY'))")
        self.assertNotIn("topsecret-from-env", r["stdout"])
        self.assertNotIn(secret, r["stdout"] + r["stderr"])
        self.assertIn("None", r["stdout"])

    def test_file_io_inside_sandbox_works(self):
        r = self.py("with open('notes.txt', 'w') as f:\n    f.write('hi')\nprint(open('notes.txt').read())")
        self.assertEqual((r["status"], r["stdout"]), ("ok", "hi\n"))

    def test_temp_dirs_cleaned_up(self):
        pattern = os.path.join(tempfile.gettempdir(), "nexuslearn_run_*")
        before = len(glob.glob(pattern))
        self.py("print(1)")
        self.py("while True: pass")
        self.assertEqual(len(glob.glob(pattern)), before)

    def test_input_validation(self):
        self.assertEqual(self.a.post("/codelab/run/python", code="   ").status_code, 400)
        self.assertEqual(self.a.post("/codelab/run/python", code="x" * (codelab.MAX_CODE + 1)).status_code, 400)

    def test_unknown_languages_have_no_route(self):
        for lang in ("ruby", "rust", "php"):
            self.assertEqual(self.a.post(f"/codelab/run/{lang}", code="x").status_code, 404)

    # ---- sql ----
    def test_select(self):
        r = self.sql("SELECT name FROM students ORDER BY id LIMIT 2;")
        self.assertEqual(r["status"], "ok")
        self.assertEqual(r["results"][0]["columns"], ["name"])
        self.assertEqual(len(r["results"][0]["rows"]), 2)

    def test_changes_persist_across_runs(self):
        self.sql("INSERT INTO students (name, major, year, gpa) VALUES ('Zed', 'CS', 1, 3.0);")
        r = self.sql("SELECT COUNT(*) FROM students;")
        self.assertEqual(r["results"][0]["rows"][0][0], 9)

    def test_users_have_isolated_databases(self):
        self.sql("CREATE TABLE only_alice (x INTEGER);")
        self.assertEqual(self.sql("SELECT * FROM only_alice;")["status"], "ok")
        self.assertEqual(self.sql("SELECT * FROM only_alice;", who=self.b)["status"], "error")

    def test_main_database_not_reachable(self):
        self.assertIn("no such table", self.sql("SELECT * FROM users;")["error"])
        self.assertEqual(self.sql(f"ATTACH DATABASE '{self.path}' AS x;")["status"], "error")

    def test_reset_restores_sample_data(self):
        self.sql("DELETE FROM enrollments; DELETE FROM students;")
        self.assertEqual(self.sql("SELECT COUNT(*) FROM students;")["results"][0]["rows"][0][0], 0)
        self.assertEqual(self.a.post("/codelab/sql/reset").get_json()["status"], "ok")
        self.assertEqual(self.sql("SELECT COUNT(*) FROM students;")["results"][0]["rows"][0][0], 8)

    def test_failed_script_is_rolled_back(self):
        r = self.sql("DELETE FROM enrollments; SELECT * FROM no_such_table;")
        self.assertEqual((r["status"], r["failed_statement"]), ("error", 2))
        self.assertEqual(self.sql("SELECT COUNT(*) FROM enrollments;")["results"][0]["rows"][0][0], 15)

    def test_error_reporting_and_multiple_results(self):
        self.assertEqual(self.sql("SELEC 1;")["status"], "error")
        r = self.sql("SELECT 1 AS a; SELECT 2 AS b;")
        self.assertEqual(len(r["results"]), 2)

    def test_dangerous_sql_blocked(self):
        for stmt in ("VACUUM INTO '/tmp/nl_vacuum_test.db';", "/* hi */ vacuum;",
                     "PRAGMA journal_mode = OFF;", "SELECT load_extension('x');"):
            self.assertEqual(self.sql(stmt)["status"], "error", stmt)
        self.assertFalse(os.path.exists("/tmp/nl_vacuum_test.db"))
        self.assertEqual(self.sql("PRAGMA table_info(students);")["status"], "ok")

    def test_sql_timeout_and_row_cap(self):
        r = self.sql("WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c) SELECT COUNT(*) FROM c;")
        self.assertEqual(r["status"], "error")
        self.assertIn("longer than", r["error"])
        r = self.sql("WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c WHERE x < 1000) SELECT x FROM c;")
        self.assertEqual((len(r["results"][0]["rows"]), r["results"][0]["truncated"]), (200, True))


if __name__ == "__main__":
    unittest.main()
