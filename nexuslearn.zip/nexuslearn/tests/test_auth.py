import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402


class AuthTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        nexus.app.config.update(DATABASE=self.path, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.c = nexus.app.test_client()
        self.token()

    def tearDown(self):
        os.remove(self.path)

    def token(self):
        with self.c.session_transaction() as s:
            s["csrf_token"] = "t"

    def post(self, url, **data):
        data["csrf_token"] = "t"
        return self.c.post(url, data=data, follow_redirects=True)

    def register(self, u="alice", p="password1", conf=None):
        return self.post("/register", username=u, password=p, confirmation=conf or p)

    def logout(self):
        self.token()  # session.clear() on login/register wipes the CSRF token
        self.c.post("/logout", data={"csrf_token": "t"})
        self.token()

    def test_register_ok_and_reaches_dashboard(self):
        self.assertIn(b"Dashboard", self.register().data)

    def test_register_rejects_bad_input(self):
        self.assertIn(b"3-30 characters", self.register(u="a!").data)
        self.assertIn(b"at least 8", self.register(p="short").data)
        self.assertIn(b"do not match", self.register(conf="different1").data)

    def test_duplicate_username_case_insensitive(self):
        self.register()
        self.logout()
        self.assertIn(b"already taken", self.register(u="ALICE").data)

    def test_password_is_hashed(self):
        self.register()
        with nexus.app.app_context():
            h = nexus.get_db().execute("SELECT password_hash FROM users").fetchone()[0]
        self.assertNotIn("password1", h)

    def test_login_wrong_and_right(self):
        self.register()
        self.logout()
        self.assertIn(b"Invalid username", self.post("/login", username="alice", password="nope").data)
        self.assertIn(b"Dashboard", self.post("/login", username="alice", password="password1").data)

    def test_logout_clears_session(self):
        self.register()
        self.logout()
        r = self.c.get("/dashboard")
        self.assertEqual(r.status_code, 302)

    def test_dashboard_requires_login(self):
        r = self.c.get("/dashboard")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/login", r.headers["Location"])

    def test_csrf_enforced(self):
        r = self.c.post("/login", data={"username": "a", "password": "b", "csrf_token": "wrong"})
        self.assertEqual(r.status_code, 400)

    def test_open_redirect_blocked(self):
        self.register()
        self.logout()
        r = self.c.post("/login?next=//evil.com",
                        data={"username": "alice", "password": "password1", "csrf_token": "t"})
        self.assertNotIn("evil.com", r.headers["Location"])


if __name__ == "__main__":
    unittest.main()
