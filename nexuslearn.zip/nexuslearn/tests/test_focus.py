import os
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as nexus  # noqa: E402
import focus  # noqa: E402
from test_tasks import Client  # noqa: E402

T0 = 1_800_000_000.0  # a fixed "now": 2027-01-15 08:00:00 UTC


class FocusBase(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        nexus.app.config.update(DATABASE=self.path, TESTING=True)
        with nexus.app.app_context():
            nexus.init_db()
        self.now = T0
        patcher = mock.patch("focus.clock", lambda: self.now)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.a, self.b = Client("alice"), Client("bobby")

    def tearDown(self):
        os.remove(self.path)

    def q(self, sql, *args):
        with nexus.app.app_context():
            return nexus.get_db().execute(sql, args).fetchall()

    def rows(self, who="alice"):
        return self.q("SELECT * FROM focus_sessions WHERE user_id = (SELECT id FROM users WHERE username = ?)", who)

    def start(self, who=None, **kw):
        kw.setdefault("kind", "focus")
        r = (who or self.a).post("/focus/start", **kw)
        return r.status_code, r.get_json()

    def call(self, name, who=None):
        r = (who or self.a).post(f"/focus/{name}")
        return r.status_code, r.get_json()

    def advance(self, seconds):
        self.now += seconds

    def totals(self, who="alice", tz=0):
        uid = self.q("SELECT id FROM users WHERE username = ?", who)[0]["id"]
        with nexus.app.app_context():
            return focus.summaries(nexus.get_db(), uid, self.now, tz)


class TimerTests(FocusBase):
    def test_start_and_countdown(self):
        code, s = self.start(minutes="25", subject="CS50")
        self.assertEqual(code, 201)
        self.assertEqual((s["active"]["status"], s["active"]["planned_seconds"], s["active"]["subject"]), ("running", 1500, "CS50"))
        self.advance(100)
        s = self.a.get("/focus/state").get_json()
        self.assertAlmostEqual(s["active"]["remaining_seconds"], 1400, delta=0.5)

    def test_defaults_come_from_user_settings(self):
        _, s = self.start()
        self.assertEqual(s["active"]["planned_seconds"], 25 * 60)
        self.call("reset")
        _, s = self.start(kind="break")
        self.assertEqual(s["active"]["planned_seconds"], 5 * 60)

    def test_repeated_start_never_duplicates(self):
        self.start(minutes="25")
        code, s = self.start(minutes="50")
        self.assertEqual((code, s.get("already_active")), (200, True))
        self.assertEqual(s["active"]["planned_seconds"], 1500)  # the first one wins
        self.assertEqual(len(self.rows()), 1)

    def test_database_refuses_a_second_active_session(self):
        self.start()
        uid = self.q("SELECT id FROM users WHERE username = 'alice'")[0]["id"]
        with nexus.app.app_context():
            db = nexus.get_db()
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("INSERT INTO focus_sessions (user_id, kind, planned_seconds, started_at) "
                           "VALUES (?, 'focus', 600, '2027-01-15 08:00:00')", (uid,))

    def test_validation(self):
        for bad in ({"minutes": "0"}, {"minutes": "181"}, {"minutes": "abc"}, {"minutes": "-5"},
                    {"kind": "nap"}, {"subject": "x" * 61}, {"task_id": "999"}, {"project_id": "abc"}):
            code, s = self.start(**bad)
            self.assertEqual(code, 400, bad)
            self.assertIn("error", s)
        self.assertEqual(len(self.rows()), 0)
        self.assertEqual(self.start(kind="break", minutes="61")[0], 400)

    def test_cannot_link_other_users_task_or_project(self):
        tid = self.b.add(title="Bobs")
        self.assertEqual(self.start(task_id=str(tid))[0], 400)
        r = self.b.post("/projects/new", name="BP", language="python")
        pid = r.headers["Location"].rsplit("/", 1)[1]
        self.assertEqual(self.start(project_id=pid)[0], 400)

    def test_links_are_recorded_and_shown(self):
        tid = self.a.add(title="Essay draft", subject="English")
        self.start(minutes="1", task_id=str(tid), subject="English")
        self.advance(60)
        self.a.get("/focus/state")
        page = self.a.get("/focus").data.decode()
        self.assertIn("Essay draft", page)
        self.assertEqual(self.rows()[0]["task_id"], tid)

    def test_pause_and_resume_accounting(self):
        self.start(minutes="25")
        self.advance(100)
        code, s = self.call("pause")
        self.assertEqual(s["active"]["status"], "paused")
        self.advance(5000)                      # a long pause must not use up time
        s = self.a.get("/focus/state").get_json()
        self.assertEqual(s["active"]["status"], "paused")
        self.assertAlmostEqual(s["active"]["remaining_seconds"], 1400, delta=0.5)
        self.call("resume")
        self.advance(1399)
        self.assertIsNone(self.a.get("/focus/state").get_json()["completed"])
        self.advance(2)
        s = self.a.get("/focus/state").get_json()
        self.assertEqual((s["active"], s["completed"]["duration_seconds"]), (None, 1500))

    def test_pause_resume_are_idempotent(self):
        self.start(minutes="25")
        self.advance(50)
        self.call("pause"); self.advance(10); self.call("pause")
        self.assertAlmostEqual(self.rows()[0]["accumulated_seconds"], 50, delta=0.01)
        self.call("resume"); self.call("resume")
        self.assertEqual(self.rows()[0]["status"], "running")

    def test_completion_is_recorded_exactly_once(self):
        self.start(minutes="1")
        self.advance(61)
        for _ in range(3):                       # refreshes / duplicate requests
            self.a.get("/focus/state")
            self.a.get("/focus")
        done = [r for r in self.rows() if r["status"] == "completed"]
        self.assertEqual((len(self.rows()), len(done), done[0]["duration_seconds"]), (1, 1, 60))

    def test_returning_late_caps_duration_and_dates_session_correctly(self):
        self.start(minutes="25")
        self.advance(10_000)                     # tab was closed for hours
        s = self.a.get("/focus/state").get_json()
        self.assertEqual(s["completed"]["duration_seconds"], 1500)
        row = self.rows()[0]
        self.assertEqual(row["ended_at"], focus.utc_str(T0 + 1500))

    def test_finish_early(self):
        self.start(minutes="25")
        self.advance(30)
        self.assertEqual(self.call("finish")[0], 400)           # under a minute
        self.advance(570)
        code, s = self.call("finish")
        row = self.rows()[0]
        self.assertEqual((code, row["status"], row["duration_seconds"], row["finished_early"]), (200, "completed", 600, 1))
        self.assertEqual(s["completed"]["duration_seconds"], 600)
        self.call("finish")                                     # repeat: no second record
        self.assertEqual(len(self.rows()), 1)

    def test_finish_while_paused_uses_time_before_pause(self):
        self.start(minutes="25")
        self.advance(300); self.call("pause"); self.advance(9999)
        self.call("finish")
        self.assertEqual(self.rows()[0]["duration_seconds"], 300)

    def test_reset_discards_and_records_nothing(self):
        self.start(minutes="25")
        self.advance(900)
        _, s = self.call("reset")
        self.assertIsNone(s["active"])
        self.assertEqual(len(self.rows()), 0)
        self.assertEqual(self.call("reset")[0], 200)            # repeat is harmless

    def test_reset_after_time_ran_out_keeps_the_completed_session(self):
        self.start(minutes="1")
        self.advance(120)
        self.call("reset")
        self.assertEqual([r["status"] for r in self.rows()], ["completed"])

    def test_breaks_do_not_count_as_study_time(self):
        self.start(kind="break", minutes="5")
        self.advance(300); self.a.get("/focus/state")
        self.assertEqual(self.totals()["total_seconds"], 0)
        self.assertEqual(self.call("finish")[0], 200)  # nothing active: no-op
        self.start(kind="break", minutes="5")
        self.assertEqual(self.call("finish")[0], 400)  # cannot "finish early" a break

    def test_long_break_suggestion(self):
        self.a.post("/focus/settings", focus_minutes="25", break_minutes="5", long_break_minutes="15", long_break_every="2")
        for _ in range(2):
            self.start(minutes="1"); self.advance(61); self.a.get("/focus/state")
        self.assertEqual(self.a.get("/focus/state").get_json()["next_break"], "long_break")
        self.start(minutes="1"); self.advance(61)
        self.assertEqual(self.a.get("/focus/state").get_json()["next_break"], "break")
        self.a.post("/focus/settings", focus_minutes="25", break_minutes="5", long_break_minutes="15", long_break_every="0")
        self.assertNotIn(b"start-long", self.a.get("/focus").data)

    def test_settings_validation(self):
        base = dict(focus_minutes="30", break_minutes="7", long_break_minutes="20", long_break_every="3")
        self.a.post("/focus/settings", **base)
        row = self.q("SELECT focus_minutes, break_minutes, long_break_minutes, long_break_every FROM users WHERE username='alice'")[0]
        self.assertEqual(tuple(row), (30, 7, 20, 3))
        for field, bad in (("focus_minutes", "0"), ("focus_minutes", "999"), ("break_minutes", "x"),
                           ("long_break_every", "11"), ("long_break_minutes", "")):
            self.a.post("/focus/settings", **{**base, field: bad, "focus_minutes": "45" if field != "focus_minutes" else bad})
        row = self.q("SELECT focus_minutes FROM users WHERE username='alice'")[0]
        self.assertEqual(row["focus_minutes"], 30)


class SummaryTests(FocusBase):
    def complete(self, minutes=25, **kw):
        self.start(minutes=str(minutes), **kw)
        self.advance(minutes * 60 + 1)
        self.a.get("/focus/state")

    def test_today_week_total_and_dashboard(self):
        self.complete(25, subject="Math")
        self.advance(3600); self.complete(10, subject="CS50")
        s = self.totals()
        self.assertEqual((s["today_seconds"], s["week_seconds"], s["total_seconds"], s["sessions_today"]), (2100, 2100, 2100, 2))
        self.assertEqual({r["subject"]: r["seconds"] for r in s["by_subject"]}, {"Math": 1500, "CS50": 600})
        html = self.a.get("/dashboard").data.decode()
        self.assertIn("35 min", html)

    def test_other_users_data_is_separate(self):
        self.complete(25)
        self.assertEqual(self.totals("bobby")["total_seconds"], 0)
        self.assertNotIn(b"35 min", self.b.get("/dashboard").data)

    def test_days_and_weeks_use_the_browser_time_zone(self):
        # T0 = Fri 2027-01-15 08:00 UTC. Session ends 23:30 UTC on Fri.
        self.now = T0 + 15.5 * 3600 - 1500 - 1
        self.complete(25)                          # ended ~23:30 UTC Friday
        self.now = T0 + 16 * 3600                  # query at 00:00 UTC Saturday
        self.assertEqual(self.totals(tz=0)["today_seconds"], 0)      # UTC: Saturday has none yet
        self.assertEqual(self.totals(tz=0)["week_seconds"], 1500)
        self.assertEqual(self.totals(tz=-120)["today_seconds"], 1500)  # UTC+2: 01:30 Saturday... session counts today
        self.a.c.set_cookie("tz_offset", "-120")
        self.assertIn(b"25 min", self.a.get("/dashboard").data)

    def test_week_resets_on_monday(self):
        self.complete(25)                          # Friday
        self.now += 3 * 86400                      # Monday 2027-01-18 08:00 UTC
        s = self.totals()
        self.assertEqual((s["today_seconds"], s["week_seconds"], s["total_seconds"]), (0, 0, 1500))

    def test_seven_day_bars(self):
        self.complete(30)
        days = self.totals()["days"]
        self.assertEqual(len(days), 7)
        self.assertEqual((days[-1]["seconds"], days[-1]["pct"], days[0]["pct"]), (1800, 100, 0))


class PageAndAccessTests(FocusBase):
    def test_page_renders_empty_state(self):
        page = self.a.get("/focus").data.decode()
        self.assertIn("No completed sessions yet", page)
        self.assertIn("Start a focus session", page)

    def test_page_after_refresh_still_shows_running_session(self):
        self.start(minutes="25", subject="CS50")
        self.advance(60)
        page = self.a.get("/focus").data.decode()
        self.assertIn('"status": "running"', page.replace('"status":"running"', '"status": "running"'))
        self.assertEqual(len(self.rows()), 1)

    def test_login_required(self):
        anon = nexus.app.test_client()
        with anon.session_transaction() as s:
            s["csrf_token"] = "t"
        self.assertEqual(anon.get("/focus").status_code, 302)
        self.assertEqual(anon.get("/focus/state").status_code, 302)
        for name in ("start", "pause", "resume", "finish", "reset", "settings"):
            self.assertEqual(anon.post(f"/focus/{name}", data={"csrf_token": "t"}).status_code, 302, name)

    def test_csrf_enforced(self):
        r = self.a.c.post("/focus/start", data={"kind": "focus", "csrf_token": "wrong"})
        self.assertEqual(r.status_code, 400)

    def test_users_cannot_affect_each_others_timers(self):
        self.start(minutes="25")
        self.start(who=self.b, minutes="10")
        self.advance(60)
        self.call("pause", who=self.b)
        self.call("reset", who=self.b)
        a = self.a.get("/focus/state").get_json()["active"]
        self.assertEqual((a["status"], a["planned_seconds"]), ("running", 1500))
        self.assertIsNone(self.b.get("/focus/state").get_json()["active"])

    def test_deleting_linked_task_keeps_history(self):
        tid = self.a.add(title="Temp")
        self.start(minutes="1", task_id=str(tid)); self.advance(61); self.a.get("/focus/state")
        self.a.post(f"/tasks/{tid}/delete")
        self.assertEqual(len(self.rows()), 1)
        self.assertIsNone(self.rows()[0]["task_id"])
        self.assertEqual(self.a.get("/focus").status_code, 200)


class MigrationTests(unittest.TestCase):
    def test_old_database_gets_new_columns_and_keeps_data(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            conn = sqlite3.connect(path)
            conn.executescript("""CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL, theme TEXT NOT NULL DEFAULT 'dark', default_language TEXT NOT NULL DEFAULT 'python',
                focus_minutes INTEGER NOT NULL DEFAULT 25, break_minutes INTEGER NOT NULL DEFAULT 5, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
                INSERT INTO users (username, password_hash) VALUES ('olduser', 'x');""")
            conn.close()
            nexus.app.config.update(DATABASE=path)
            with nexus.app.app_context():
                nexus.init_db()
                nexus.init_db()   # running twice is safe
                row = nexus.get_db().execute("SELECT username, long_break_minutes, long_break_every FROM users").fetchone()
            self.assertEqual(tuple(row), ("olduser", 15, 4))
        finally:
            os.remove(path)


if __name__ == "__main__":
    unittest.main()
