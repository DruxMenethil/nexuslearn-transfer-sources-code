import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from test_projects import Base  # noqa: E402


class SnippetTests(Base):
    def add(self, who=None, **kw):
        kw.setdefault("title", "Snip")
        kw.setdefault("language", "python")
        kw.setdefault("code", "print(1)")
        r = (who or self.a).post("/snippets/new", **kw)
        if r.status_code != 302:
            return None
        return self.q("SELECT MAX(id) AS i FROM code_snippets")[0]["i"]

    def test_create_and_tag_normalization(self):
        sid = self.add(tags="Loops,  String Tools, loops, c++")
        self.assertEqual(self.q("SELECT tags FROM code_snippets WHERE id = ?", sid)[0]["tags"], "loops,string-tools,c++")

    def test_validation(self):
        for bad in ({"title": ""}, {"title": "x" * 81}, {"language": "cobol"}, {"code": "  "},
                    {"code": "x" * 20_001}, {"tags": "a,b,c,d,e,f,g,h,i"}, {"tags": "bad!tag"}):
            self.assertIsNone(self.add(**bad), bad)
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM code_snippets")[0]["n"], 0)

    def test_search_filter_tag(self):
        self.add(title="Reverse list", tags="lists", code="x[::-1]")
        self.add(title="Join tables", language="sql", tags="joins", code="SELECT 1")
        page = lambda qs: self.a.get("/snippets?" + qs).data
        self.assertIn(b"Reverse list", page("q=reverse"))
        self.assertIn(b"Reverse list", page("q=%3A%3A-1"))      # matches code text
        self.assertNotIn(b"Join tables", page("language=python"))
        self.assertIn(b"Join tables", page("tag=joins"))
        self.assertNotIn(b"Reverse list", page("tag=joins"))
        self.assertNotIn(b"Reverse list", page("tag=join"))     # exact tag match, not substring
        self.assertNotIn(b"Reverse list", page("q=%25"))

    def test_edit_and_delete(self):
        sid = self.add(title="Old")
        self.a.post(f"/snippets/{sid}/edit", title="New", language="python", code="print(2)", tags="", description="")
        self.assertEqual(self.q("SELECT title, code FROM code_snippets WHERE id = ?", sid)[0]["title"], "New")
        self.a.post(f"/snippets/{sid}/delete")
        self.assertEqual(self.q("SELECT COUNT(*) AS n FROM code_snippets")[0]["n"], 0)

    def test_private_to_owner(self):
        sid = self.add(title="Mine only", code="secret_code()")
        self.assertNotIn(b"Mine only", self.b.get("/snippets").data)
        self.assertEqual(self.b.get(f"/snippets/{sid}/edit").status_code, 404)
        self.assertEqual(self.b.post(f"/snippets/{sid}/edit", title="x", language="python", code="HACK").status_code, 404)
        self.assertEqual(self.b.post(f"/snippets/{sid}/delete").status_code, 404)
        self.assertEqual(self.b.get(f"/codelab?snippet={sid}").status_code, 404)
        self.assertEqual(self.q("SELECT code FROM code_snippets WHERE id = ?", sid)[0]["code"], "secret_code()")

    def test_output_is_escaped(self):
        self.add(title="<script>alert(1)</script>", code="<img src=x onerror=alert(2)>")
        html = self.a.get("/snippets").data.decode()
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertNotIn("<img src=x", html)

    def test_open_in_codelab(self):
        py = self.add(title="PySnip", language="python", code="print('open me')")
        cc = self.add(title="CSnip", language="c", code="int main(){}")
        page = self.a.get("/snippets").data.decode()
        self.assertIn(f"snippet={py}", page)
        self.assertNotIn(f"snippet={cc}", page)  # C cannot run yet, so no Open button
        self.assertIn("open me", self.a.get(f"/codelab?snippet={py}").data.decode())

    def test_from_codelab(self):
        r = self.a.post("/snippets/from-codelab", title="Saved", language="sql", code="SELECT 1;", tags="x")
        self.assertEqual(r.status_code, 201)
        self.assertEqual(self.a.post("/snippets/from-codelab", title="", language="sql", code="x").status_code, 400)


if __name__ == "__main__":
    unittest.main()
