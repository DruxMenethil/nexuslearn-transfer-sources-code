-- NexusLearn schema (Phase 1 + 2 tables). Safe to run repeatedly.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    username         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash    TEXT NOT NULL,
    theme            TEXT NOT NULL DEFAULT 'dark' CHECK (theme IN ('dark', 'light')),
    default_language TEXT NOT NULL DEFAULT 'python'
                     CHECK (default_language IN ('python', 'sql', 'javascript', 'c', 'cpp', 'html')),
    focus_minutes    INTEGER NOT NULL DEFAULT 25 CHECK (focus_minutes BETWEEN 1 AND 180),
    break_minutes    INTEGER NOT NULL DEFAULT 5  CHECK (break_minutes BETWEEN 1 AND 60),
    long_break_minutes INTEGER NOT NULL DEFAULT 15 CHECK (long_break_minutes BETWEEN 1 AND 60),
    long_break_every   INTEGER NOT NULL DEFAULT 4  CHECK (long_break_every BETWEEN 0 AND 10),  -- 0 = no long breaks
    display_name       TEXT NOT NULL DEFAULT '' CHECK (length(display_name) <= 50),
    created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subjects (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name    TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 60),
    UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS tasks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id   INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title        TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 120),
    description  TEXT NOT NULL DEFAULT '',
    due_date     TEXT,  -- ISO date YYYY-MM-DD
    priority     TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed')),
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_tasks_user_status ON tasks (user_id, status);
CREATE INDEX IF NOT EXISTS idx_tasks_user_due    ON tasks (user_id, due_date);

-- Phase 4: projects, project files, snippets ---------------------------------
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id     INTEGER REFERENCES tasks(id) ON DELETE SET NULL,  -- optional linked assignment
    name        TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    description TEXT NOT NULL DEFAULT '',
    language    TEXT NOT NULL CHECK (language IN ('python', 'sql', 'html', 'javascript', 'c', 'cpp')),
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_projects_user_updated ON projects (user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_projects_task ON projects (task_id);

CREATE TABLE IF NOT EXISTS project_files (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    filename   TEXT NOT NULL CHECK (length(filename) BETWEEN 1 AND 60),
    content    TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (project_id, filename)
);

CREATE TABLE IF NOT EXISTS code_snippets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 80),
    description TEXT NOT NULL DEFAULT '',
    language    TEXT NOT NULL CHECK (language IN ('python', 'sql', 'html', 'css', 'javascript', 'c', 'cpp')),
    code        TEXT NOT NULL,
    tags        TEXT NOT NULL DEFAULT '',  -- normalized, comma-separated: "loops,python"
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_snippets_user_updated ON code_snippets (user_id, updated_at);

-- Phase 5: focus timer ------------------------------------------------------
-- The server owns the clock. A session is 'running' (resumed_at = epoch seconds),
-- 'paused', or 'completed'. Reset deletes the row. Study time counts only
-- completed sessions with kind = 'focus'.
CREATE TABLE IF NOT EXISTS focus_sessions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind                TEXT NOT NULL CHECK (kind IN ('focus', 'break', 'long_break')),
    status              TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'paused', 'completed')),
    planned_seconds     INTEGER NOT NULL CHECK (planned_seconds BETWEEN 60 AND 10800),
    accumulated_seconds REAL NOT NULL DEFAULT 0,   -- time used before the current run
    resumed_at          REAL,                      -- epoch seconds, only while running
    duration_seconds    INTEGER,                   -- final length, set on completion
    finished_early      INTEGER NOT NULL DEFAULT 0,
    subject_id          INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    task_id             INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    project_id          INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    started_at          TEXT NOT NULL,             -- UTC 'YYYY-MM-DD HH:MM:SS'
    ended_at            TEXT                       -- UTC, set on completion
);
-- At most ONE unfinished session per user: duplicate "start" requests cannot create a second one.
CREATE UNIQUE INDEX IF NOT EXISTS uq_focus_active ON focus_sessions (user_id) WHERE status IN ('running', 'paused');
CREATE INDEX IF NOT EXISTS idx_focus_user_ended ON focus_sessions (user_id, kind, status, ended_at);

-- Phase 6: Learning Hub -----------------------------------------------------
-- Exercises are built-in content (seeded from exercises_data.py), shared by all users.
-- `solution` is never shown to students; it is used to compute expected SQL results.
CREATE TABLE IF NOT EXISTS exercises (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    slug         TEXT NOT NULL UNIQUE,
    title        TEXT NOT NULL,
    language     TEXT NOT NULL CHECK (language IN ('python', 'sql')),
    topic        TEXT NOT NULL,
    difficulty   TEXT NOT NULL CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
    instructions TEXT NOT NULL,
    starter_code TEXT NOT NULL DEFAULT '',
    hints        TEXT NOT NULL DEFAULT '[]',   -- JSON list of strings
    tests        TEXT NOT NULL DEFAULT '[]',   -- JSON list of test cases
    solution     TEXT NOT NULL DEFAULT '',
    position     INTEGER NOT NULL DEFAULT 0
);

-- Every graded submission. An exercise is "completed" for a user once any attempt has passed = 1;
-- the completion time is the earliest such attempt.
CREATE TABLE IF NOT EXISTS exercise_attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    exercise_id  INTEGER NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
    code         TEXT NOT NULL,
    passed       INTEGER NOT NULL CHECK (passed IN (0, 1)),
    tests_passed INTEGER NOT NULL,
    tests_total  INTEGER NOT NULL,
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_attempts_user_exercise ON exercise_attempts (user_id, exercise_id, created_at);

CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 100),
    topic      TEXT NOT NULL DEFAULT '',
    body       TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_notes_user_updated ON notes (user_id, updated_at);

-- Study Studio (Stage 2) -----------------------------------------------------
-- Extra note columns (folder, tags, favorite, task_id, project_id) are added to older
-- databases by helpers.init_db() with ALTER TABLE, so no student data is ever dropped.

-- Original uploaded documents. Files live in instance/uploads/<user_id>/ (never under static/).
CREATE TABLE IF NOT EXISTS note_documents (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    note_id        INTEGER REFERENCES notes(id) ON DELETE SET NULL,
    original_name  TEXT NOT NULL,
    stored_name    TEXT NOT NULL UNIQUE,
    kind           TEXT NOT NULL CHECK (kind IN ('txt', 'md', 'pdf', 'docx')),
    size_bytes     INTEGER NOT NULL,
    created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_docs_user ON note_documents (user_id, created_at);

CREATE TABLE IF NOT EXISTS quizzes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title         TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 100),
    description   TEXT NOT NULL DEFAULT '',
    subject       TEXT NOT NULL DEFAULT '',
    topic         TEXT NOT NULL DEFAULT '',
    difficulty    TEXT NOT NULL DEFAULT 'beginner' CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
    status        TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
    time_limit_minutes INTEGER CHECK (time_limit_minutes IS NULL OR time_limit_minutes BETWEEN 1 AND 240),
    source        TEXT NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'template', 'ai')),
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_quizzes_user ON quizzes (user_id, updated_at);

CREATE TABLE IF NOT EXISTS quiz_notes (
    quiz_id INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    note_id INTEGER NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
    PRIMARY KEY (quiz_id, note_id)
);

-- `answer` is the answer key. It is only ever sent to the browser on the owner's edit page
-- and in results after an attempt is submitted. choices is a JSON list (multiple choice only).
CREATE TABLE IF NOT EXISTS quiz_questions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id     INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    position    INTEGER NOT NULL,
    qtype       TEXT NOT NULL CHECK (qtype IN ('mcq', 'tf', 'identification', 'blank')),
    prompt      TEXT NOT NULL CHECK (length(prompt) BETWEEN 1 AND 600),
    answer      TEXT NOT NULL CHECK (length(answer) BETWEEN 1 AND 300),
    choices     TEXT NOT NULL DEFAULT '[]',
    explanation TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_qq_quiz ON quiz_questions (quiz_id, position);

CREATE TABLE IF NOT EXISTS quiz_attempts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id      INTEGER NOT NULL REFERENCES quizzes(id) ON DELETE CASCADE,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    status       TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'submitted')),
    started_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at  TEXT,
    seconds_taken INTEGER,
    score        INTEGER,   -- correct answers; counts only graded or self-marked answers
    total        INTEGER
);
CREATE INDEX IF NOT EXISTS idx_attempts_quiz_user ON quiz_attempts (user_id, quiz_id, status);
-- One unfinished attempt per quiz and user: a double click cannot start two.
CREATE UNIQUE INDEX IF NOT EXISTS uq_quiz_open_attempt ON quiz_attempts (quiz_id, user_id) WHERE status = 'in_progress';

-- Prompt and answer are copied here so history stays accurate if the quiz is edited later.
-- is_correct: 1 / 0, or NULL = waiting for the student to review their own written answer.
CREATE TABLE IF NOT EXISTS quiz_responses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    attempt_id  INTEGER NOT NULL REFERENCES quiz_attempts(id) ON DELETE CASCADE,
    question_id INTEGER REFERENCES quiz_questions(id) ON DELETE SET NULL,
    qtype       TEXT NOT NULL,
    prompt      TEXT NOT NULL,
    answer_key  TEXT NOT NULL,
    explanation TEXT NOT NULL DEFAULT '',
    response    TEXT NOT NULL DEFAULT '',
    is_correct  INTEGER CHECK (is_correct IN (0, 1)),
    UNIQUE (attempt_id, question_id)
);
CREATE INDEX IF NOT EXISTS idx_responses_attempt ON quiz_responses (attempt_id);

CREATE TABLE IF NOT EXISTS decks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    subject     TEXT NOT NULL DEFAULT '',
    topic       TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS deck_notes (
    deck_id INTEGER NOT NULL REFERENCES decks(id) ON DELETE CASCADE,
    note_id INTEGER NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
    PRIMARY KEY (deck_id, note_id)
);

-- Scheduling state lives on the card: due_date (student's local day, ISO), interval_days,
-- ease, repetitions, lapses. It only changes when the student reviews the card.
CREATE TABLE IF NOT EXISTS cards (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    deck_id       INTEGER NOT NULL REFERENCES decks(id) ON DELETE CASCADE,
    front         TEXT NOT NULL CHECK (length(front) BETWEEN 1 AND 500),
    back          TEXT NOT NULL CHECK (length(back) BETWEEN 1 AND 1000),
    example       TEXT NOT NULL DEFAULT '',
    explanation   TEXT NOT NULL DEFAULT '',
    due_date      TEXT NOT NULL,
    interval_days INTEGER NOT NULL DEFAULT 0,
    ease          REAL NOT NULL DEFAULT 2.5,
    repetitions   INTEGER NOT NULL DEFAULT 0,
    lapses        INTEGER NOT NULL DEFAULT 0,
    last_reviewed TEXT,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_cards_deck_due ON cards (deck_id, due_date);

CREATE TABLE IF NOT EXISTS card_reviews (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    card_id         INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,
    user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rating          TEXT NOT NULL CHECK (rating IN ('difficult', 'uncertain', 'easy')),
    interval_before INTEGER NOT NULL,
    interval_after  INTEGER NOT NULL,
    due_after       TEXT NOT NULL,
    reviewed_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON card_reviews (user_id, reviewed_at);

CREATE TABLE IF NOT EXISTS writing_docs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 100),
    original   TEXT NOT NULL,
    revised    TEXT NOT NULL,
    style      TEXT NOT NULL,
    engine     TEXT NOT NULL CHECK (engine IN ('basic', 'ai')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_writing_user ON writing_docs (user_id, created_at);
