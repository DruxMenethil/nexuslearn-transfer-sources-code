-- NexusLearn schema (Phase 1 + 2 tables). Safe to run repeatedly.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    username         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash    TEXT NOT NULL,
    theme            TEXT NOT NULL DEFAULT 'dark' CHECK (theme IN ('dark', 'light')),
    default_language TEXT NOT NULL DEFAULT 'python'
                     CHECK (default_language IN ('python', 'sql', 'javascript', 'c', 'cpp', 'html')),
    focus_minutes    INTEGER NOT NULL DEFAULT 25 CHECK (focus_minutes BETWEEN 1 AND 180),
    break_minutes    INTEGER NOT NULL DEFAULT 5  CHECK (break_minutes BETWEEN 1 AND 60),
    long_break_minutes INTEGER NOT NULL DEFAULT 15 CHECK (long_break_minutes BETWEEN 1 AND 60),
    long_break_every   INTEGER NOT NULL DEFAULT 4  CHECK (long_break_every BETWEEN 0 AND 10),  -- 0 = no long breaks
    created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subjects (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name    TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 60),
    UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS tasks (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject_id   INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    title        TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 120),
    description  TEXT NOT NULL DEFAULT '',
    due_date     TEXT,  -- ISO date YYYY-MM-DD
    priority     TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed')),
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_tasks_user_status ON tasks (user_id, status);
CREATE INDEX IF NOT EXISTS idx_tasks_user_due    ON tasks (user_id, due_date);

-- Phase 4: projects, project files, snippets ---------------------------------
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id     INTEGER REFERENCES tasks(id) ON DELETE SET NULL,  -- optional linked assignment
    name        TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
    description TEXT NOT NULL DEFAULT '',
    language    TEXT NOT NULL CHECK (language IN ('python', 'sql', 'html', 'javascript', 'c', 'cpp')),
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_projects_user_updated ON projects (user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_projects_task ON projects (task_id);

CREATE TABLE IF NOT EXISTS project_files (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    filename   TEXT NOT NULL CHECK (length(filename) BETWEEN 1 AND 60),
    content    TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (project_id, filename)
);

CREATE TABLE IF NOT EXISTS code_snippets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 80),
    description TEXT NOT NULL DEFAULT '',
    language    TEXT NOT NULL CHECK (language IN ('python', 'sql', 'html', 'css', 'javascript', 'c', 'cpp')),
    code        TEXT NOT NULL,
    tags        TEXT NOT NULL DEFAULT '',  -- normalized, comma-separated: "loops,python"
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_snippets_user_updated ON code_snippets (user_id, updated_at);

-- Phase 5: focus timer ------------------------------------------------------
-- The server owns the clock. A session is 'running' (resumed_at = epoch seconds),
-- 'paused', or 'completed'. Reset deletes the row. Study time counts only
-- completed sessions with kind = 'focus'.
CREATE TABLE IF NOT EXISTS focus_sessions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind                TEXT NOT NULL CHECK (kind IN ('focus', 'break', 'long_break')),
    status              TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'paused', 'completed')),
    planned_seconds     INTEGER NOT NULL CHECK (planned_seconds BETWEEN 60 AND 10800),
    accumulated_seconds REAL NOT NULL DEFAULT 0,   -- time used before the current run
    resumed_at          REAL,                      -- epoch seconds, only while running
    duration_seconds    INTEGER,                   -- final length, set on completion
    finished_early      INTEGER NOT NULL DEFAULT 0,
    subject_id          INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
    task_id             INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    project_id          INTEGER REFERENCES projects(id) ON DELETE SET NULL,
    started_at          TEXT NOT NULL,             -- UTC 'YYYY-MM-DD HH:MM:SS'
    ended_at            TEXT                       -- UTC, set on completion
);
-- At most ONE unfinished session per user: duplicate "start" requests cannot create a second one.
CREATE UNIQUE INDEX IF NOT EXISTS uq_focus_active ON focus_sessions (user_id) WHERE status IN ('running', 'paused');
CREATE INDEX IF NOT EXISTS idx_focus_user_ended ON focus_sessions (user_id, kind, status, ended_at);
