"""My Projects (Phase 4): projects, multiple files per project, link to a task.

Ownership rule: a project is reachable only through `projects.user_id = you`,
and a file only through its project, so every lookup below joins on the owner.
Not-yours and does-not-exist both return 404.
"""
import json
import os
import re

from flask import (Blueprint, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)

from helpers import get_db, login_required

bp = Blueprint("projects", __name__)

LANGUAGES = {"python": "Python", "sql": "SQL", "html": "HTML + CSS",
             "javascript": "JavaScript", "c": "C", "cpp": "C++"}
CODELAB_LANGUAGES = ("python", "sql", "html")  # the ones CodeLab can run today

STARTERS = {
    "python": {"main.py": 'print("Hello, NexusLearn!")\n'},
    "sql": {"query.sql": "SELECT * FROM students;\n"},
    "html": {
        "index.html": '<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="utf-8">\n'
                      '  <title>My page</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n'
                      "<body>\n  <h1>Hello, web!</h1>\n</body>\n</html>\n",
        "style.css": "body { font-family: system-ui, sans-serif; margin: 2rem; }\n",
    },
    "javascript": {"main.js": 'console.log("Hello, NexusLearn!");\n'},
    "c": {"main.c": '#include <stdio.h>\n\nint main(void)\n{\n    printf("Hello, NexusLearn!\\n");\n    return 0;\n}\n'},
    "cpp": {"main.cpp": '#include <iostream>\n\nint main()\n{\n    std::cout << "Hello, NexusLearn!\\n";\n    return 0;\n}\n'},
}

FILENAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,59}$")
ALLOWED_EXT = {".py", ".sql", ".html", ".css", ".js", ".c", ".h", ".cpp", ".hpp", ".txt", ".md", ".json"}
MAX_FILE_CHARS = 100_000
MAX_FILES = 30


# ------------------------------------------------------------- helpers ----
def get_owned_project(db, project_id):
    project = db.execute(
        """SELECT p.*, t.title AS task_title FROM projects p
           LEFT JOIN tasks t ON t.id = p.task_id AND t.user_id = p.user_id
           WHERE p.id = ? AND p.user_id = ?""", (project_id, session["user_id"])).fetchone()
    if project is None:
        abort(404)
    return project


def get_owned_file(db, project_id, file_id):
    f = db.execute(
        """SELECT f.* FROM project_files f JOIN projects p ON p.id = f.project_id
           WHERE f.id = ? AND f.project_id = ? AND p.user_id = ?""",
        (file_id, project_id, session["user_id"])).fetchone()
    if f is None:
        abort(404)
    return f


def user_tasks(db):
    return db.execute("""SELECT id, title FROM tasks WHERE user_id = ?
                         ORDER BY status = 'completed', due_date IS NULL, due_date, id""",
                      (session["user_id"],)).fetchall()


def validate_filename(name):
    if not FILENAME_RE.match(name):
        return "File names use letters, numbers, dots, dashes and underscores (max 60 characters)."
    if os.path.splitext(name)[1].lower() not in ALLOWED_EXT:
        return "Unsupported file type. Allowed: " + ", ".join(sorted(ALLOWED_EXT)) + "."
    return None


def validate_project_form(db, form):
    values = {"name": form.get("name", "").strip(),
              "description": form.get("description", "").strip(),
              "language": form.get("language", ""),
              "task_id": form.get("task_id", "").strip()}
    errors = []
    if not values["name"]:
        errors.append("Project name is required.")
    elif len(values["name"]) > 80:
        errors.append("Project name must be 80 characters or fewer.")
    if len(values["description"]) > 1000:
        errors.append("Description must be 1000 characters or fewer.")
    if values["language"] not in LANGUAGES:
        errors.append("Choose a programming language.")
    task_id = None
    if values["task_id"]:
        row = None
        if values["task_id"].isdigit():
            row = db.execute("SELECT id FROM tasks WHERE id = ? AND user_id = ?",
                             (int(values["task_id"]), session["user_id"])).fetchone()
        if row is None:
            errors.append("The linked task was not found.")
        else:
            task_id = row["id"]
    values["task_id_clean"] = task_id
    return values, errors


def create_project(db, values, files):
    cur = db.execute(
        "INSERT INTO projects (user_id, task_id, name, description, language) VALUES (?, ?, ?, ?, ?)",
        (session["user_id"], values.get("task_id_clean"), values["name"], values["description"], values["language"]))
    for filename, content in files.items():
        db.execute("INSERT INTO project_files (project_id, filename, content) VALUES (?, ?, ?)",
                   (cur.lastrowid, filename, content))
    db.commit()
    return cur.lastrowid


def touch_project(db, project_id):
    db.execute("UPDATE projects SET updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?",
               (project_id, session["user_id"]))


# -------------------------------------------------------------- routes ----
@bp.route("/projects")
@login_required
def list_projects():
    db = get_db()
    q = request.args.get("q", "").strip()
    language = request.args.get("language", "")
    where, params = ["p.user_id = ?"], [session["user_id"]]
    if q:
        like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(p.name LIKE ? ESCAPE '\\' OR p.description LIKE ? ESCAPE '\\')")
        params += [like, like]
    if language in LANGUAGES:
        where.append("p.language = ?")
        params.append(language)
    projects = db.execute(
        f"""SELECT p.*, t.title AS task_title,
                   (SELECT COUNT(*) FROM project_files f WHERE f.project_id = p.id) AS file_count
            FROM projects p LEFT JOIN tasks t ON t.id = p.task_id AND t.user_id = p.user_id
            WHERE {' AND '.join(where)} ORDER BY p.updated_at DESC, p.id DESC""", params).fetchall()
    total = db.execute("SELECT COUNT(*) FROM projects WHERE user_id = ?", (session["user_id"],)).fetchone()[0]
    return render_template("projects.html", projects=projects, total=total, q=q, language=language,
                           languages=LANGUAGES)


@bp.route("/projects/new", methods=["GET", "POST"])
@login_required
def new_project():
    db = get_db()
    values, errors = {"language": "python", "task_id": request.args.get("task", "")}, []
    if request.method == "POST":
        values, errors = validate_project_form(db, request.form)
        if not errors:
            pid = create_project(db, values, STARTERS[values["language"]])
            flash("Project created with a starter file.", "success")
            return redirect(url_for("projects.project_detail", project_id=pid))
    return render_template("project_form.html", project=None, values=values, errors=errors,
                           languages=LANGUAGES, tasks=user_tasks(db))


@bp.route("/projects/<int:project_id>")
@login_required
def project_detail(project_id):
    db = get_db()
    project = get_owned_project(db, project_id)
    files = db.execute("SELECT id, filename, updated_at, length(content) AS size FROM project_files "
                       "WHERE project_id = ? ORDER BY filename", (project_id,)).fetchall()
    return render_template("project_detail.html", project=project, files=files,
                           languages=LANGUAGES, codelab_ok=project["language"] in CODELAB_LANGUAGES)


@bp.route("/projects/<int:project_id>/edit", methods=["GET", "POST"])
@login_required
def edit_project(project_id):
    db = get_db()
    project = get_owned_project(db, project_id)
    values = {"name": project["name"], "description": project["description"],
              "language": project["language"], "task_id": str(project["task_id"] or "")}
    errors = []
    if request.method == "POST":
        values, errors = validate_project_form(db, request.form)
        if not errors:
            db.execute("""UPDATE projects SET name = ?, description = ?, language = ?, task_id = ?,
                          updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?""",
                       (values["name"], values["description"], values["language"],
                        values["task_id_clean"], project_id, session["user_id"]))
            db.commit()
            flash("Project updated.", "success")
            return redirect(url_for("projects.project_detail", project_id=project_id))
    return render_template("project_form.html", project=project, values=values, errors=errors,
                           languages=LANGUAGES, tasks=user_tasks(db))


@bp.route("/projects/<int:project_id>/delete", methods=["POST"])
@login_required
def delete_project(project_id):
    db = get_db()
    get_owned_project(db, project_id)
    db.execute("DELETE FROM projects WHERE id = ? AND user_id = ?", (project_id, session["user_id"]))
    db.commit()
    flash("Project and its files deleted.", "info")
    return redirect(url_for("projects.list_projects"))


# --- files ---
@bp.route("/projects/<int:project_id>/files/new", methods=["POST"])
@login_required
def new_file(project_id):
    db = get_db()
    get_owned_project(db, project_id)
    name = request.form.get("filename", "").strip()
    error = validate_filename(name)
    count = db.execute("SELECT COUNT(*) FROM project_files WHERE project_id = ?", (project_id,)).fetchone()[0]
    if error is None and count >= MAX_FILES:
        error = f"A project can have at most {MAX_FILES} files."
    if error is None and db.execute("SELECT 1 FROM project_files WHERE project_id = ? AND filename = ? COLLATE NOCASE",
                                    (project_id, name)).fetchone():
        error = "A file with that name already exists."
    if error:
        flash(error, "danger")
    else:
        db.execute("INSERT INTO project_files (project_id, filename) VALUES (?, ?)", (project_id, name))
        touch_project(db, project_id)
        db.commit()
        flash(f"Created {name}.", "success")
    return redirect(url_for("projects.project_detail", project_id=project_id))


@bp.route("/projects/<int:project_id>/files/<int:file_id>/save", methods=["POST"])
@login_required
def save_file(project_id, file_id):
    """Called by CodeLab (fetch). Returns JSON."""
    db = get_db()
    get_owned_file(db, project_id, file_id)
    content = request.form.get("content", "")
    if len(content) > MAX_FILE_CHARS:
        return jsonify(error=f"Files are limited to {MAX_FILE_CHARS} characters."), 400
    db.execute("UPDATE project_files SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?",
               (content, file_id, project_id))
    touch_project(db, project_id)
    db.commit()
    return jsonify(status="saved")


@bp.route("/projects/<int:project_id>/files/<int:file_id>/rename", methods=["POST"])
@login_required
def rename_file(project_id, file_id):
    db = get_db()
    get_owned_project(db, project_id)
    f = get_owned_file(db, project_id, file_id)
    name = request.form.get("filename", "").strip()
    error = validate_filename(name)
    if error is None and db.execute(
            "SELECT 1 FROM project_files WHERE project_id = ? AND filename = ? COLLATE NOCASE AND id != ?",
            (project_id, name, file_id)).fetchone():
        error = "A file with that name already exists."
    if error:
        flash(error, "danger")
    else:
        db.execute("UPDATE project_files SET filename = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?",
                   (name, file_id, project_id))
        touch_project(db, project_id)
        db.commit()
        flash(f"Renamed {f['filename']} to {name}.", "success")
    return redirect(url_for("projects.project_detail", project_id=project_id))


@bp.route("/projects/<int:project_id>/files/<int:file_id>/delete", methods=["POST"])
@login_required
def delete_file(project_id, file_id):
    db = get_db()
    f = get_owned_file(db, project_id, file_id)
    db.execute("DELETE FROM project_files WHERE id = ? AND project_id = ?", (file_id, project_id))
    touch_project(db, project_id)
    db.commit()
    flash(f"Deleted {f['filename']}.", "info")
    return redirect(url_for("projects.project_detail", project_id=project_id))


@bp.route("/projects/from-codelab", methods=["POST"])
@login_required
def from_codelab():
    """Save the files currently open in CodeLab as a new project (fetch, JSON reply)."""
    db = get_db()
    values, errors = validate_project_form(db, {"name": request.form.get("name", ""),
                                                "language": request.form.get("language", "")})
    if values["language"] not in CODELAB_LANGUAGES:
        errors.append("Only Python, SQL and HTML projects can be saved from CodeLab.")
    try:
        files = json.loads(request.form.get("files", ""))
        if not isinstance(files, dict) or not files or len(files) > 10:
            raise ValueError
        for name, content in files.items():
            if not isinstance(content, str) or len(content) > MAX_FILE_CHARS or validate_filename(name):
                raise ValueError
    except ValueError:
        errors.append("The files could not be saved. Check names and sizes.")
        files = {}
    if errors:
        return jsonify(error=" ".join(errors)), 400
    pid = create_project(db, values, files)
    return jsonify(url=url_for("projects.project_detail", project_id=pid), id=pid), 201
