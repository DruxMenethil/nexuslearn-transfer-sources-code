"""Exercise content for the Learning Hub (seeded into the database at startup).

Each exercise has a hidden reference `solution`. Tests in tests/test_learn.py check that
every solution passes its own tests and that every starter does NOT, so exercises cannot
be completed without real work.

Python test cases:
  {"stdin": "...", "expected": "..."}            program mode: run the code, compare stdout
  {"call": "print(f(1))", "expected": "..."}      function mode: define functions, grader runs `call`
                                                  (output of your top-level code is ignored)
  add "hidden": True to hide the input and expected output from the student.
SQL test cases (expected rows come from running `solution` on a fresh sample database):
  {"ordered": bool, "columns": [...], "check": "SELECT ..."}   `check` is run after the student's
  script to verify data changes; without it the last result set of the script is compared.
"""
import json

SCHEMA_NOTE = ("Tables: students(id, name, major, year, gpa), courses(id, code, title, credits), "
               "enrollments(student_id, course_id, grade).")
FUNCTION_NOTE = "Define the function only. Any output printed outside your function is ignored by the grader, so you may add your own test calls while experimenting."
SQL_STARTER = "-- Write your SQL below\n"


def _fizz(n):
    return "\n".join("FizzBuzz" if i % 15 == 0 else "Fizz" if i % 3 == 0 else "Buzz" if i % 5 == 0 else str(i)
                     for i in range(1, n + 1))


def _countdown(n):
    return "\n".join([str(i) for i in range(n, 0, -1)] + ["Liftoff!"])


EXERCISES = [
    # ------------------------------------------------------------------ Python
    {"slug": "py-hello-name", "title": "Greet by name", "language": "python", "topic": "Input and output",
     "difficulty": "beginner",
     "instructions": "Read one line containing a name, then print Hello, <name>! using exactly that punctuation.\n\nExample: input Ada, output Hello, Ada!",
     "starter": "name = input()\n# Print the greeting here\n",
     "hints": ["input() reads one line of text.", "An f-string such as f\"Hello, {name}!\" is the easiest way to build the message."],
     "tests": [{"stdin": "Ada\n", "expected": "Hello, Ada!"}, {"stdin": "Grace Hopper\n", "expected": "Hello, Grace Hopper!"},
               {"stdin": "x\n", "expected": "Hello, x!", "hidden": True}],
     "solution": 'name = input()\nprint(f"Hello, {name}!")\n'},
    {"slug": "py-sum-two", "title": "Add two numbers", "language": "python", "topic": "Variables", "difficulty": "beginner",
     "instructions": "Read two integers (one per line) and print their sum.\n\nExample: inputs 2 and 3, output 5",
     "starter": "a = int(input())\nb = int(input())\n# Print the sum\n",
     "hints": ["input() returns text, so int() is needed before adding."],
     "tests": [{"stdin": "2\n3\n", "expected": "5"}, {"stdin": "-4\n10\n", "expected": "6"},
               {"stdin": "0\n0\n", "expected": "0", "hidden": True}, {"stdin": "100\n250\n", "expected": "350", "hidden": True}],
     "solution": "a = int(input())\nb = int(input())\nprint(a + b)\n"},
    {"slug": "py-even-odd", "title": "Even or odd", "language": "python", "topic": "Conditions", "difficulty": "beginner",
     "instructions": "Read an integer and print even if it is even, otherwise print odd (lowercase).",
     "starter": "n = int(input())\n# Print even or odd\n",
     "hints": ["The remainder operator % gives the remainder after division.", "A number is even when n % 2 == 0."],
     "tests": [{"stdin": "4\n", "expected": "even"}, {"stdin": "7\n", "expected": "odd"},
               {"stdin": "0\n", "expected": "even", "hidden": True}, {"stdin": "-3\n", "expected": "odd", "hidden": True}],
     "solution": 'n = int(input())\nprint("even" if n % 2 == 0 else "odd")\n'},
    {"slug": "py-countdown", "title": "Countdown", "language": "python", "topic": "Loops", "difficulty": "beginner",
     "instructions": "Read a positive integer n. Print n, n-1, ... 1, one number per line, then print Liftoff!",
     "starter": "n = int(input())\n# Count down from n to 1, then print Liftoff!\n",
     "hints": ["range(n, 0, -1) counts down from n to 1."],
     "tests": [{"stdin": "3\n", "expected": _countdown(3)}, {"stdin": "1\n", "expected": _countdown(1)},
               {"stdin": "5\n", "expected": _countdown(5), "hidden": True}],
     "solution": 'n = int(input())\nfor i in range(n, 0, -1):\n    print(i)\nprint("Liftoff!")\n'},
    {"slug": "py-fizzbuzz", "title": "FizzBuzz", "language": "python", "topic": "Loops", "difficulty": "intermediate",
     "instructions": "Read n. For each number from 1 to n print Fizz if it is divisible by 3, Buzz if divisible by 5, FizzBuzz if divisible by both, otherwise the number itself. One item per line.",
     "starter": "n = int(input())\n# Loop from 1 to n\n",
     "hints": ["Check the divisible-by-both case first.", "i % 15 == 0 means divisible by both 3 and 5."],
     "tests": [{"stdin": "5\n", "expected": _fizz(5)}, {"stdin": "15\n", "expected": _fizz(15)},
               {"stdin": "1\n", "expected": "1", "hidden": True}, {"stdin": "30\n", "expected": _fizz(30), "hidden": True}],
     "solution": 'n = int(input())\nfor i in range(1, n + 1):\n    if i % 15 == 0:\n        print("FizzBuzz")\n    elif i % 3 == 0:\n        print("Fizz")\n    elif i % 5 == 0:\n        print("Buzz")\n    else:\n        print(i)\n'},
    {"slug": "py-average", "title": "Average of a list", "language": "python", "topic": "Lists", "difficulty": "beginner",
     "instructions": "Write average(numbers) that returns the mean of a list of numbers as a float. For an empty list return 0.0.\n\n" + FUNCTION_NOTE,
     "starter": "def average(numbers):\n    pass\n",
     "hints": ["sum() and len() do most of the work.", "Handle the empty list first so you never divide by zero."],
     "tests": [{"call": "print(average([1, 2, 3]))", "expected": "2.0"}, {"call": "print(average([10]))", "expected": "10.0"},
               {"call": "print(average([1, 2]))", "expected": "1.5"}, {"call": "print(average([]))", "expected": "0.0", "hidden": True}],
     "solution": "def average(numbers):\n    if not numbers:\n        return 0.0\n    return sum(numbers) / len(numbers)\n"},
    {"slug": "py-second-largest", "title": "Second largest", "language": "python", "topic": "Lists", "difficulty": "intermediate",
     "instructions": "Write second_largest(numbers) that returns the second largest DISTINCT value in the list, or None if there is no such value.\n\n" + FUNCTION_NOTE,
     "starter": "def second_largest(numbers):\n    pass\n",
     "hints": ["set() removes duplicates and sorted() orders the values.", "Check how many distinct values there are before indexing."],
     "tests": [{"call": "print(second_largest([3, 1, 4, 1, 5]))", "expected": "4"}, {"call": "print(second_largest([2, 2, 2]))", "expected": "None"},
               {"call": "print(second_largest([7]))", "expected": "None"}, {"call": "print(second_largest([-1, -5, -3]))", "expected": "-3", "hidden": True}],
     "solution": "def second_largest(numbers):\n    distinct = sorted(set(numbers))\n    return distinct[-2] if len(distinct) >= 2 else None\n"},
    {"slug": "py-count-words", "title": "Count words", "language": "python", "topic": "Dictionaries", "difficulty": "intermediate",
     "instructions": "Write count_words(text) that returns a dictionary mapping each lowercase word to how many times it appears. Words are separated by whitespace.\n\n" + FUNCTION_NOTE,
     "starter": "def count_words(text):\n    pass\n",
     "hints": ["text.lower().split() gives a list of lowercase words.", "counts.get(word, 0) + 1 avoids a KeyError for new words."],
     "tests": [{"call": "print(sorted(count_words('a b a').items()))", "expected": "[('a', 2), ('b', 1)]"},
               {"call": "print(sorted(count_words('Hello hello HELLO').items()))", "expected": "[('hello', 3)]"},
               {"call": "print(count_words(''))", "expected": "{}", "hidden": True}],
     "solution": "def count_words(text):\n    counts = {}\n    for word in text.lower().split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n"},
    {"slug": "py-reverse-words", "title": "Reverse the words", "language": "python", "topic": "Strings", "difficulty": "beginner",
     "instructions": "Write reverse_words(sentence) that returns the words in reverse order, separated by single spaces.\n\n" + FUNCTION_NOTE,
     "starter": "def reverse_words(sentence):\n    pass\n",
     "hints": ["split() breaks a string into words; \" \".join(...) puts them back."],
     "tests": [{"call": "print(reverse_words('hello big world'))", "expected": "world big hello"},
               {"call": "print(reverse_words('one'))", "expected": "one"},
               {"call": "print(reverse_words('a  b'))", "expected": "b a", "hidden": True}],
     "solution": 'def reverse_words(sentence):\n    return " ".join(reversed(sentence.split()))\n'},
    {"slug": "py-palindrome", "title": "Palindrome check", "language": "python", "topic": "Strings", "difficulty": "intermediate",
     "instructions": "Write is_palindrome(text) that returns True if the text reads the same forwards and backwards, ignoring case and spaces.\n\n" + FUNCTION_NOTE,
     "starter": "def is_palindrome(text):\n    pass\n",
     "hints": ["Remove spaces with replace(\" \", \"\") and lowercase with lower().", "text[::-1] reverses a string."],
     "tests": [{"call": "print(is_palindrome('level'))", "expected": "True"}, {"call": "print(is_palindrome('Never odd or even'))", "expected": "True"},
               {"call": "print(is_palindrome('hello'))", "expected": "False"}, {"call": "print(is_palindrome(''))", "expected": "True", "hidden": True},
               {"call": "print(is_palindrome('A man a plan a canal Panama'))", "expected": "True", "hidden": True}],
     "solution": 'def is_palindrome(text):\n    cleaned = text.replace(" ", "").lower()\n    return cleaned == cleaned[::-1]\n'},
    {"slug": "py-factorial", "title": "Factorial", "language": "python", "topic": "Functions", "difficulty": "intermediate",
     "instructions": "Write factorial(n) that returns n! for n >= 0. Remember that 0! is 1.\n\n" + FUNCTION_NOTE,
     "starter": "def factorial(n):\n    pass\n",
     "hints": ["Start a result at 1 and multiply it by every number from 2 to n.", "A recursive version also works: n * factorial(n - 1)."],
     "tests": [{"call": "print(factorial(0))", "expected": "1"}, {"call": "print(factorial(5))", "expected": "120"},
               {"call": "print(factorial(10))", "expected": "3628800"}, {"call": "print(factorial(1))", "expected": "1", "hidden": True},
               {"call": "print(factorial(15))", "expected": "1307674368000", "hidden": True}],
     "solution": "def factorial(n):\n    result = 1\n    for i in range(2, n + 1):\n        result *= i\n    return result\n"},
    {"slug": "py-is-prime", "title": "Prime check", "language": "python", "topic": "Functions", "difficulty": "intermediate",
     "instructions": "Write is_prime(n) that returns True if n is a prime number and False otherwise. Numbers below 2 are not prime.\n\n" + FUNCTION_NOTE,
     "starter": "def is_prime(n):\n    pass\n",
     "hints": ["Handle n < 2 first.", "You only need to test divisors up to the square root of n."],
     "tests": [{"call": "print(is_prime(2))", "expected": "True"}, {"call": "print(is_prime(17))", "expected": "True"},
               {"call": "print(is_prime(21))", "expected": "False"}, {"call": "print(is_prime(1))", "expected": "False"},
               {"call": "print(is_prime(97))", "expected": "True", "hidden": True}, {"call": "print(is_prime(91))", "expected": "False", "hidden": True},
               {"call": "print(is_prime(0))", "expected": "False", "hidden": True}],
     "solution": "def is_prime(n):\n    if n < 2:\n        return False\n    d = 2\n    while d * d <= n:\n        if n % d == 0:\n            return False\n        d += 1\n    return True\n"},
    # --------------------------------------------------------------------- SQL
    {"slug": "sql-course-list", "title": "List the courses", "language": "sql", "topic": "SELECT", "difficulty": "beginner",
     "instructions": "Return the code and title of every course, ordered by code.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["SELECT code, title FROM courses ...", "ORDER BY sorts the rows."],
     "tests": [{"ordered": True, "columns": ["code", "title"], "label": "All courses, ordered by code"}],
     "solution": "SELECT code, title FROM courses ORDER BY code;"},
    {"slug": "sql-high-gpa", "title": "High achievers", "language": "sql", "topic": "WHERE", "difficulty": "beginner",
     "instructions": "Return the name of every student with a GPA of at least 3.7, highest GPA first.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["Filter with WHERE gpa >= 3.7.", "ORDER BY gpa DESC puts the highest first."],
     "tests": [{"ordered": True, "columns": ["name"], "label": "Students with GPA >= 3.7"}],
     "solution": "SELECT name FROM students WHERE gpa >= 3.7 ORDER BY gpa DESC;"},
    {"slug": "sql-major-counts", "title": "Students per major", "language": "sql", "topic": "GROUP BY", "difficulty": "intermediate",
     "instructions": "For each major return the major and the number of students in it. Name the columns major and students. Row order does not matter.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["GROUP BY major collapses rows per major.", "COUNT(*) AS students names the count column."],
     "tests": [{"ordered": False, "columns": ["major", "students"], "label": "Count per major"}],
     "solution": "SELECT major, COUNT(*) AS students FROM students GROUP BY major;"},
    {"slug": "sql-cs50-roster", "title": "CS50 roster", "language": "sql", "topic": "JOIN", "difficulty": "intermediate",
     "instructions": "Return the names of all students enrolled in the course with code CS50, in alphabetical order.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["You need students, enrollments and courses.", "JOIN enrollments e ON e.student_id = s.id, then JOIN courses c ON c.id = e.course_id."],
     "tests": [{"ordered": True, "columns": ["name"], "label": "Students enrolled in CS50"}],
     "solution": "SELECT s.name FROM students s JOIN enrollments e ON e.student_id = s.id JOIN courses c ON c.id = e.course_id WHERE c.code = 'CS50' ORDER BY s.name;"},
    {"slug": "sql-busy-courses", "title": "Busy courses", "language": "sql", "topic": "GROUP BY", "difficulty": "advanced",
     "instructions": "Return the code of each course with at least 3 enrolled students, and the enrollment count named enrolled. Order by enrolled (highest first), then by code.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["HAVING filters groups after GROUP BY.", "ORDER BY enrolled DESC, c.code"],
     "tests": [{"ordered": True, "columns": ["code", "enrolled"], "label": "Courses with 3+ students"}],
     "solution": "SELECT c.code, COUNT(*) AS enrolled FROM enrollments e JOIN courses c ON c.id = e.course_id GROUP BY c.id HAVING COUNT(*) >= 3 ORDER BY enrolled DESC, c.code;"},
    {"slug": "sql-insert-student", "title": "Add a student", "language": "sql", "topic": "INSERT", "difficulty": "beginner",
     "instructions": "Insert one new student: name Katherine Johnson, major Mathematics, year 2, GPA 4.0. Let the id be assigned automatically.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["INSERT INTO students (name, major, year, gpa) VALUES (...);"],
     "tests": [{"check": "SELECT name, major, year, gpa FROM students WHERE name = 'Katherine Johnson';", "ordered": True, "label": "The new student exists exactly once"},
               {"check": "SELECT COUNT(*) FROM students;", "ordered": True, "label": "No other rows were added or removed"}],
     "solution": "INSERT INTO students (name, major, year, gpa) VALUES ('Katherine Johnson', 'Mathematics', 2, 4.0);"},
    {"slug": "sql-raise-gpa", "title": "Raise the GPA", "language": "sql", "topic": "UPDATE", "difficulty": "intermediate",
     "instructions": "Increase the GPA of every Information Tech student by 0.1. Do not change anyone else.\n\n" + SCHEMA_NOTE,
     "starter": SQL_STARTER, "hints": ["UPDATE students SET gpa = gpa + 0.1 WHERE ...", "Use the WHERE clause so only one major changes."],
     "tests": [{"check": "SELECT name, ROUND(gpa, 2) FROM students WHERE major = 'Information Tech' ORDER BY name;", "ordered": True, "label": "Information Tech GPAs went up"},
               {"check": "SELECT name, gpa FROM students WHERE major != 'Information Tech' ORDER BY name;", "ordered": True, "label": "Other students are unchanged"}],
     "solution": "UPDATE students SET gpa = gpa + 0.1 WHERE major = 'Information Tech';"},
]


def seed_exercises(db):
    """Insert or refresh the built-in exercises. Keyed by slug, so ids and attempts survive updates."""
    for position, ex in enumerate(EXERCISES):
        db.execute(
            """INSERT INTO exercises (slug, title, language, topic, difficulty, instructions, starter_code,
                                      hints, tests, solution, position)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(slug) DO UPDATE SET title = excluded.title, language = excluded.language,
                   topic = excluded.topic, difficulty = excluded.difficulty, instructions = excluded.instructions,
                   starter_code = excluded.starter_code, hints = excluded.hints, tests = excluded.tests,
                   solution = excluded.solution, position = excluded.position""",
            (ex["slug"], ex["title"], ex["language"], ex["topic"], ex["difficulty"], ex["instructions"],
             ex["starter"], json.dumps(ex["hints"]), json.dumps(ex["tests"]), ex["solution"], position))
    db.commit()
