"""Shared helpers: database access, secret key, login and CSRF protection."""
import os
import secrets
import sqlite3
from functools import wraps

from flask import abort, current_app, flash, g, redirect, request, session, url_for


def get_db():
    """One SQLite connection per request, with foreign keys enforced."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables from schema.sql (uses IF NOT EXISTS, so it is safe to repeat)."""
    db = get_db()
    with current_app.open_resource("schema.sql") as f:
        db.executescript(f.read().decode("utf-8"))
    # Databases created before Phase 5 lack two columns on users: add them in place.
    ensure_column(db, "users", "long_break_minutes",
                  "INTEGER NOT NULL DEFAULT 15 CHECK (long_break_minutes BETWEEN 1 AND 60)")
    ensure_column(db, "users", "long_break_every",
                  "INTEGER NOT NULL DEFAULT 4 CHECK (long_break_every BETWEEN 0 AND 10)")
    ensure_column(db, "users", "display_name", "TEXT NOT NULL DEFAULT '' CHECK (length(display_name) <= 50)")
    # Study Studio: richer notes. Added in place so existing notes are kept.
    ensure_column(db, "notes", "folder", "TEXT NOT NULL DEFAULT ''")
    ensure_column(db, "notes", "tags", "TEXT NOT NULL DEFAULT ''")
    ensure_column(db, "notes", "favorite", "INTEGER NOT NULL DEFAULT 0 CHECK (favorite IN (0, 1))")
    ensure_column(db, "notes", "task_id", "INTEGER REFERENCES tasks(id) ON DELETE SET NULL")
    ensure_column(db, "notes", "project_id", "INTEGER REFERENCES projects(id) ON DELETE SET NULL")
    db.execute("CREATE INDEX IF NOT EXISTS idx_notes_user_fav ON notes (user_id, favorite)")
    from exercises_data import seed_exercises  # imported here to avoid a circular import
    seed_exercises(db)
    db.commit()


def ensure_column(db, table, column, ddl):
    """Add a column if missing. Arguments are code constants, never user input."""
    if column not in [row["name"] for row in db.execute(f"PRAGMA table_info({table})")]:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def load_secret_key(instance_path):
    """Use SECRET_KEY from the environment; otherwise generate one and keep it in
    instance/secret_key (which is git-ignored) so sessions survive restarts."""
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    os.makedirs(instance_path, exist_ok=True)
    path = os.path.join(instance_path, "secret_key")
    if os.path.exists(path):
        with open(path) as f:
            return f.read().strip()
    key = secrets.token_hex(32)
    with open(path, "w") as f:
        f.write(key)
    os.chmod(path, 0o600)
    return key


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(16)
    return session["csrf_token"]


def check_csrf():
    """Reject any POST whose form token does not match the session token."""
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    if not expected or not secrets.compare_digest(sent, expected):
        abort(400, "Invalid or missing CSRF token. Reload the page and try again.")


def safe_next(target, default):
    """Return `target` only if it is a local path (blocks open redirects)."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return default


def tz_offset_minutes():
    """Browser's UTC offset (JS getTimezoneOffset) from the tz_offset cookie; 0 if missing or invalid."""
    try:
        value = int(request.cookies.get("tz_offset", "0"))
    except ValueError:
        return 0
    return value if -840 <= value <= 840 else 0


def fmt_duration(seconds):
    seconds = int(seconds or 0)
    if seconds < 60:
        return f"{seconds} s"
    if seconds < 3600:
        return f"{seconds // 60} min"
    return f"{seconds // 3600} h {seconds % 3600 // 60:02d} min"


def local_dt(utc_text, offset_minutes, fmt="%b %d, %H:%M"):
    """Format a stored UTC 'YYYY-MM-DD HH:MM:SS' string in the browser's time zone."""
    from datetime import datetime, timedelta
    return (datetime.strptime(utc_text, "%Y-%m-%d %H:%M:%S") - timedelta(minutes=offset_minutes)).strftime(fmt)


def like(text):
    """Escape a search term for LIKE ... ESCAPE '\\'."""
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def local_today(offset_minutes=None):
    """The student's current local date (ISO). Uses focus.clock so tests can control time."""
    from datetime import datetime, timedelta, timezone
    import focus
    if offset_minutes is None:
        offset_minutes = tz_offset_minutes()
    now = datetime.fromtimestamp(focus.clock(), timezone.utc).replace(tzinfo=None)
    return (now - timedelta(minutes=offset_minutes)).date().isoformat()


def clean_tags(raw):
    """Normalise 'Loops, python ,loops' -> 'loops,python' (max 8 tags, 20 chars each)."""
    seen = []
    for t in raw.replace(";", ",").split(","):
        t = " ".join(t.lower().split())[:20]
        if t and t not in seen:
            seen.append(t)
    return ",".join(seen[:8])


def owned_or_404(db, table, row_id):
    """Fetch a row from a table that has user_id, only if the current user owns it.
    `table` is always a code constant."""
    row = db.execute(f"SELECT * FROM {table} WHERE id = ? AND user_id = ?", (row_id, session["user_id"])).fetchone()
    if row is None:
        abort(404)
    return row
