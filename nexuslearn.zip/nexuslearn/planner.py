"""Academic Planner: task CRUD, subjects, search/filter/sort (Phase 2).

Every query filters on user_id, and a task that is not yours returns 404
(not 403) so other users' task ids cannot even be probed.
"""
import re
from datetime import date, timedelta

from flask import (Blueprint, abort, flash, redirect, render_template,
                   request, session, url_for)

from helpers import get_db, login_required, safe_next

bp = Blueprint("planner", __name__)

PRIORITIES = ("low", "medium", "high")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

PRIORITY_RANK = "CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END"
SORTS = {  # whitelist: user input only selects a key, never becomes SQL
    "deadline": f"t.status = 'completed', t.due_date IS NULL, t.due_date, {PRIORITY_RANK}, t.id",
    "priority": f"t.status = 'completed', {PRIORITY_RANK}, t.due_date IS NULL, t.due_date, t.id",
    "newest": "t.created_at DESC, t.id DESC",
}


def validate_task_form(form):
    values = {
        "title": form.get("title", "").strip(),
        "description": form.get("description", "").strip(),
        "subject": " ".join(form.get("subject", "").split()),
        "due_date": form.get("due_date", "").strip(),
        "priority": form.get("priority", "medium"),
    }
    errors = []
    if not values["title"]:
        errors.append("Title is required.")
    elif len(values["title"]) > 120:
        errors.append("Title must be 120 characters or fewer.")
    if len(values["subject"]) > 60:
        errors.append("Subject must be 60 characters or fewer.")
    if len(values["description"]) > 2000:
        errors.append("Description must be 2000 characters or fewer.")
    if values["priority"] not in PRIORITIES:
        errors.append("Priority must be low, medium, or high.")
    if values["due_date"]:
        try:
            if not DATE_RE.match(values["due_date"]):
                raise ValueError
            year = date.fromisoformat(values["due_date"]).year
            if not 2000 <= year <= 2100:
                raise ValueError
        except ValueError:
            errors.append("Due date must be a real date between 2000 and 2100 (YYYY-MM-DD).")
    return values, errors


def subject_id_for(db, uid, name):
    """Find (case-insensitively) or create the user's subject; '' means none."""
    if not name:
        return None
    row = db.execute("SELECT id FROM subjects WHERE user_id = ? AND name = ? COLLATE NOCASE",
                     (uid, name)).fetchone()
    if row:
        return row["id"]
    return db.execute("INSERT INTO subjects (user_id, name) VALUES (?, ?)", (uid, name)).lastrowid


def get_owned_task(db, task_id):
    task = db.execute(
        """SELECT t.*, s.name AS subject FROM tasks t
           LEFT JOIN subjects s ON s.id = t.subject_id
           WHERE t.id = ? AND t.user_id = ?""", (task_id, session["user_id"])).fetchone()
    if task is None:
        abort(404)
    return task


def user_subjects(db):
    return db.execute("SELECT id, name FROM subjects WHERE user_id = ? ORDER BY name COLLATE NOCASE",
                      (session["user_id"],)).fetchall()


@bp.route("/planner")
@login_required
def list_tasks():
    db = get_db()
    uid = session["user_id"]
    today = date.today()
    f = {k: request.args.get(k, "").strip() for k in ("q", "subject", "priority", "status", "due", "sort")}
    sort = f["sort"] if f["sort"] in SORTS else "deadline"

    where, params = ["t.user_id = ?"], [uid]
    if f["q"]:
        like = "%" + f["q"].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(t.title LIKE ? ESCAPE '\\' OR t.description LIKE ? ESCAPE '\\')")
        params += [like, like]
    if f["subject"].isdigit():
        where.append("t.subject_id = ?")
        params.append(int(f["subject"]))
    if f["priority"] in PRIORITIES:
        where.append("t.priority = ?")
        params.append(f["priority"])
    if f["status"] in ("pending", "completed"):
        where.append("t.status = ?")
        params.append(f["status"])
    elif f["status"] == "overdue":
        where.append("t.status = 'pending' AND t.due_date < ?")
        params.append(today.isoformat())
    if f["due"] == "today":
        where.append("t.due_date = ?")
        params.append(today.isoformat())
    elif f["due"] == "week":
        where.append("t.due_date BETWEEN ? AND ?")
        params += [today.isoformat(), (today + timedelta(days=7)).isoformat()]
    elif f["due"] == "none":
        where.append("t.due_date IS NULL")

    tasks = db.execute(
        f"""SELECT t.*, s.name AS subject FROM tasks t
            LEFT JOIN subjects s ON s.id = t.subject_id
            WHERE {' AND '.join(where)} ORDER BY {SORTS[sort]}""", params).fetchall()
    total = db.execute("SELECT COUNT(*) FROM tasks WHERE user_id = ?", (uid,)).fetchone()[0]
    return render_template("planner.html", tasks=tasks, total=total, f=f, sort=sort,
                           subjects=user_subjects(db), today=today.isoformat())


@bp.route("/tasks/new", methods=["GET", "POST"])
@login_required
def new_task():
    values, errors = {"priority": "medium"}, []
    if request.method == "POST":
        values, errors = validate_task_form(request.form)
        if not errors:
            db = get_db()
            uid = session["user_id"]
            cur = db.execute(
                """INSERT INTO tasks (user_id, subject_id, title, description, due_date, priority)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (uid, subject_id_for(db, uid, values["subject"]), values["title"],
                 values["description"], values["due_date"] or None, values["priority"]))
            db.commit()
            flash("Task created.", "success")
            return redirect(url_for("planner.task_detail", task_id=cur.lastrowid))
    return render_template("task_form.html", task=None, values=values, errors=errors,
                           subjects=user_subjects(get_db()))


@bp.route("/tasks/<int:task_id>")
@login_required
def task_detail(task_id):
    db = get_db()
    task = get_owned_task(db, task_id)
    linked = db.execute("SELECT id, name, language FROM projects WHERE task_id = ? AND user_id = ? "
                        "ORDER BY updated_at DESC", (task_id, session["user_id"])).fetchall()
    return render_template("task_detail.html", task=task, projects=linked, today=date.today().isoformat())


@bp.route("/tasks/<int:task_id>/edit", methods=["GET", "POST"])
@login_required
def edit_task(task_id):
    db = get_db()
    task = get_owned_task(db, task_id)
    values = {"title": task["title"], "description": task["description"],
              "subject": task["subject"] or "", "due_date": task["due_date"] or "",
              "priority": task["priority"]}
    errors = []
    if request.method == "POST":
        values, errors = validate_task_form(request.form)
        if not errors:
            uid = session["user_id"]
            db.execute(
                """UPDATE tasks SET subject_id = ?, title = ?, description = ?, due_date = ?, priority = ?
                   WHERE id = ? AND user_id = ?""",
                (subject_id_for(db, uid, values["subject"]), values["title"], values["description"],
                 values["due_date"] or None, values["priority"], task_id, uid))
            db.commit()
            flash("Task updated.", "success")
            return redirect(url_for("planner.task_detail", task_id=task_id))
    return render_template("task_form.html", task=task, values=values, errors=errors,
                           subjects=user_subjects(db))


@bp.route("/tasks/<int:task_id>/toggle", methods=["POST"])
@login_required
def toggle_task(task_id):
    db = get_db()
    task = get_owned_task(db, task_id)
    if task["status"] == "pending":
        db.execute("""UPDATE tasks SET status = 'completed', completed_at = CURRENT_TIMESTAMP
                      WHERE id = ? AND user_id = ?""", (task_id, session["user_id"]))
        flash("Task marked complete.", "success")
    else:
        db.execute("""UPDATE tasks SET status = 'pending', completed_at = NULL
                      WHERE id = ? AND user_id = ?""", (task_id, session["user_id"]))
        flash("Task moved back to pending.", "info")
    db.commit()
    return redirect(safe_next(request.form.get("next"), url_for("planner.list_tasks")))


@bp.route("/tasks/<int:task_id>/delete", methods=["POST"])
@login_required
def delete_task(task_id):
    db = get_db()
    get_owned_task(db, task_id)
    db.execute("DELETE FROM tasks WHERE id = ? AND user_id = ?", (task_id, session["user_id"]))
    db.commit()
    flash("Task deleted.", "info")
    return redirect(url_for("planner.list_tasks"))
