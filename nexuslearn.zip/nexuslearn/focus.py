"""Focus Mode (Phase 5): a server-authoritative study timer.

Why server-authoritative: the browser countdown is only a display. The database
stores when the session was (re)started and how much time was used before, so a
refresh, a closed tab, or a double-click cannot change what gets recorded.

Rules (also shown to the student on the page):
  * Study time = completed FOCUS sessions: ones that ran their full length, or
    that the student finished early after at least 1 minute. Breaks do not count.
  * Reset discards the session (nothing is recorded).
  * A running timer counts down on the server even if the tab is closed. When the
    student returns after it ran out, it is recorded as completed, capped at the
    planned length.
  * Only one unfinished session per user (enforced by a unique index).
"""
import sqlite3
import time
from datetime import datetime, timedelta, timezone

from flask import (Blueprint, flash, jsonify, redirect, render_template,
                   request, session, url_for)

from helpers import get_db, login_required, tz_offset_minutes
from planner import subject_id_for

bp = Blueprint("focus", __name__)

FMT = "%Y-%m-%d %H:%M:%S"
KINDS = ("focus", "break", "long_break")
LIMITS = {"focus": (1, 180), "break": (1, 60), "long_break": (1, 60)}
MIN_EARLY_SECONDS = 60
HISTORY_ROWS = 15

ACTIVE_SQL = """
    SELECT f.*, s.name AS subject, t.title AS task_title, p.name AS project_name
    FROM focus_sessions f
    LEFT JOIN subjects s ON s.id = f.subject_id
    LEFT JOIN tasks    t ON t.id = f.task_id    AND t.user_id = f.user_id
    LEFT JOIN projects p ON p.id = f.project_id AND p.user_id = f.user_id
    WHERE f.user_id = ? AND f.status IN ('running', 'paused')"""


def clock():
    """Current epoch seconds. A function so tests can replace it."""
    return time.time()


def utc_str(ts):
    return datetime.fromtimestamp(ts, timezone.utc).strftime(FMT)


def dt_str(dt):
    return dt.strftime(FMT)


# ------------------------------------------------------------ time logic ----
def elapsed(row, now):
    used = row["accumulated_seconds"]
    if row["status"] == "running":
        used += now - row["resumed_at"]
    return max(0.0, used)


def get_active(db, uid):
    return db.execute(ACTIVE_SQL, (uid,)).fetchone()


def settle(db, uid, row, now):
    """Complete a running session whose time is up. Safe to call repeatedly:
    the conditional UPDATE succeeds for exactly one caller."""
    if row is None or row["status"] != "running" or elapsed(row, now) < row["planned_seconds"]:
        return None
    finished_at = row["resumed_at"] + (row["planned_seconds"] - row["accumulated_seconds"])
    cur = db.execute(
        """UPDATE focus_sessions SET status = 'completed', duration_seconds = planned_seconds,
               accumulated_seconds = planned_seconds, resumed_at = NULL, ended_at = ?
           WHERE id = ? AND user_id = ? AND status = 'running'""",
        (utc_str(finished_at), row["id"], uid))
    db.commit()
    if cur.rowcount == 1:
        return {"kind": row["kind"], "duration_seconds": row["planned_seconds"]}
    return None


def describe(row, now):
    used = min(elapsed(row, now), row["planned_seconds"])
    return {"id": row["id"], "kind": row["kind"], "status": row["status"],
            "planned_seconds": row["planned_seconds"], "elapsed_seconds": round(used, 1),
            "remaining_seconds": round(row["planned_seconds"] - used, 1),
            "subject": row["subject"], "task": row["task_title"], "project": row["project_name"]}


def day_start(now, offset, days_back=0):
    """(utc, local) datetimes of the start of the student's local day."""
    local = datetime.fromtimestamp(now, timezone.utc).replace(tzinfo=None) - timedelta(minutes=offset)
    start_local = local.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days_back)
    return start_local + timedelta(minutes=offset), start_local


def focus_seconds(db, uid, start=None, end=None):
    sql = ("SELECT COALESCE(SUM(duration_seconds), 0), COUNT(*) FROM focus_sessions "
           "WHERE user_id = ? AND kind = 'focus' AND status = 'completed'")
    params = [uid]
    if start is not None:
        sql += " AND ended_at >= ? AND ended_at < ?"
        params += [dt_str(start), dt_str(end)]
    row = db.execute(sql, params).fetchone()
    return row[0], row[1]


def study_totals(db, uid, now, offset):
    today_utc, today_local = day_start(now, offset)
    week_start = today_utc - timedelta(days=today_local.weekday())  # weeks start on Monday
    return {"today_seconds": focus_seconds(db, uid, today_utc, today_utc + timedelta(days=1))[0],
            "week_seconds": focus_seconds(db, uid, week_start, week_start + timedelta(days=7))[0]}


def summaries(db, uid, now, offset):
    today_utc, today_local = day_start(now, offset)
    week_start = today_utc - timedelta(days=today_local.weekday())
    week_end = week_start + timedelta(days=7)
    today_secs, today_count = focus_seconds(db, uid, today_utc, today_utc + timedelta(days=1))
    days = []
    for back in range(6, -1, -1):
        start_utc, start_local = day_start(now, offset, back)
        days.append({"label": start_local.strftime("%a %d"),
                     "seconds": focus_seconds(db, uid, start_utc, start_utc + timedelta(days=1))[0]})
    biggest = max((d["seconds"] for d in days), default=0)
    for d in days:
        d["pct"] = round(100 * d["seconds"] / biggest) if biggest else 0
    by_subject = db.execute(
        """SELECT COALESCE(s.name, 'No subject') AS subject, SUM(f.duration_seconds) AS seconds
           FROM focus_sessions f LEFT JOIN subjects s ON s.id = f.subject_id
           WHERE f.user_id = ? AND f.kind = 'focus' AND f.status = 'completed'
                 AND f.ended_at >= ? AND f.ended_at < ?
           GROUP BY f.subject_id ORDER BY seconds DESC""",
        (uid, dt_str(week_start), dt_str(week_end))).fetchall()
    return {"today_seconds": today_secs, "sessions_today": today_count,
            "week_seconds": focus_seconds(db, uid, week_start, week_end)[0],
            "total_seconds": focus_seconds(db, uid)[0], "days": days, "by_subject": by_subject}


def user_settings(db, uid):
    return db.execute("""SELECT focus_minutes, break_minutes, long_break_minutes, long_break_every
                         FROM users WHERE id = ?""", (uid,)).fetchone()


def next_break_kind(db, uid, now, offset, settings):
    every = settings["long_break_every"]
    if every > 0:
        today_utc, _ = day_start(now, offset)
        _, count = focus_seconds(db, uid, today_utc, today_utc + timedelta(days=1))
        if count > 0 and count % every == 0:
            return "long_break"
    return "break"


def build_state(db, uid, now):
    """Settle anything that finished, then describe what is active right now."""
    completed = settle(db, uid, get_active(db, uid), now)
    row = get_active(db, uid)  # re-read: another request may have settled it
    settings = user_settings(db, uid)
    return {"active": describe(row, now) if row else None, "completed": completed,
            "server_time": now, "next_break": next_break_kind(db, uid, now, tz_offset_minutes(), settings)}


def error(message, code=400):
    return jsonify(error=message), code


# ---------------------------------------------------------------- routes ----
@bp.route("/focus")
@login_required
def focus_page():
    db, uid, now, offset = get_db(), session["user_id"], clock(), tz_offset_minutes()
    state = build_state(db, uid, now)
    if state["completed"]:
        flash(f"A {state['completed']['kind'].replace('_', ' ')} session finished while you were away "
              f"({state['completed']['duration_seconds'] // 60} min).", "success")
    settings = user_settings(db, uid)
    history = []
    for r in db.execute(
            """SELECT f.id, f.duration_seconds, f.finished_early, f.ended_at, f.task_id, f.project_id,
                      s.name AS subject, t.title AS task_title, p.name AS project_name
               FROM focus_sessions f
               LEFT JOIN subjects s ON s.id = f.subject_id
               LEFT JOIN tasks    t ON t.id = f.task_id    AND t.user_id = f.user_id
               LEFT JOIN projects p ON p.id = f.project_id AND p.user_id = f.user_id
               WHERE f.user_id = ? AND f.kind = 'focus' AND f.status = 'completed'
               ORDER BY f.ended_at DESC, f.id DESC LIMIT ?""", (uid, HISTORY_ROWS)):
        local = datetime.strptime(r["ended_at"], FMT) - timedelta(minutes=offset)
        history.append({**dict(r), "when": local.strftime("%b %d, %H:%M")})
    boot = {"state": state, "csrf": None,
            "defaults": {"focus": settings["focus_minutes"], "break": settings["break_minutes"],
                         "long_break": settings["long_break_minutes"]},
            "urls": {name: url_for(f"focus.{name}") for name in
                     ("get_state", "start", "pause", "resume", "finish", "reset")}}
    return render_template(
        "focus.html", boot=boot, settings=settings, history=history,
        summary=summaries(db, uid, now, offset),
        subjects=db.execute("SELECT name FROM subjects WHERE user_id = ? ORDER BY name COLLATE NOCASE", (uid,)).fetchall(),
        tasks=db.execute("""SELECT t.id, t.title, s.name AS subject FROM tasks t LEFT JOIN subjects s ON s.id = t.subject_id
                            WHERE t.user_id = ? AND t.status = 'pending' ORDER BY t.due_date IS NULL, t.due_date, t.id""",
                         (uid,)).fetchall(),
        projects=db.execute("SELECT id, name FROM projects WHERE user_id = ? ORDER BY updated_at DESC", (uid,)).fetchall())


@bp.route("/focus/state")
@login_required
def get_state():
    return jsonify(build_state(get_db(), session["user_id"], clock()))


@bp.route("/focus/start", methods=["POST"])
@login_required
def start():
    db, uid, now = get_db(), session["user_id"], clock()
    state = build_state(db, uid, now)  # also settles a session that already ran out
    if state["active"]:
        return jsonify({**state, "already_active": True})

    kind = request.form.get("kind", "focus")
    if kind not in KINDS:
        return error("Unknown session type.")
    settings = user_settings(db, uid)
    default = {"focus": settings["focus_minutes"], "break": settings["break_minutes"],
               "long_break": settings["long_break_minutes"]}[kind]
    raw = request.form.get("minutes", "").strip()
    if raw and not raw.isdigit():
        return error("Minutes must be a whole number.")
    minutes = int(raw) if raw else default
    low, high = LIMITS[kind]
    if not low <= minutes <= high:
        return error(f"{kind.replace('_', ' ').capitalize()} length must be {low}-{high} minutes.")

    subject_id = task_id = project_id = None
    if kind == "focus":
        subject = " ".join(request.form.get("subject", "").split())
        if len(subject) > 60:
            return error("Subject must be 60 characters or fewer.")
        links = {}
        for field, table in (("task_id", "tasks"), ("project_id", "projects")):
            value = request.form.get(field, "").strip()
            if not value:
                links[field] = None
            elif value.isdigit() and db.execute(f"SELECT 1 FROM {table} WHERE id = ? AND user_id = ?",
                                                (int(value), uid)).fetchone():
                links[field] = int(value)
            else:
                return error("The linked assignment or project was not found.")
        task_id, project_id = links["task_id"], links["project_id"]
        subject_id = subject_id_for(db, uid, subject)

    try:
        db.execute(
            """INSERT INTO focus_sessions (user_id, kind, planned_seconds, resumed_at, subject_id,
                                           task_id, project_id, started_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (uid, kind, minutes * 60, now, subject_id, task_id, project_id, utc_str(now)))
        db.commit()
    except sqlite3.IntegrityError:  # a parallel request started one first
        db.rollback()
        return jsonify({**build_state(db, uid, now), "already_active": True})
    return jsonify(build_state(db, uid, now)), 201


@bp.route("/focus/pause", methods=["POST"])
@login_required
def pause():
    db, uid, now = get_db(), session["user_id"], clock()
    state = build_state(db, uid, now)
    row = get_active(db, uid)
    if row is not None and row["status"] == "running":
        db.execute("""UPDATE focus_sessions SET status = 'paused', accumulated_seconds = ?, resumed_at = NULL
                      WHERE id = ? AND user_id = ? AND status = 'running'""",
                   (elapsed(row, now), row["id"], uid))
        db.commit()
        state = build_state(db, uid, now)
    return jsonify(state)


@bp.route("/focus/resume", methods=["POST"])
@login_required
def resume():
    db, uid, now = get_db(), session["user_id"], clock()
    state = build_state(db, uid, now)
    row = get_active(db, uid)
    if row is not None and row["status"] == "paused":
        db.execute("""UPDATE focus_sessions SET status = 'running', resumed_at = ?
                      WHERE id = ? AND user_id = ? AND status = 'paused'""", (now, row["id"], uid))
        db.commit()
        state = build_state(db, uid, now)
    return jsonify(state)


@bp.route("/focus/finish", methods=["POST"])
@login_required
def finish():
    """Finish a focus session early and record the time actually studied."""
    db, uid, now = get_db(), session["user_id"], clock()
    state = build_state(db, uid, now)
    row = get_active(db, uid)
    if row is None:
        return jsonify(state)
    if row["kind"] != "focus":
        return error("Breaks cannot be finished early. Use Skip break.")
    used = elapsed(row, now)
    if used < MIN_EARLY_SECONDS:
        return error("Study for at least 1 minute before finishing early, or reset to discard this session.")
    db.execute("""UPDATE focus_sessions SET status = 'completed', duration_seconds = ?, accumulated_seconds = ?,
                      resumed_at = NULL, finished_early = 1, ended_at = ?
                  WHERE id = ? AND user_id = ? AND status IN ('running', 'paused')""",
               (int(used), used, utc_str(now), row["id"], uid))
    db.commit()
    state = build_state(db, uid, now)
    state["completed"] = {"kind": "focus", "duration_seconds": int(used), "finished_early": True}
    return jsonify(state)


@bp.route("/focus/reset", methods=["POST"])
@login_required
def reset():
    """Discard the unfinished session. Nothing is recorded."""
    db, uid, now = get_db(), session["user_id"], clock()
    build_state(db, uid, now)  # a session that already finished stays recorded
    db.execute("DELETE FROM focus_sessions WHERE user_id = ? AND status IN ('running', 'paused')", (uid,))
    db.commit()
    return jsonify(build_state(db, uid, now))


@bp.route("/focus/settings", methods=["POST"])
@login_required
def save_settings():
    fields = {"focus_minutes": (1, 180, "Focus"), "break_minutes": (1, 60, "Break"),
              "long_break_minutes": (1, 60, "Long break"), "long_break_every": (0, 10, "Long break interval")}
    values = {}
    for name, (low, high, label) in fields.items():
        raw = request.form.get(name, "").strip()
        if not raw.isdigit() or not low <= int(raw) <= high:
            flash(f"{label} must be a whole number from {low} to {high}.", "danger")
            return redirect(url_for("focus.focus_page"))
        values[name] = int(raw)
    db = get_db()
    db.execute("""UPDATE users SET focus_minutes = ?, break_minutes = ?, long_break_minutes = ?, long_break_every = ?
                  WHERE id = ?""", (values["focus_minutes"], values["break_minutes"],
                                    values["long_break_minutes"], values["long_break_every"], session["user_id"]))
    db.commit()
    flash("Timer settings saved.", "success")
    return redirect(url_for("focus.focus_page"))
