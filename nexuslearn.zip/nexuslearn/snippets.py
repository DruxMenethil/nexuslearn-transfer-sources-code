"""Code Snippet Library (Phase 4): private, taggable, searchable snippets."""
import re

from flask import (Blueprint, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)

from helpers import get_db, login_required
from projects import LANGUAGES

bp = Blueprint("snippets", __name__)

SNIPPET_LANGUAGES = {**LANGUAGES, "css": "CSS"}
OPENABLE = ("python", "sql", "html", "javascript", "c", "cpp")  # languages CodeLab can open
TAG_RE = re.compile(r"^[a-z0-9][a-z0-9+#._-]{0,19}$")
MAX_TAGS = 8
MAX_CODE = 20_000


def get_owned_snippet(db, snippet_id):
    s = db.execute("SELECT * FROM code_snippets WHERE id = ? AND user_id = ?",
                   (snippet_id, session["user_id"])).fetchone()
    if s is None:
        abort(404)
    return s


def normalize_tags(raw):
    tags, error = [], None
    for part in raw.split(","):
        tag = "-".join(part.strip().lower().split())
        if not tag:
            continue
        if not TAG_RE.match(tag):
            error = f"Tag '{part.strip()[:20]}' is not valid (letters, numbers, + # . _ -, max 20)."
        elif tag not in tags:
            tags.append(tag)
    if len(tags) > MAX_TAGS:
        error = f"Use at most {MAX_TAGS} tags."
    return tags, error


def validate_snippet_form(form):
    values = {"title": form.get("title", "").strip(),
              "description": form.get("description", "").strip(),
              "language": form.get("language", ""),
              "code": form.get("code", "").replace("\r\n", "\n"),
              "tags_raw": form.get("tags", "")}
    errors = []
    if not values["title"]:
        errors.append("Title is required.")
    elif len(values["title"]) > 80:
        errors.append("Title must be 80 characters or fewer.")
    if len(values["description"]) > 500:
        errors.append("Description must be 500 characters or fewer.")
    if values["language"] not in SNIPPET_LANGUAGES:
        errors.append("Choose a language.")
    if not values["code"].strip():
        errors.append("Code cannot be empty.")
    elif len(values["code"]) > MAX_CODE:
        errors.append(f"Code must be {MAX_CODE} characters or fewer.")
    tags, tag_error = normalize_tags(values["tags_raw"])
    if tag_error:
        errors.append(tag_error)
    values["tags"] = ",".join(tags)
    return values, errors


@bp.route("/snippets")
@login_required
def list_snippets():
    db = get_db()
    q = request.args.get("q", "").strip()
    language = request.args.get("language", "")
    tag = request.args.get("tag", "").strip().lower()
    where, params = ["user_id = ?"], [session["user_id"]]

    def like(text):
        return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"

    if q:
        where.append("(title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\' "
                     "OR tags LIKE ? ESCAPE '\\' OR code LIKE ? ESCAPE '\\')")
        params += [like(q)] * 4
    if language in SNIPPET_LANGUAGES:
        where.append("language = ?")
        params.append(language)
    if tag:
        where.append("(',' || tags || ',') LIKE ? ESCAPE '\\'")
        params.append(like("," + tag + ","))
    snippets = db.execute(f"SELECT * FROM code_snippets WHERE {' AND '.join(where)} "
                          "ORDER BY updated_at DESC, id DESC", params).fetchall()
    total = db.execute("SELECT COUNT(*) FROM code_snippets WHERE user_id = ?", (session["user_id"],)).fetchone()[0]
    return render_template("snippets.html", snippets=snippets, total=total, q=q, language=language, tag=tag,
                           languages=SNIPPET_LANGUAGES, openable=OPENABLE)


@bp.route("/snippets/new", methods=["GET", "POST"])
@login_required
def new_snippet():
    values, errors = {"language": request.args.get("language", "python")}, []
    if request.method == "POST":
        values, errors = validate_snippet_form(request.form)
        if not errors:
            db = get_db()
            db.execute("""INSERT INTO code_snippets (user_id, title, description, language, code, tags)
                          VALUES (?, ?, ?, ?, ?, ?)""",
                       (session["user_id"], values["title"], values["description"], values["language"],
                        values["code"], values["tags"]))
            db.commit()
            flash("Snippet saved.", "success")
            return redirect(url_for("snippets.list_snippets"))
    return render_template("snippet_form.html", snippet=None, values=values, errors=errors,
                           languages=SNIPPET_LANGUAGES)


@bp.route("/snippets/<int:snippet_id>/edit", methods=["GET", "POST"])
@login_required
def edit_snippet(snippet_id):
    db = get_db()
    s = get_owned_snippet(db, snippet_id)
    values = {"title": s["title"], "description": s["description"], "language": s["language"],
              "code": s["code"], "tags_raw": s["tags"].replace(",", ", ")}
    errors = []
    if request.method == "POST":
        values, errors = validate_snippet_form(request.form)
        if not errors:
            db.execute("""UPDATE code_snippets SET title = ?, description = ?, language = ?, code = ?, tags = ?,
                          updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?""",
                       (values["title"], values["description"], values["language"], values["code"],
                        values["tags"], snippet_id, session["user_id"]))
            db.commit()
            flash("Snippet updated.", "success")
            return redirect(url_for("snippets.list_snippets"))
    return render_template("snippet_form.html", snippet=s, values=values, errors=errors,
                           languages=SNIPPET_LANGUAGES)


@bp.route("/snippets/<int:snippet_id>/delete", methods=["POST"])
@login_required
def delete_snippet(snippet_id):
    db = get_db()
    get_owned_snippet(db, snippet_id)
    db.execute("DELETE FROM code_snippets WHERE id = ? AND user_id = ?", (snippet_id, session["user_id"]))
    db.commit()
    flash("Snippet deleted.", "info")
    return redirect(url_for("snippets.list_snippets"))


@bp.route("/snippets/from-codelab", methods=["POST"])
@login_required
def from_codelab():
    """Save the code open in CodeLab as a snippet (fetch, JSON reply)."""
    values, errors = validate_snippet_form(request.form)
    if errors:
        return jsonify(error=" ".join(errors)), 400
    db = get_db()
    cur = db.execute("""INSERT INTO code_snippets (user_id, title, description, language, code, tags)
                        VALUES (?, ?, ?, ?, ?, ?)""",
                     (session["user_id"], values["title"], values["description"], values["language"],
                      values["code"], values["tags"]))
    db.commit()
    return jsonify(url=url_for("snippets.list_snippets"), id=cur.lastrowid), 201
