"""NexusLearn - Phase 1: foundation (auth + dashboard)."""
import os
import re
import sqlite3
from datetime import date

from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import codelab
import focus
import planner
import projects
import snippets
from helpers import (check_csrf, close_db, csrf_token, get_db, init_db,
                     fmt_duration, load_secret_key, login_required, safe_next, tz_offset_minutes)

app = Flask(__name__)
os.makedirs(app.instance_path, exist_ok=True)
app.config.update(
    SECRET_KEY=load_secret_key(app.instance_path),
    DATABASE=os.path.join(app.instance_path, "nexuslearn.db"),
    PRACTICE_DIR=os.path.join(app.instance_path, "practice"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
app.teardown_appcontext(close_db)
app.register_blueprint(planner.bp)
app.register_blueprint(codelab.bp)
app.register_blueprint(focus.bp)
app.register_blueprint(projects.bp)
app.register_blueprint(snippets.bp)
app.jinja_env.globals["csrf_token"] = csrf_token
app.jinja_env.filters["duration"] = fmt_duration

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")


@app.before_request
def protect_forms():
    if request.method == "POST":
        check_csrf()


@app.after_request
def no_cache(response):
    response.headers["Cache-Control"] = "no-store"
    return response


@app.context_processor
def inject_user():
    """Make the current user's theme available to every template."""
    uid = session.get("user_id")
    if uid is None:
        return {"current_user": None}
    user = get_db().execute("SELECT id, username, theme FROM users WHERE id = ?", (uid,)).fetchone()
    return {"current_user": user}


@app.route("/")
def index():
    return redirect(url_for("dashboard" if session.get("user_id") else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirmation", "")

        error = None
        if not USERNAME_RE.match(username):
            error = "Username must be 3-30 characters: letters, numbers, underscore."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."
        elif password != confirm:
            error = "Passwords do not match."

        if error is None:
            db = get_db()
            try:
                cur = db.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password)))
                db.commit()
            except sqlite3.IntegrityError:
                error = "That username is already taken."
            else:
                session.clear()
                session["user_id"] = cur.lastrowid
                flash("Welcome to NexusLearn! Your account is ready.", "success")
                return redirect(url_for("dashboard"))
        flash(error, "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT id, password_hash FROM users WHERE username = ?",
                                (username,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Invalid username or password.", "danger")
        else:
            session.clear()
            session["user_id"] = user["id"]
            return redirect(safe_next(request.args.get("next"), url_for("dashboard")))
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    uid = session["user_id"]
    today = date.today().isoformat()
    stats = db.execute(
        """SELECT COUNT(*) AS total,
                  COALESCE(SUM(status = 'pending'), 0)   AS pending,
                  COALESCE(SUM(status = 'completed'), 0) AS completed,
                  COALESCE(SUM(status = 'pending' AND due_date < ?), 0) AS overdue
           FROM tasks WHERE user_id = ?""", (today, uid)).fetchone()
    upcoming = db.execute(
        """SELECT id, title, due_date, priority FROM tasks
           WHERE user_id = ? AND status = 'pending' AND due_date >= ?
           ORDER BY due_date LIMIT 5""", (uid, today)).fetchall()
    recent_projects = db.execute(
        """SELECT id, name, language, updated_at FROM projects WHERE user_id = ?
           ORDER BY updated_at DESC, id DESC LIMIT 5""", (uid,)).fetchall()
    study = focus.study_totals(db, uid, focus.clock(), tz_offset_minutes())
    return render_template("dashboard.html", stats=stats, upcoming=upcoming, recent_projects=recent_projects, study=study)


if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(debug=True)

# Also create tables when started with `flask run`.
with app.app_context():
    init_db()
