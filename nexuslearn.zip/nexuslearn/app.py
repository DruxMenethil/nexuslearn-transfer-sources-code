"""NexusLearn - Phase 1: foundation (auth + dashboard)."""
import os
import re
import sqlite3
from datetime import date, timedelta

from flask import Flask, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import codelab
import flashcards
import focus
import learn
import notes
import planner
import progress
import projects
import quizzes
import search
import settings
import snippets
import visualizer
import writing
from helpers import (check_csrf, close_db, csrf_token, get_db, init_db,
                     fmt_duration, load_secret_key, local_today, login_required, safe_next, tz_offset_minutes)

app = Flask(__name__)
os.makedirs(app.instance_path, exist_ok=True)
app.config.update(
    SECRET_KEY=load_secret_key(app.instance_path),
    DATABASE=os.path.join(app.instance_path, "nexuslearn.db"),
    PRACTICE_DIR=os.path.join(app.instance_path, "practice"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=6 * 1024 * 1024,   # uploads are limited to 5 MB (documents.py); this is the hard ceiling
)
app.teardown_appcontext(close_db)
app.register_blueprint(planner.bp)
app.register_blueprint(codelab.bp)
app.register_blueprint(focus.bp)
app.register_blueprint(learn.bp)
app.register_blueprint(progress.bp)
app.register_blueprint(search.bp)
app.register_blueprint(settings.bp)
app.register_blueprint(projects.bp)
app.register_blueprint(snippets.bp)
app.register_blueprint(notes.bp)
app.register_blueprint(quizzes.bp)
app.register_blueprint(flashcards.bp)
app.register_blueprint(visualizer.bp)
app.register_blueprint(writing.bp)
app.jinja_env.globals["csrf_token"] = csrf_token
app.jinja_env.filters["duration"] = fmt_duration

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")


@app.before_request
def protect_forms():
    if request.method == "POST":
        check_csrf()


@app.errorhandler(413)
def too_large(error):
    flash("That upload is too large. Files are limited to 5 MB.", "danger")
    return redirect(request.referrer or url_for("dashboard")), 303


@app.after_request
def no_cache(response):
    response.headers["Cache-Control"] = "no-store"
    return response


@app.context_processor
def inject_user():
    """Current user (theme, name) and deadline reminders, available to every template."""
    uid = session.get("user_id")
    if uid is None:
        return {"current_user": None, "alerts": None}
    db = get_db()
    user = db.execute("SELECT id, username, theme, display_name FROM users WHERE id = ?", (uid,)).fetchone()
    today = date.today()
    row = db.execute(
        """SELECT COALESCE(SUM(due_date < ?), 0) AS overdue,
                  COALESCE(SUM(due_date >= ? AND due_date <= ?), 0) AS soon
           FROM tasks WHERE user_id = ? AND status = 'pending' AND due_date IS NOT NULL""",
        (today.isoformat(), today.isoformat(), (today + timedelta(days=2)).isoformat(), uid)).fetchone()
    cards_due = db.execute("""SELECT COUNT(*) FROM cards c JOIN decks d ON d.id = c.deck_id
                              WHERE d.user_id = ? AND c.due_date <= ?""", (uid, local_today())).fetchone()[0]
    return {"current_user": user, "alerts": {"overdue": row["overdue"], "soon": row["soon"], "cards_due": cards_due}}


@app.route("/")
def index():
    return redirect(url_for("dashboard" if session.get("user_id") else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirmation", "")

        error = None
        if not USERNAME_RE.match(username):
            error = "Username must be 3-30 characters: letters, numbers, underscore."
        elif len(password) < 8:
            error = "Password must be at least 8 characters."
        elif password != confirm:
            error = "Passwords do not match."

        if error is None:
            db = get_db()
            try:
                cur = db.execute(
                    "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password)))
                db.commit()
            except sqlite3.IntegrityError:
                error = "That username is already taken."
            else:
                session.clear()
                session["user_id"] = cur.lastrowid
                flash("Welcome to NexusLearn! Your account is ready.", "success")
                return redirect(url_for("dashboard"))
        flash(error, "danger")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT id, password_hash FROM users WHERE username = ?",
                                (username,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Invalid username or password.", "danger")
        else:
            session.clear()
            session["user_id"] = user["id"]
            return redirect(safe_next(request.args.get("next"), url_for("dashboard")))
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    uid = session["user_id"]
    today = date.today().isoformat()
    stats = db.execute(
        """SELECT COUNT(*) AS total,
                  COALESCE(SUM(status = 'pending'), 0)   AS pending,
                  COALESCE(SUM(status = 'completed'), 0) AS completed,
                  COALESCE(SUM(status = 'pending' AND due_date < ?), 0) AS overdue
           FROM tasks WHERE user_id = ?""", (today, uid)).fetchone()
    upcoming = db.execute(
        """SELECT id, title, due_date, priority FROM tasks
           WHERE user_id = ? AND status = 'pending' AND due_date >= ?
           ORDER BY due_date LIMIT 5""", (uid, today)).fetchall()
    recent_projects = db.execute(
        """SELECT id, name, language, updated_at FROM projects WHERE user_id = ?
           ORDER BY updated_at DESC, id DESC LIMIT 5""", (uid,)).fetchall()
    recent_attempts = db.execute(
        """SELECT e.title, e.slug, a.passed, a.tests_passed, a.tests_total, a.created_at
           FROM exercise_attempts a JOIN exercises e ON e.id = a.exercise_id
           WHERE a.user_id = ? ORDER BY a.id DESC LIMIT 5""", (uid,)).fetchall()
    study = focus.study_totals(db, uid, focus.clock(), tz_offset_minutes())
    studio = {
        "cards_due": db.execute("""SELECT COUNT(*) FROM cards c JOIN decks d ON d.id = c.deck_id
                                   WHERE d.user_id = ? AND c.due_date <= ?""", (uid, local_today())).fetchone()[0],
        "notes": db.execute("SELECT COUNT(*) FROM notes WHERE user_id = ?", (uid,)).fetchone()[0],
        "quizzes": db.execute("SELECT COUNT(*) FROM quizzes WHERE user_id = ?", (uid,)).fetchone()[0],
        "decks": db.execute("SELECT COUNT(*) FROM decks WHERE user_id = ?", (uid,)).fetchone()[0],
        "last_quiz": db.execute("""SELECT a.id, z.title, a.score, a.total FROM quiz_attempts a JOIN quizzes z ON z.id = a.quiz_id
                                   WHERE a.user_id = ? AND a.status = 'submitted' ORDER BY a.id DESC LIMIT 1""", (uid,)).fetchone(),
        "recent_notes": db.execute("SELECT id, title FROM notes WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 3", (uid,)).fetchall(),
    }
    new_account = not (stats["total"] or studio["notes"] or studio["quizzes"] or studio["decks"] or recent_projects or recent_attempts)
    return render_template("dashboard.html", stats=stats, upcoming=upcoming, recent_projects=recent_projects, study=study,
                           recent_attempts=recent_attempts, studio=studio, new_account=new_account)


if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(debug=True)

# Also create tables when started with `flask run`.
with app.app_context():
    init_db()
