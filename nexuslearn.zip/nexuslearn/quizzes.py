"""Quiz Builder: create, edit, generate (template-based), take, grade and review quizzes.

Security: every query filters on user_id (directly or through the quiz). The answer key is only
rendered on the owner's edit page and in the results of a SUBMITTED attempt; the quiz-taking page
never contains it. Grading happens on the server.
"""
import json
import random
import re
import zlib
from datetime import datetime, timezone

from flask import (Blueprint, abort, flash, jsonify, redirect, render_template, request,
                   session, url_for)

import studytext
from helpers import get_db, like, login_required, owned_or_404

bp = Blueprint("quizzes", __name__)
QTYPES = {"mcq": "Multiple choice", "tf": "True / false", "identification": "Identification (short answer)",
          "blank": "Fill in the blank"}
DIFFICULTIES = ("beginner", "intermediate", "advanced")
MAX_QUESTIONS = 100


# ------------------------------------------------------------ validation ----
def normalize(text):
    """Case-, space- and punctuation-insensitive form used to compare written answers."""
    return " ".join(re.sub(r"[^\w\s]", " ", (text or "").casefold()).split())


def validate_question(form):
    """-> (values, errors). `form` is any mapping with qtype, prompt, answer, choices, explanation."""
    qtype = form.get("qtype", "")
    v = {"qtype": qtype, "prompt": form.get("prompt", "").strip(), "answer": form.get("answer", "").strip(),
         "explanation": form.get("explanation", "").strip()[:600], "choices": []}
    errors = []
    if qtype not in QTYPES:
        return v, ["Choose a question type."]
    if not v["prompt"]:
        errors.append("The question text is required.")
    elif len(v["prompt"]) > 600:
        errors.append("The question must be 600 characters or fewer.")
    if qtype == "tf":
        v["answer"] = v["answer"].lower()
        if v["answer"] not in ("true", "false"):
            errors.append("The answer to a true/false question must be true or false.")
    elif not v["answer"]:
        errors.append("The correct answer is required.")
    elif len(v["answer"]) > 300:
        errors.append("The answer must be 300 characters or fewer.")
    if qtype == "mcq":
        raw = form.get("choices", "")
        choices = [c.strip() for c in (raw if isinstance(raw, list) else raw.split("\n")) if c.strip()]
        v["choices"] = choices
        if not 2 <= len(choices) <= 6:
            errors.append("Multiple choice needs 2 to 6 choices, one per line.")
        elif len({normalize(c) for c in choices}) != len(choices):
            errors.append("Choices must all be different.")
        elif normalize(v["answer"]) not in {normalize(c) for c in choices}:
            errors.append("The correct answer must match one of the choices.")
        else:   # store the answer exactly as the matching choice is spelled
            v["answer"] = next(c for c in choices if normalize(c) == normalize(v["answer"]))
    return v, errors


def validate_quiz(form):
    v = {"title": form.get("title", "").strip(), "description": form.get("description", "").strip()[:500],
         "subject": " ".join(form.get("subject", "").split())[:60], "topic": " ".join(form.get("topic", "").split())[:60],
         "difficulty": form.get("difficulty", "beginner"), "time_limit_minutes": None}
    errors = []
    if not v["title"] or len(v["title"]) > 100:
        errors.append("Title is required and must be 100 characters or fewer.")
    if v["difficulty"] not in DIFFICULTIES:
        errors.append("Choose a difficulty."); v["difficulty"] = "beginner"
    limit = form.get("time_limit_minutes", "").strip()
    if limit:
        if limit.isdigit() and 1 <= int(limit) <= 240:
            v["time_limit_minutes"] = int(limit)
        else:
            errors.append("The time limit must be between 1 and 240 minutes, or empty for no limit.")
    return v, errors


def grade(qtype, key, response):
    """1 = correct, 0 = incorrect, None = cannot be graded reliably (student reviews it).
    Written answers: any '|'-separated alternative in the key may match after normalisation."""
    response = (response or "").strip()
    if not response:
        return 0
    if qtype in ("mcq", "tf"):
        return int(normalize(response) == normalize(key))
    if normalize(response) in {normalize(alt) for alt in key.split("|")}:
        return 1
    return None


# --------------------------------------------------------------- helpers ----
def get_quiz(db, quiz_id):
    return owned_or_404(db, "quizzes", quiz_id)


def get_questions(db, quiz_id):
    return db.execute("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY position, id", (quiz_id,)).fetchall()


def touch(db, quiz_id):
    db.execute("UPDATE quizzes SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", (quiz_id,))


def insert_question(db, quiz_id, v):
    pos = db.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM quiz_questions WHERE quiz_id = ?", (quiz_id,)).fetchone()[0]
    db.execute("""INSERT INTO quiz_questions (quiz_id, position, qtype, prompt, answer, choices, explanation)
                  VALUES (?, ?, ?, ?, ?, ?, ?)""",
               (quiz_id, pos, v["qtype"], v["prompt"], v["answer"], json.dumps(v["choices"]), v["explanation"]))


def set_note_links(db, quiz_id, note_ids):
    uid = session["user_id"]
    ids = {int(n) for n in note_ids if str(n).isdigit()}
    valid = [r[0] for r in db.execute(f"SELECT id FROM notes WHERE user_id = ? AND id IN ({','.join('?' * len(ids))})",
                                      [uid, *ids])] if ids else []
    db.execute("DELETE FROM quiz_notes WHERE quiz_id = ?", (quiz_id,))
    db.executemany("INSERT INTO quiz_notes (quiz_id, note_id) VALUES (?, ?)", [(quiz_id, n) for n in valid])


def user_notes(db):
    return db.execute("SELECT id, title FROM notes WHERE user_id = ? ORDER BY updated_at DESC", (session["user_id"],)).fetchall()


# ------------------------------------------------------------ quiz CRUD ----
@bp.route("/study/quizzes")
@login_required
def list_quizzes():
    db, uid = get_db(), session["user_id"]
    q, status = request.args.get("q", "").strip(), request.args.get("status", "")
    where, params = ["z.user_id = ?"], [uid]
    if q:
        where.append("(z.title LIKE ? ESCAPE '\\' OR z.subject LIKE ? ESCAPE '\\' OR z.topic LIKE ? ESCAPE '\\')")
        params += [like(q)] * 3
    if status in ("draft", "published"):
        where.append("z.status = ?"); params.append(status)
    quizzes = db.execute(f"""
        SELECT z.*, (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = z.id) AS n_questions,
               (SELECT COUNT(*) FROM quiz_attempts a WHERE a.quiz_id = z.id AND a.status = 'submitted') AS n_attempts,
               (SELECT a.score * 100 / NULLIF(a.total, 0) FROM quiz_attempts a WHERE a.quiz_id = z.id AND a.status = 'submitted'
                  ORDER BY a.id DESC LIMIT 1) AS last_pct
        FROM quizzes z WHERE {' AND '.join(where)} ORDER BY z.updated_at DESC, z.id DESC""", params).fetchall()
    total = db.execute("SELECT COUNT(*) FROM quizzes WHERE user_id = ?", (uid,)).fetchone()[0]
    return render_template("quizzes.html", quizzes=quizzes, q=q, status=status, total=total)


@bp.route("/study/quizzes/new", methods=["GET", "POST"])
@login_required
def new_quiz():
    db, uid = get_db(), session["user_id"]
    values, errors = {"difficulty": "beginner"}, []
    if request.method == "POST":
        values, errors = validate_quiz(request.form)
        if not errors:
            cur = db.execute("""INSERT INTO quizzes (user_id, title, description, subject, topic, difficulty, time_limit_minutes)
                                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                             (uid, values["title"], values["description"], values["subject"], values["topic"],
                              values["difficulty"], values["time_limit_minutes"]))
            set_note_links(db, cur.lastrowid, request.form.getlist("note_ids"))
            db.commit()
            flash("Quiz created as a draft. Add your questions below.", "success")
            return redirect(url_for("quizzes.edit_quiz", quiz_id=cur.lastrowid))
    return render_template("quiz_edit.html", quiz=None, values=values, errors=errors, questions=[], notes=user_notes(db),
                           linked=set(), attempts=[], qtypes=QTYPES, difficulties=DIFFICULTIES, new_question={})


@bp.route("/study/quizzes/<int:quiz_id>/edit", methods=["GET", "POST"])
@login_required
def edit_quiz(quiz_id):
    db, uid = get_db(), session["user_id"]
    quiz = get_quiz(db, quiz_id)
    values, errors = dict(quiz), []
    if request.method == "POST":
        values, errors = validate_quiz(request.form)
        if not errors:
            db.execute("""UPDATE quizzes SET title = ?, description = ?, subject = ?, topic = ?, difficulty = ?,
                          time_limit_minutes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?""",
                       (values["title"], values["description"], values["subject"], values["topic"], values["difficulty"],
                        values["time_limit_minutes"], quiz_id, uid))
            set_note_links(db, quiz_id, request.form.getlist("note_ids"))
            db.commit()
            flash("Quiz details saved.", "success")
            return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
    questions = [{**dict(r), "choice_list": json.loads(r["choices"])} for r in get_questions(db, quiz_id)]
    attempts = db.execute("""SELECT id, status, started_at, finished_at, score, total, seconds_taken FROM quiz_attempts
                             WHERE quiz_id = ? AND user_id = ? ORDER BY id DESC LIMIT 20""", (quiz_id, uid)).fetchall()
    linked = {r[0] for r in db.execute("SELECT note_id FROM quiz_notes WHERE quiz_id = ?", (quiz_id,))}
    return render_template("quiz_edit.html", quiz=quiz, values=values, errors=errors, questions=questions, notes=user_notes(db),
                           linked=linked, attempts=attempts, qtypes=QTYPES, difficulties=DIFFICULTIES, new_question={})


@bp.route("/study/quizzes/<int:quiz_id>/delete", methods=["POST"])
@login_required
def delete_quiz(quiz_id):
    db = get_db()
    get_quiz(db, quiz_id)
    db.execute("DELETE FROM quizzes WHERE id = ? AND user_id = ?", (quiz_id, session["user_id"]))
    db.commit()
    flash("Quiz deleted along with its questions and attempts.", "info")
    return redirect(url_for("quizzes.list_quizzes"))


@bp.route("/study/quizzes/<int:quiz_id>/duplicate", methods=["POST"])
@login_required
def duplicate_quiz(quiz_id):
    db, uid = get_db(), session["user_id"]
    quiz = get_quiz(db, quiz_id)
    cur = db.execute("""INSERT INTO quizzes (user_id, title, description, subject, topic, difficulty, time_limit_minutes, source)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                     (uid, (quiz["title"][:93] + " (copy)"), quiz["description"], quiz["subject"], quiz["topic"],
                      quiz["difficulty"], quiz["time_limit_minutes"], quiz["source"]))
    new_id = cur.lastrowid
    db.execute("""INSERT INTO quiz_questions (quiz_id, position, qtype, prompt, answer, choices, explanation)
                  SELECT ?, position, qtype, prompt, answer, choices, explanation FROM quiz_questions WHERE quiz_id = ?""",
               (new_id, quiz_id))
    db.execute("INSERT INTO quiz_notes (quiz_id, note_id) SELECT ?, note_id FROM quiz_notes WHERE quiz_id = ?", (new_id, quiz_id))
    db.commit()
    flash("Duplicated as a draft. You are editing the copy.", "success")
    return redirect(url_for("quizzes.edit_quiz", quiz_id=new_id))


@bp.route("/study/quizzes/<int:quiz_id>/status", methods=["POST"])
@login_required
def set_status(quiz_id):
    db = get_db()
    quiz = get_quiz(db, quiz_id)
    target = request.form.get("status")
    if target == "published":
        n = db.execute("SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = ?", (quiz_id,)).fetchone()[0]
        if n == 0:
            flash("Add at least one question before publishing.", "danger")
            return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
    elif target != "draft":
        abort(400)
    db.execute("UPDATE quizzes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?",
               (target, quiz_id, session["user_id"]))
    db.commit()
    flash("Published for practice." if target == "published" else "Moved back to draft.", "success")
    return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))


# ------------------------------------------------------------- questions ----
@bp.route("/study/quizzes/<int:quiz_id>/questions", methods=["POST"])
@login_required
def add_question(quiz_id):
    db = get_db()
    quiz = get_quiz(db, quiz_id)
    if db.execute("SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = ?", (quiz_id,)).fetchone()[0] >= MAX_QUESTIONS:
        flash(f"A quiz can have at most {MAX_QUESTIONS} questions.", "danger")
        return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
    v, errors = validate_question(request.form)
    if errors:
        for e in errors:
            flash(e, "danger")
        return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
    insert_question(db, quiz_id, v)
    touch(db, quiz_id)
    db.commit()
    flash("Question added.", "success")
    return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))


def get_question(db, quiz_id, question_id):
    get_quiz(db, quiz_id)
    q = db.execute("SELECT * FROM quiz_questions WHERE id = ? AND quiz_id = ?", (question_id, quiz_id)).fetchone()
    if q is None:
        abort(404)
    return q


@bp.route("/study/quizzes/<int:quiz_id>/questions/<int:question_id>", methods=["GET", "POST"])
@login_required
def edit_question(quiz_id, question_id):
    db = get_db()
    quiz, q = get_quiz(db, quiz_id), get_question(db, quiz_id, question_id)
    values, errors = {**dict(q), "choices": "\n".join(json.loads(q["choices"]))}, []
    if request.method == "POST":
        v, errors = validate_question(request.form)
        if not errors:
            db.execute("""UPDATE quiz_questions SET qtype = ?, prompt = ?, answer = ?, choices = ?, explanation = ?
                          WHERE id = ? AND quiz_id = ?""",
                       (v["qtype"], v["prompt"], v["answer"], json.dumps(v["choices"]), v["explanation"], question_id, quiz_id))
            touch(db, quiz_id)
            db.commit()
            flash("Question saved.", "success")
            return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
        values = {**v, "choices": request.form.get("choices", "")}
    return render_template("question_form.html", quiz=quiz, q=q, values=values, errors=errors, qtypes=QTYPES)


@bp.route("/study/quizzes/<int:quiz_id>/questions/<int:question_id>/delete", methods=["POST"])
@login_required
def delete_question(quiz_id, question_id):
    db = get_db()
    get_question(db, quiz_id, question_id)
    db.execute("DELETE FROM quiz_questions WHERE id = ? AND quiz_id = ?", (question_id, quiz_id))
    touch(db, quiz_id)
    db.commit()
    flash("Question deleted.", "info")
    return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))


@bp.route("/study/quizzes/<int:quiz_id>/questions/<int:question_id>/move", methods=["POST"])
@login_required
def move_question(quiz_id, question_id):
    db = get_db()
    get_question(db, quiz_id, question_id)
    ids = [r["id"] for r in get_questions(db, quiz_id)]
    i = ids.index(question_id)
    j = i - 1 if request.form.get("direction") == "up" else i + 1
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
        for pos, qid in enumerate(ids, 1):
            db.execute("UPDATE quiz_questions SET position = ? WHERE id = ? AND quiz_id = ?", (pos, qid, quiz_id))
        touch(db, quiz_id)
        db.commit()
    return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id) + "#questions")


# ------------------------------------------------------------ generation ----
def generate_drafts(text, count, types, seed=0):
    """Template-based drafts. Returns (questions, messages). No AI is involved."""
    rng = random.Random(seed or zlib.crc32(text.encode("utf-8")))
    pairs = studytext.extract_pairs(text)
    sentences = studytext.extract_sentences(text)
    out, messages = [], []
    wanted = [t for t in types if t in QTYPES] or ["identification"]

    def mcq(i):
        term, definition = pairs[i]
        others = [p[0] for j, p in enumerate(pairs) if j != i]
        if len(others) < 3:
            return None
        choices = rng.sample(others, 3) + [term]
        rng.shuffle(choices)
        return {"qtype": "mcq", "prompt": f"Which term matches this description? {definition}", "answer": term,
                "choices": choices, "explanation": f"{term}: {definition}"}

    def ident(i):
        term, definition = pairs[i]
        return {"qtype": "identification", "prompt": f"What term is described here? {definition}", "answer": term,
                "choices": [], "explanation": f"{term}: {definition}"}

    def tf(i, flip):
        term, definition = pairs[i]
        if flip:
            if len(pairs) < 2:
                return None
            definition = pairs[(i + 1) % len(pairs)][1]
        return {"qtype": "tf", "prompt": f"True or false: {term} is described as follows. {definition}",
                "answer": "false" if flip else "true", "choices": [],
                "explanation": f"The correct description: {pairs[i][0]}: {pairs[i][1]}"}

    def blank_pair(i):
        term, definition = pairs[i]
        return {"qtype": "blank", "prompt": f"{definition} (Term: _____)", "answer": term, "choices": [],
                "explanation": f"{term}: {definition}"}

    def blank_sentence(s):
        word = studytext.key_word(s)
        if not word:
            return None
        return {"qtype": "blank", "prompt": re.sub(re.escape(word), "_____", s, count=1), "answer": word, "choices": [],
                "explanation": s}

    blank_pool = [("s", x) for x in sentences] + [("p", i) for i in range(len(pairs))]

    def blank(r):
        if r >= len(blank_pool):
            return None
        kind, item = blank_pool[r]
        return blank_sentence(item) if kind == "s" else blank_pair(item)

    makers = {"mcq": lambda r: mcq(r) if r < len(pairs) else None,
              "identification": lambda r: ident(r) if r < len(pairs) else None,
              "tf": lambda r: tf(r // 2, r % 2 == 1) if pairs and r // 2 < len(pairs) else None,
              "blank": blank}
    seen = set()
    for r in range(len(pairs) * 2 + len(blank_pool) + 1):      # round r asks each wanted type for its r-th question
        for t in wanted:
            if len(out) >= count:
                break
            q = makers[t](r)
            if q and q["prompt"] not in seen:
                seen.add(q["prompt"])
                out.append(q)
    if len(out) < count:
        messages.append(f"Only {len(out)} question{'' if len(out) == 1 else 's'} could be drafted from this text. "
                        "Lines like 'Term: definition' and clear sentences work best. You can add more by hand.")
    if not out:
        messages.append("No questions could be drafted. Try 'Term: definition' lines, or build the quiz manually.")
    return out, messages


def note_text(db, raw_ids):
    ids = [int(x) for x in raw_ids if str(x).isdigit()]
    if not ids:
        return "", []
    rows = db.execute(f"SELECT id, title, body FROM notes WHERE user_id = ? AND id IN ({','.join('?' * len(ids))})",
                      [session["user_id"], *ids]).fetchall()
    return "\n\n".join(r["body"] for r in rows), [r["id"] for r in rows]


@bp.route("/study/quizzes/generate", methods=["GET", "POST"])
@login_required
def generate():
    db = get_db()
    notes = user_notes(db)
    if request.method == "POST":
        text, note_ids = note_text(db, request.form.getlist("note_ids"))
        pasted = request.form.get("text", "").strip()
        text = (text + "\n\n" + pasted).strip()[:40_000]
        count = min(max(int(request.form.get("count", "5")) if request.form.get("count", "5").isdigit() else 5, 1), 30)
        types = request.form.getlist("types") or ["identification"]
        if not text:
            flash("Choose a note or paste some text first.", "danger")
        else:
            drafts, messages = generate_drafts(text, count, types)
            meta = {"title": request.form.get("title", "").strip() or "Quiz from notes",
                    "subject": request.form.get("subject", ""), "topic": request.form.get("topic", ""),
                    "difficulty": request.form.get("difficulty", "beginner")}
            return render_template("quiz_review.html", drafts=drafts, messages=messages, meta=meta, note_ids=note_ids,
                                   qtypes=QTYPES, difficulties=DIFFICULTIES)
    return render_template("quiz_generate.html", notes=notes, selected=request.args.get("note_id", ""), qtypes=QTYPES,
                           difficulties=DIFFICULTIES)


@bp.route("/study/quizzes/generate/save", methods=["POST"])
@login_required
def save_generated():
    """Validate every kept draft again on the server; reject bad ones with a message."""
    db, uid = get_db(), session["user_id"]
    meta, errors = validate_quiz(request.form)
    kept, problems = [], []
    for i in range(int(request.form.get("n", "0")) if request.form.get("n", "0").isdigit() else 0):
        if not request.form.get(f"keep-{i}"):
            continue
        v, errs = validate_question({"qtype": request.form.get(f"qtype-{i}", ""), "prompt": request.form.get(f"prompt-{i}", ""),
                                     "answer": request.form.get(f"answer-{i}", ""), "choices": request.form.get(f"choices-{i}", ""),
                                     "explanation": request.form.get(f"explanation-{i}", "")})
        if errs:
            problems.append(f"Question {i + 1}: {' '.join(errs)}")
        else:
            kept.append(v)
    if not kept and not problems:
        problems.append("Keep at least one question.")
    if errors or problems:
        for e in errors + problems:
            flash(e, "danger")
        return redirect(url_for("quizzes.generate"))
    cur = db.execute("""INSERT INTO quizzes (user_id, title, description, subject, topic, difficulty, source)
                        VALUES (?, ?, ?, ?, ?, ?, 'template')""",
                     (uid, meta["title"], "Drafted from notes with templates (no AI). Reviewed by me.", meta["subject"],
                      meta["topic"], meta["difficulty"]))
    for v in kept:
        insert_question(db, cur.lastrowid, v)
    set_note_links(db, cur.lastrowid, request.form.getlist("note_ids"))
    db.commit()
    flash(f"Saved {len(kept)} question{'' if len(kept) == 1 else 's'} as a draft quiz. Publish it when you are happy.", "success")
    return redirect(url_for("quizzes.edit_quiz", quiz_id=cur.lastrowid))


# --------------------------------------------------------------- taking ----
def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


@bp.route("/study/quizzes/<int:quiz_id>/take", methods=["GET", "POST"])
@login_required
def take(quiz_id):
    """GET shows the intro, POST starts (or resumes) an attempt. The answer key is never sent."""
    db, uid = get_db(), session["user_id"]
    quiz = get_quiz(db, quiz_id)
    questions = get_questions(db, quiz_id)
    if quiz["status"] != "published" or not questions:
        flash("Publish the quiz (with at least one question) before practising it.", "warning")
        return redirect(url_for("quizzes.edit_quiz", quiz_id=quiz_id))
    attempt = db.execute("SELECT * FROM quiz_attempts WHERE quiz_id = ? AND user_id = ? AND status = 'in_progress'",
                         (quiz_id, uid)).fetchone()
    if request.method == "POST" and attempt is None:
        cur = db.execute("INSERT INTO quiz_attempts (quiz_id, user_id, started_at, total) VALUES (?, ?, ?, ?)",
                         (quiz_id, uid, utc_now(), len(questions)))
        db.commit()
        attempt = db.execute("SELECT * FROM quiz_attempts WHERE id = ?", (cur.lastrowid,)).fetchone()
    if attempt is None:
        history = db.execute("SELECT id, finished_at, score, total FROM quiz_attempts WHERE quiz_id = ? AND user_id = ? "
                             "AND status = 'submitted' ORDER BY id DESC LIMIT 10", (quiz_id, uid)).fetchall()
        return render_template("quiz_intro.html", quiz=quiz, n=len(questions), history=history)
    remaining = None
    if quiz["time_limit_minutes"]:
        started = datetime.strptime(attempt["started_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        remaining = max(0, int(quiz["time_limit_minutes"] * 60 - (datetime.now(timezone.utc) - started).total_seconds()))
    public = [{"id": q["id"], "qtype": q["qtype"], "prompt": q["prompt"],
               "choices": json.loads(q["choices"]) if q["qtype"] == "mcq" else (["True", "False"] if q["qtype"] == "tf" else [])}
              for q in questions]
    return render_template("quiz_take.html", quiz=quiz, attempt=attempt, questions=public, remaining=remaining)


@bp.route("/study/attempts/<int:attempt_id>/submit", methods=["POST"])
@login_required
def submit(attempt_id):
    db, uid = get_db(), session["user_id"]
    attempt = owned_or_404(db, "quiz_attempts", attempt_id)
    if attempt["status"] == "submitted":
        return redirect(url_for("quizzes.results", attempt_id=attempt_id))
    questions = get_questions(db, attempt["quiz_id"])
    score = 0
    for q in questions:           # one transaction: committed once below
        response = request.form.get(f"q{q['id']}", "").strip()[:500]
        verdict = grade(q["qtype"], q["answer"], response)
        score += verdict or 0
        db.execute("""INSERT OR REPLACE INTO quiz_responses
                      (attempt_id, question_id, qtype, prompt, answer_key, explanation, response, is_correct)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                   (attempt_id, q["id"], q["qtype"], q["prompt"], q["answer"], q["explanation"], response, verdict))
    started = datetime.strptime(attempt["started_at"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    seconds = max(0, int((datetime.now(timezone.utc) - started).total_seconds()))
    db.execute("""UPDATE quiz_attempts SET status = 'submitted', finished_at = ?, seconds_taken = ?, score = ?, total = ?
                  WHERE id = ? AND user_id = ?""", (utc_now(), seconds, score, len(questions), attempt_id, uid))
    db.commit()
    return redirect(url_for("quizzes.results", attempt_id=attempt_id))


@bp.route("/study/attempts/<int:attempt_id>")
@login_required
def results(attempt_id):
    db = get_db()
    attempt = owned_or_404(db, "quiz_attempts", attempt_id)
    if attempt["status"] != "submitted":
        return redirect(url_for("quizzes.take", quiz_id=attempt["quiz_id"]))
    quiz = db.execute("SELECT id, title FROM quizzes WHERE id = ?", (attempt["quiz_id"],)).fetchone()
    rows = db.execute("SELECT * FROM quiz_responses WHERE attempt_id = ? ORDER BY id", (attempt_id,)).fetchall()
    pending = sum(1 for r in rows if r["is_correct"] is None)
    return render_template("quiz_results.html", attempt=attempt, quiz=quiz, rows=rows, pending=pending,
                           pct=round(100 * attempt["score"] / attempt["total"]) if attempt["total"] else 0)


@bp.route("/study/attempts/<int:attempt_id>/mark/<int:response_id>", methods=["POST"])
@login_required
def mark_response(attempt_id, response_id):
    """The student decides whether a written answer that did not match the key was right."""
    db = get_db()
    owned_or_404(db, "quiz_attempts", attempt_id)
    row = db.execute("SELECT id FROM quiz_responses WHERE id = ? AND attempt_id = ? AND is_correct IS NULL",
                     (response_id, attempt_id)).fetchone()
    if row is None:
        abort(404)
    verdict = 1 if request.form.get("verdict") == "correct" else 0
    db.execute("UPDATE quiz_responses SET is_correct = ? WHERE id = ?", (verdict, response_id))
    db.execute("""UPDATE quiz_attempts SET score = (SELECT COUNT(*) FROM quiz_responses WHERE attempt_id = ? AND is_correct = 1)
                  WHERE id = ?""", (attempt_id, attempt_id))
    db.commit()
    return redirect(url_for("quizzes.results", attempt_id=attempt_id) + "#r" + str(response_id))
