(function () {
  // Formatting toolbar: wrap the selection in Markdown markers.
  const body = document.getElementById("body");
  document.querySelectorAll("[data-md-before]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (!body) return;
      const b = btn.dataset.mdBefore, a = btn.dataset.mdAfter;
      const s = body.selectionStart, e = body.selectionEnd, sel = body.value.slice(s, e);
      body.setRangeText(b + sel + a, s, e, "end");
      body.focus();
      body.dispatchEvent(new Event("input", { bubbles: true }));
    });
  });
  const count = document.getElementById("body-count");
  if (body && count) body.addEventListener("input", function () { count.textContent = body.value.length; });

  // Autosave (edit page only): shows Saved / Unsaved / Save failed.
  const form = document.getElementById("note-form");
  const status = document.getElementById("save-status");
  if (form && form.dataset.autosave && status) {
    let timer = null, dirty = false, saving = false;
    const show = function (text, cls) { status.textContent = text; status.className = "badge " + cls; };
    const save = function () {
      if (saving) { timer = setTimeout(save, 1000); return; }
      saving = true; show("Saving…", "text-bg-info");
      fetch(form.dataset.autosave, { method: "POST", body: new FormData(form), headers: { "X-Requested-With": "fetch" } })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok && j.ok, j: j }; }); })
        .then(function (res) {
          saving = false;
          if (res.ok) { dirty = false; show("All changes saved", "text-bg-success"); }
          else { show("Not saved: " + (res.j.error || "error"), "text-bg-danger"); }
        })
        .catch(function () {
          saving = false; show("Save failed. Your text is still here; retrying…", "text-bg-danger");
          timer = setTimeout(save, 10000);
        });
    };
    form.addEventListener("input", function () {
      dirty = true; show("Unsaved changes", "text-bg-warning");
      clearTimeout(timer); timer = setTimeout(save, 1500);
    });
    form.addEventListener("submit", function () { dirty = false; });
    window.addEventListener("beforeunload", function (e) { if (dirty) { e.preventDefault(); e.returnValue = ""; } });
  }

  // Import: show upload progress with XHR (falls back to a normal form post).
  const imp = document.getElementById("import-form");
  if (imp && window.XMLHttpRequest && window.FormData) {
    imp.addEventListener("submit", function (ev) {
      ev.preventDefault();
      const bar = document.getElementById("import-progress");
      const inner = bar.querySelector(".progress-bar");
      bar.classList.remove("d-none");
      document.getElementById("import-btn").disabled = true;
      const xhr = new XMLHttpRequest();
      xhr.open("POST", imp.action);
      xhr.upload.onprogress = function (e) { if (e.lengthComputable) inner.style.width = Math.round(100 * e.loaded / e.total) + "%"; };
      xhr.onload = function () { window.location.href = xhr.responseURL || imp.action; };
      xhr.onerror = function () { alert("Upload failed. Check your connection and try again."); document.getElementById("import-btn").disabled = false; };
      xhr.send(new FormData(imp));
    });
  }
})();
