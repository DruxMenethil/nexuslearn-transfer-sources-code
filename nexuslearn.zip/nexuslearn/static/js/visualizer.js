(function () {
  var $ = function (id) { return document.getElementById(id); };
  var form = $("viz-form"), steps = [], idx = 0, timer = null, trace = null;
  function setInfo(algo) {
    var i = window.VIZ_INFO[algo];
    $("algo-name").textContent = i.name; $("algo-explain").textContent = i.explain;
    $("algo-time").textContent = i.time; $("algo-space").textContent = i.space;
    var search = algo === "linear" || algo === "binary";
    $("order-row").hidden = search; $("target-row").hidden = !search;
  }
  $("algorithm").addEventListener("change", function () { setInfo(this.value); });
  setInfo($("algorithm").value);

  document.querySelectorAll("[data-sample]").forEach(function (b) {
    b.addEventListener("click", function () {
      var n = 8, a = [], k = b.dataset.sample, i;
      for (i = 0; i < n; i++) a.push(Math.floor(Math.random() * 90) + 5);
      if (k === "sorted") a.sort(function (x, y) { return x - y; });
      if (k === "reverse") a.sort(function (x, y) { return y - x; });
      if (k === "dupes") a = [4, 7, 4, 2, 7, 2, 9, 4];
      $("array").value = a.join(", ");
    });
  });

  function draw() {
    var s = steps[idx], max = Math.max.apply(null, s.array.map(Math.abs).concat([1])), bars = $("bars");
    bars.textContent = "";
    s.array.forEach(function (v, i) {
      var d = document.createElement("div"), cls = "viz-bar";
      if (s.low !== undefined && i >= s.low && i <= s.high) cls += " viz-range";
      if ((s.sorted || []).indexOf(i) >= 0) cls += " viz-sorted";
      if (s.compare.indexOf(i) >= 0) cls += " viz-compare";
      if (s.swap.indexOf(i) >= 0) cls += " viz-swap";
      if (s.found === i) cls += " viz-found";
      d.className = cls; d.style.height = Math.max(4, Math.round(100 * Math.abs(v) / max)) + "%";
      var l = document.createElement("span"); l.textContent = v; d.appendChild(l); bars.appendChild(d);
    });
    $("note").textContent = s.note;
    $("s-step").textContent = idx + " / " + (steps.length - 1);
    $("s-comp").textContent = s.comparisons; $("s-swap").textContent = s.swaps; $("s-pass").textContent = s.passes;
    $("prev").disabled = $("reset").disabled = idx === 0; $("next").disabled = idx === steps.length - 1;
    $("final-box").hidden = idx !== steps.length - 1;
    if (idx === steps.length - 1) $("final").textContent = trace.final.join(", ") + (trace.found !== undefined ? "  (found at index " + trace.found + ")" : "");
    if (idx === steps.length - 1) stop();
  }
  function stop() { clearInterval(timer); timer = null; $("play").textContent = "Play"; }
  function play() {
    if (timer) return stop();
    if (idx === steps.length - 1) idx = 0;
    $("play").textContent = "Pause";
    var delay = 1100 - 100 * parseInt($("speed").value, 10);
    timer = setInterval(function () { if (idx < steps.length - 1) { idx++; draw(); } else stop(); }, delay);
  }
  $("play").onclick = play;
  $("next").onclick = function () { stop(); if (idx < steps.length - 1) { idx++; draw(); } };
  $("prev").onclick = function () { stop(); if (idx > 0) { idx--; draw(); } };
  $("reset").onclick = function () { stop(); idx = 0; draw(); };
  $("speed").addEventListener("input", function () { if (timer) { stop(); play(); } });

  form.addEventListener("submit", function (e) {
    e.preventDefault(); stop();
    var q = new URLSearchParams(new FormData(form)), err = $("viz-error");
    fetch("/learn/visualizer/trace?" + q.toString())
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
      .then(function (res) {
        if (!res.ok) { err.textContent = res.j.error || "Something went wrong."; err.hidden = false; return; }
        err.hidden = true; trace = res.j; steps = trace.steps; idx = 0;
        $("original").textContent = trace.input.join(", ") + (trace.notice ? "  — " + trace.notice : "");
        ["play"].forEach(function (id) { $(id).disabled = false; }); draw();
      })
      .catch(function () { err.textContent = "Could not reach the server. Try again."; err.hidden = false; });
  });
})();
