/* Copy-to-clipboard buttons for the snippet library. */
document.querySelectorAll("[data-copy]").forEach((button) => {
  button.addEventListener("click", async () => {
    const text = document.getElementById(button.dataset.copy).textContent;
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch (e) {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.append(area);
      area.select();
      try { ok = document.execCommand("copy"); } catch (err) { ok = false; }
      area.remove();
    }
    const original = button.textContent;
    button.textContent = ok ? "Copied!" : "Copy failed";
    setTimeout(() => { button.textContent = original; }, 1500);
  });
});
