(function () {
  var data = document.getElementById("cards-json");
  if (!data) return;
  var queue = JSON.parse(data.textContent), total = queue.length, reviewed = 0, counts = { difficult: 0, uncertain: 0, easy: 0 };
  var face = document.getElementById("card-face"), reveal = document.getElementById("reveal");
  var rate = document.getElementById("rate"), note = document.getElementById("rate-note");
  var csrf = document.getElementById("csrf").value, err = document.getElementById("err"), showing = false;
  function el(tag, text, cls) { var e = document.createElement(tag); e.textContent = text; if (cls) e.className = cls; return e; }
  function render() {
    face.textContent = "";
    if (!queue.length) { return finish(); }
    var c = queue[0];
    face.appendChild(el("div", c.front));
    if (showing) {
      face.appendChild(el("hr"));
      face.appendChild(el("div", c.back));
      if (c.example) face.appendChild(el("div", "Example: " + c.example, "small text-secondary mt-2"));
      if (c.explanation) face.appendChild(el("div", c.explanation, "small text-secondary mt-1"));
    }
    reveal.hidden = showing; rate.hidden = !showing; note.hidden = !showing;
    document.getElementById("scount").textContent = reviewed + " reviewed · " + queue.length + " left in the queue";
    document.getElementById("sprog").style.width = Math.round(100 * reviewed / (reviewed + queue.length)) + "%";
  }
  function finish() {
    reveal.hidden = rate.hidden = note.hidden = true; face.hidden = true;
    document.getElementById("done").hidden = false;
    document.getElementById("summary").textContent = reviewed + " reviews: " + counts.easy + " easy, " + counts.uncertain + " uncertain, " + counts.difficult + " difficult.";
    document.getElementById("sprog").style.width = "100%";
  }
  reveal.onclick = function () { showing = true; render(); rate.querySelector("button").focus(); };
  rate.addEventListener("click", function (e) {
    var b = e.target.closest("button[data-rating]"); if (!b) return;
    var r = b.dataset.rating, card = queue[0];
    rate.querySelectorAll("button").forEach(function (x) { x.disabled = true; });
    var body = new URLSearchParams(); body.append("csrf_token", csrf); body.append("rating", r);
    fetch("/study/cards/" + card.id + "/review", { method: "POST", body: body })
      .then(function (res) { return res.json().then(function (j) { if (!res.ok) throw new Error(j.error || "Could not save"); }); })
      .then(function () {
        err.hidden = true; reviewed += 1; counts[r] += 1; queue.shift();
        if (r === "difficult") queue.push(card);   // missed cards return later in this session
        showing = false; render();
      })
      .catch(function (ex) { err.textContent = "Your rating was not saved: " + ex.message + ". Try again."; err.hidden = false; })
      .finally(function () { rate.querySelectorAll("button").forEach(function (x) { x.disabled = false; }); });
  });
  document.addEventListener("keydown", function (e) {
    if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
    if (e.key === " " && !showing && queue.length) { e.preventDefault(); reveal.click(); }
  });
  render();
})();
