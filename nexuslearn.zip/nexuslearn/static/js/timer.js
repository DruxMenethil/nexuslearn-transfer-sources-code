/* Focus Mode front end. The server owns the real timer state; this script only
   displays a countdown and re-syncs with the server often. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const boot = JSON.parse($("boot").textContent);
  const csrf = $("csrf").value;
  const U = boot.urls;
  const baseTitle = document.title;
  const KIND_LABEL = { focus: "Focus", break: "Break", long_break: "Long break" };

  let state = boot.state;
  let deadline = 0;          // local Date.now() at which the running session ends
  let settling = false;
  let reloading = false;

  const fmt = (seconds) => {
    const s = Math.max(0, Math.ceil(seconds));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    const pad = (n) => String(n).padStart(2, "0");
    return (h ? `${h}:${pad(m)}` : pad(m)) + ":" + pad(sec);
  };

  function message(text, color) {
    const box = $("msg");
    box.replaceChildren();
    if (!text) return;
    const div = document.createElement("div");
    div.className = `alert alert-${color} mb-0`;
    div.textContent = text;
    box.append(div);
  }

  const remaining = () => {
    const a = state.active;
    return a.status === "running" ? Math.max(0, (deadline - Date.now()) / 1000) : a.remaining_seconds;
  };

  function tick() {
    const a = state.active;
    if (!a) return;
    const left = remaining();
    $("clock").textContent = fmt(left);
    $("bar").style.width = `${Math.min(100, (100 * (a.planned_seconds - left)) / a.planned_seconds)}%`;
    document.title = `${fmt(left)} · ${KIND_LABEL[a.kind]}`;
    if (a.status === "running" && left <= 0 && !settling) settle();
  }

  function render() {
    const a = state.active;
    $("idle").classList.toggle("d-none", !!a);
    $("controls").classList.toggle("d-none", !a);
    const hint = $("break-hint");
    if (!a) {
      $("phase").className = "badge text-bg-secondary mb-2";
      $("phase").textContent = "Ready";
      $("clock").textContent = fmt(Number($("minutes").value || boot.defaults.focus) * 60);
      $("bar").style.width = "0%";
      $("meta").textContent = "\u00a0";
      document.title = baseTitle;
      const suggested = state.next_break;
      hint.classList.toggle("d-none", suggested !== "long_break");
      hint.textContent = suggested === "long_break" ? "You have earned a long break." : "";
      return;
    }
    const running = a.status === "running";
    $("phase").className = `badge mb-2 text-bg-${a.kind === "focus" ? "info" : "success"}`;
    $("phase").textContent = KIND_LABEL[a.kind] + (running ? "" : " · paused");
    const bits = [a.subject, a.task && `Task: ${a.task}`, a.project && `Project: ${a.project}`].filter(Boolean);
    $("meta").textContent = bits.length ? bits.join(" · ") : "\u00a0";
    $("pause").classList.toggle("d-none", !running);
    $("resume").classList.toggle("d-none", running);
    $("finish").classList.toggle("d-none", a.kind !== "focus");
    $("reset").textContent = a.kind === "focus" ? "Reset" : "Skip break";
    tick();
  }

  function setState(next) {
    state = next;
    if (next.active && next.active.status === "running") deadline = Date.now() + next.active.remaining_seconds * 1000;
    if (next.completed) onCompleted(next.completed);
    render();
  }

  function onCompleted(done) {
    const mins = Math.max(1, Math.round(done.duration_seconds / 60));
    message(done.kind === "focus"
      ? `Focus session complete: ${mins} min recorded. Nice work!`
      : "Break finished. Ready when you are.", "success");
    if (!reloading) {            // refresh totals and history once
      reloading = true;
      setTimeout(() => location.reload(), 2500);
    }
  }

  async function call(url, method, fields) {
    const options = { method };
    if (method === "POST") {
      const body = new FormData();
      body.append("csrf_token", csrf);
      Object.entries(fields || {}).forEach(([k, v]) => body.append(k, v));
      options.body = body;
    }
    const resp = await fetch(url, options);
    let data = null;
    try { data = await resp.json(); } catch (e) { /* not JSON */ }
    if (!data) throw new Error(`Server error (${resp.status}). Reload the page.`);
    if (!resp.ok) throw new Error(data.error || "Request failed.");
    return data;
  }

  async function act(url, fields) {
    message("");
    try { setState(await call(url, "POST", fields)); }
    catch (e) { message(e.message, "danger"); sync(); }
  }

  async function sync() {
    try { setState(await call(U.get_state, "GET")); } catch (e) { /* offline: keep counting locally */ }
  }

  async function settle() {
    settling = true;
    await sync();
    setTimeout(() => { settling = false; }, 1000);
  }

  // ---- controls ----
  $("start-focus").addEventListener("click", () => act(U.start, {
    kind: "focus", minutes: $("minutes").value, subject: $("subject").value,
    task_id: $("task").value, project_id: $("project").value,
  }));
  document.querySelectorAll("[data-kind]").forEach((b) => b.addEventListener("click", () => act(U.start, { kind: b.dataset.kind })));
  $("pause").addEventListener("click", () => act(U.pause));
  $("resume").addEventListener("click", () => act(U.resume));
  $("finish").addEventListener("click", () => {
    if (confirm("Finish now and record the time studied so far?")) act(U.finish);
  });
  $("reset").addEventListener("click", () => {
    const what = state.active && state.active.kind === "focus" ? "Discard this session? Nothing will be recorded." : "Skip this break?";
    if (confirm(what)) act(U.reset);
  });
  $("minutes").addEventListener("input", () => { if (!state.active) render(); });
  $("task").addEventListener("change", (e) => {
    const subject = e.target.selectedOptions[0].dataset.subject;
    if (subject && !$("subject").value) $("subject").value = subject;
  });

  // ---- keep in step with the server ----
  document.addEventListener("visibilitychange", () => { if (!document.hidden) sync(); });
  setInterval(() => { if (state.active) sync(); }, 30000);
  setInterval(tick, 250);

  if (state.active && state.active.status === "running") deadline = Date.now() + state.active.remaining_seconds * 1000;
  render();
})();
