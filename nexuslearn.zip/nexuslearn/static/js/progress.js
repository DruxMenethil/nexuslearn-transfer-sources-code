/* Progress Center charts. Data comes from the server (saved records only). */
(() => {
  "use strict";
  if (typeof Chart === "undefined") return;       // CDN blocked: the numbers above still show
  const data = JSON.parse(document.getElementById("chart-data").textContent);
  const css = getComputedStyle(document.documentElement);
  const accent = css.getPropertyValue("--nl-accent").trim() || "#22d3ee";
  const text = getComputedStyle(document.body).color;
  const grid = css.getPropertyValue("--nl-border").trim() || "#1f2d4a";

  function bar(id, datasets, stacked) {
    const canvas = document.getElementById(id);
    if (!canvas) return;
    new Chart(canvas, {
      type: "bar",
      data: { labels: data.labels, datasets },
      options: {
        responsive: true,
        plugins: { legend: { display: datasets.length > 1, labels: { color: text } } },
        scales: {
          x: { stacked, ticks: { color: text, maxTicksLimit: 10 }, grid: { color: grid } },
          y: { stacked, beginAtZero: true, ticks: { color: text, precision: 0 }, grid: { color: grid } },
        },
      },
    });
  }
  bar("chart-tasks", [{ label: "Tasks completed", data: data.tasks_completed, backgroundColor: accent }], false);
  bar("chart-study", [{ label: "Minutes", data: data.study_minutes, backgroundColor: accent }], false);
  bar("chart-cards", [{ label: "Reviews", data: data.cards_reviewed, backgroundColor: accent }], false);
  bar("chart-ex", [
    { label: "Passed", data: data.attempts_passed, backgroundColor: accent },
    { label: "Not passing", data: data.attempts_failed, backgroundColor: "#64748b" },
  ], true);
})();
