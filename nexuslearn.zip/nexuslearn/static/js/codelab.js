/* CodeLab front end: editor, tabs, running code, rendering results.
   All text from the server is inserted with textContent (never innerHTML). */
(() => {
  "use strict";
  const root = document.getElementById("codelab");
  const $ = (sel) => root.querySelector(sel);
  const csrf = $("#csrf").value;
  const boot = JSON.parse(document.getElementById("boot").textContent);
  const URLS = boot.urls;
  const project = boot.project;          // set when opened with ?project=ID
  const exercise = boot.exercise;        // set when opened with ?exercise=SLUG
  const RUNNABLE = { python: true, sql: true, html: true, javascript: true, c: true, cpp: true };
  const CAPS = boot.caps || {};          // what this server can really run (see execution.py)
  const available = (l) => !!RUNNABLE[l] && !(CAPS[l] && CAPS[l].available === false);
  const STDIN_LANGS = { python: true, javascript: true, c: true, cpp: true };
  const EXT = { python: ".py", sql: ".sql", javascript: ".js", c: ".c", cpp: ".cpp" };
  const LANG_LABELS = { python: "Python", sql: "SQL", html: "HTML + CSS", javascript: "JavaScript", c: "C", cpp: "C++" };

  function modeFor(name) {
    const ext = name.includes(".") ? name.slice(name.lastIndexOf(".")).toLowerCase() : "";
    return { ".py": "python", ".sql": "text/x-sql", ".html": "htmlmixed", ".css": "css", ".js": "javascript",
             ".c": "text/x-csrc", ".h": "text/x-csrc", ".cpp": "text/x-c++src", ".hpp": "text/x-c++src",
             ".json": "application/json" }[ext] || "text/plain";
  }

  const LANGS = {
    python: { files: [["main.py", "python"]] },
    sql: { files: [["query.sql", "text/x-sql"]] },
    html: { files: [["index.html", "htmlmixed"], ["style.css", "css"]] },
    javascript: { files: [["main.js", "javascript"]] },
    c: { files: [["main.c", "text/x-csrc"]] },
    cpp: { files: [["main.cpp", "text/x-c++src"]] },
  };

  const EXAMPLES = {
    python: [
      { title: "Hello & variables", files: { "main.py": `name = "NexusLearn"
year = 2026
print(f"Hello from {name}!")
print("Next year is", year + 1)
` } },
      { title: "Loops & conditions (FizzBuzz)", files: { "main.py": `for n in range(1, 16):
    if n % 15 == 0:
        print("FizzBuzz")
    elif n % 3 == 0:
        print("Fizz")
    elif n % 5 == 0:
        print("Buzz")
    else:
        print(n)
` } },
      { title: "Functions, lists & dictionaries", files: { "main.py": `def word_counts(text):
    counts = {}
    for word in text.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return counts

counts = word_counts("the quick brown fox jumps over the lazy dog the end")
for word, n in sorted(counts.items(), key=lambda item: -item[1])[:3]:
    print(word, n)
` } },
      { title: "Input (uses the Program input box)", files: { "main.py": `name = input("Your name: ")
age = int(input("Your age: "))
print(f"Hi {name}! In 10 years you will be {age + 10}.")
` } },
      { title: "Runtime error (see the traceback)", files: { "main.py": `numbers = [1, 2, 3]
print(numbers[5])
` } },
    ],
    sql: [
      { title: "SELECT basics", files: { "query.sql": `-- Tables: students, courses, enrollments
SELECT name, major, gpa
FROM students
WHERE gpa >= 3.5
ORDER BY gpa DESC;
` } },
      { title: "JOIN + GROUP BY", files: { "query.sql": `SELECT c.code, c.title, COUNT(*) AS enrolled
FROM enrollments e
JOIN courses c ON c.id = e.course_id
GROUP BY c.id
ORDER BY enrolled DESC;
` } },
      { title: "INSERT / UPDATE / DELETE", files: { "query.sql": `INSERT INTO students (name, major, year, gpa) VALUES ('Your Name', 'Computer Science', 1, 3.0);
UPDATE students SET gpa = 3.3 WHERE name = 'Your Name';
SELECT * FROM students WHERE name = 'Your Name';
DELETE FROM students WHERE name = 'Your Name';
` } },
      { title: "CREATE TABLE", files: { "query.sql": `CREATE TABLE notes (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT
);
INSERT INTO notes (title, body) VALUES ('First note', 'SQL is fun');
SELECT * FROM notes;
` } },
    ],
    javascript: [
      { title: "Hello & arrays", files: { "main.js": `const names = ["Ada", "Grace", "Linus"];
for (const name of names) {
  console.log("Hello, " + name + "!");
}
console.log(names.map((n) => n.length));
` } },
      { title: "Read input (stdin)", files: { "main.js": `const fs = require("fs");
const lines = fs.readFileSync(0, "utf8").trim().split("\n");
const total = lines.map(Number).reduce((a, b) => a + b, 0);
console.log("Sum:", total);
` } },
      { title: "Uncaught error (see the stack trace)", files: { "main.js": `function boom() {
  throw new Error("something went wrong");
}
boom();
` } },
    ],
    c: [
      { title: "Hello, C", files: { "main.c": `#include <stdio.h>

int main(void)
{
    printf("Hello, C!\n");
    return 0;
}
` } },
      { title: "Read input (scanf)", files: { "main.c": `#include <stdio.h>

int main(void)
{
    int a, b;
    if (scanf("%d %d", &a, &b) != 2)
    {
        printf("Please enter two integers in Program input.\n");
        return 1;
    }
    printf("%d + %d = %d\n", a, b, a + b);
    return 0;
}
` } },
      { title: "Compile error (see the line numbers)", files: { "main.c": `#include <stdio.h>

int main(void)
{
    printf("missing semicolon")
    return 0;
}
` } },
    ],
    cpp: [
      { title: "Hello, C++", files: { "main.cpp": `#include <iostream>
#include <vector>

int main()
{
    std::vector<int> numbers = {3, 1, 4, 1, 5};
    int sum = 0;
    for (int n : numbers) sum += n;
    std::cout << "Hello, C++! Sum = " << sum << std::endl;
    return 0;
}
` } },
      { title: "Read input (cin)", files: { "main.cpp": `#include <iostream>
#include <string>

int main()
{
    std::string name;
    std::getline(std::cin, name);
    std::cout << "Hello, " << name << "!" << std::endl;
    return 0;
}
` } },
    ],
    html: [
      { title: "Profile card", files: {
        "index.html": `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="card">
    <h1>Hello, web!</h1>
    <p>Edit index.html and style.css, then press Run.</p>
    <button id="btn">Click me</button>
    <p id="msg"></p>
  </div>
  <script>
    document.getElementById("btn").addEventListener("click", () => {
      document.getElementById("msg").textContent = "JavaScript works in the preview.";
    });
  </script>
</body>
</html>
`,
        "style.css": `body { font-family: system-ui, sans-serif; background: #0b1220; color: #e6f1ff; display: grid; place-items: center; min-height: 100vh; margin: 0; }
.card { background: #111a2e; border: 1px solid #22d3ee; border-radius: 14px; padding: 2rem; max-width: 22rem; text-align: center; }
button { background: #22d3ee; border: 0; border-radius: 8px; padding: .5rem 1rem; font-weight: 600; cursor: pointer; }
`,
      } },
    ],
  };

  // ---- state & elements ----
  const editor = CodeMirror.fromTextArea($("#editor"), {
    theme: "dracula", lineNumbers: true, indentUnit: 4, lineWrapping: false,
    extraKeys: {
      "Ctrl-Enter": () => run(), "Cmd-Enter": () => run(),
      "Ctrl-S": () => saveFile(), "Cmd-S": () => saveFile(),
      Tab: (cm) => (cm.somethingSelected() ? cm.indentSelection("add") : cm.replaceSelection("    ", "end")),
    },
  });
  const docs = {};
  let lang = "python", fileName = "main.py", running = false, saveTimer = null, previewTimer = null;
  const output = $("#output"), preview = $("#preview"), statusEl = $("#status"), statusText = $("#status-text");

  const draftKey = (l, f) => `nl:draft:${l}/${f}`;
  const storageGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const storageSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } };
  const storageDel = (k) => { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } };

  function getDoc(f, l = lang) {
    const key = (project ? "project" : exercise ? "exercise" : l) + "/" + f;
    if (!docs[key]) {
      let text, mode;
      if (project) {
        text = project.files.find((x) => x.filename === f).content;
        mode = modeFor(f);
      } else if (exercise) {
        mode = modeFor(f);
        const draft = storageGet(currentDraftKey());
        text = draft !== null ? draft : (exercise.last_code !== null ? exercise.last_code : exercise.starter);
      } else {
        mode = LANGS[l].files.find((x) => x[0] === f)[1];
        const draft = storageGet(draftKey(l, f));
        text = draft !== null ? draft : EXAMPLES[l][0].files[f];
      }
      docs[key] = new CodeMirror.Doc(text, mode);
      docs[key].markClean();
    }
    return docs[key];
  }

  const fileNames = () => (project ? project.files.map((f) => f.filename)
    : exercise ? [exercise.filename] : LANGS[lang].files.map((f) => f[0]));
  const currentDraftKey = () => (exercise ? "nl:draft:exercise/" + exercise.slug : draftKey(lang, fileName));
  let dirtyAny = false;

  function updateDirty() {
    if (!project) return;
    let any = false;
    $("#tabs").querySelectorAll("button").forEach((b) => {
      const d = docs["project/" + b.dataset.file];
      const dirty = !!d && !d.isClean();
      b.textContent = b.dataset.file + (dirty ? " ●" : "");
      any = any || dirty;
    });
    dirtyAny = any;
    $("#dirty").classList.toggle("d-none", !any);
  }

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  // ---- language / file switching ----
  function showFile(f) {
    fileName = f;
    editor.swapDoc(getDoc(f));
    $("#tabs").querySelectorAll("button").forEach((b) => b.classList.toggle("active", b.dataset.file === f));
    editor.refresh();
  }

  function setLang(l) {
    lang = project ? project.language : (exercise ? exercise.language : l);
    $("#lang").value = lang;
    const tabs = $("#tabs");
    tabs.replaceChildren();
    fileNames().forEach((f) => {
      const li = el("li", "nav-item");
      const b = el("button", "nav-link", f);
      b.type = "button"; b.dataset.file = f;
      b.addEventListener("click", () => showFile(f));
      li.append(b); tabs.append(li);
    });
    if (!project && !exercise) {
      const ex = $("#examples");
      ex.replaceChildren(new Option("Examples…", ""));
      EXAMPLES[lang].forEach((e, i) => ex.append(new Option(e.title, String(i))));
    }
    const runnable = available(lang);
    $("#run").disabled = !runnable;
    $("#stdin-wrap").classList.toggle("d-none", !STDIN_LANGS[lang]);
    $("#reset-db").classList.toggle("d-none", lang !== "sql" || !!exercise);
    $("#auto-wrap").classList.toggle("d-none", !(lang === "html" && runnable));
    output.classList.toggle("d-none", lang === "html");
    preview.classList.toggle("d-none", lang !== "html");
    $("#run-label").textContent = lang === "html" ? "▶ Refresh preview" : "▶ Run";
    output.replaceChildren();
    setStatus("secondary", "Ready", "");
    if (!runnable) {
      setStatus("secondary", "Edit only", "");
      message((CAPS[lang] && CAPS[lang].reason) || `Running ${LANG_LABELS[lang]} code is not available on this server. You can still edit and save files.`, "info");
    }
    const names = fileNames();
    if (names.length) {
      showFile(project && project.open && names.includes(project.open) ? project.open : names[0]);
    } else {
      editor.swapDoc(new CodeMirror.Doc("", "text/plain"));
      editor.setOption("readOnly", "nocursor");
      message("This project has no files. Add one on the project page.", "info");
    }
    if (lang === "html" && runnable) updatePreview();
  }

  // ---- status & output rendering ----
  function setStatus(color, label, text) {
    statusEl.className = "badge text-bg-" + color;
    statusEl.textContent = label;
    statusText.textContent = text || "";
  }

  function message(text, color) {
    output.replaceChildren(el("div", `alert alert-${color} mb-0`, text));
  }

  function showRun(data, httpOk) {
    output.replaceChildren();
    if (!httpOk || data.error) {
      const busy = data.status === "busy";
      setStatus(busy ? "warning" : "secondary", busy ? "Busy" : data.status === "unavailable" ? "Unavailable" : "Not run", "");
      message(data.error || "Could not run the program.", "warning");
      return;
    }
    const t = `${data.duration_ms} ms`;
    const where = data.sandbox ? ` · sandbox: ${data.sandbox}` : "";
    if (data.status === "ok") setStatus("success", "Finished", t + where);
    else if (data.status === "compile_error") setStatus("danger", "Compile error", "the program was not run" + where);
    else if (data.status === "timeout") setStatus("warning", "Timed out", `stopped after ${data.timeout_s} s`);
    else if (data.status === "output_limit") setStatus("warning", "Output limit", "the program wrote too much");
    else setStatus("danger", data.signal ? "Crashed" : "Error", `exit code ${data.exit_code} · ${t}`);
    if (data.compile_output) {
      const bad = data.status === "compile_error";
      output.append(el("div", "small text-secondary", bad ? "Compiler errors" : "Compiler warnings"));
      output.append(el("pre", `cl-pre ${bad ? "text-danger" : "text-warning"}`, data.compile_output));
    }
    if (data.stdout) output.append(el("pre", "cl-pre", data.stdout));
    if (data.stderr) output.append(el("pre", "cl-pre text-danger", data.stderr));
    if (data.status === "timeout") output.append(el("div", "small text-warning", "Your program ran longer than the allowed time. Check for infinite loops."));
    if (data.truncated || data.status === "output_limit") output.append(el("div", "small text-warning", "Output was cut off."));
    if (!data.stdout && !data.stderr && data.status === "ok") output.append(el("div", "text-secondary", "(the program printed nothing)"));
  }

  function showSql(data) {
    output.replaceChildren();
    if (data.status !== "ok") {
      setStatus("danger", "SQL error", "");
      output.append(el("div", "alert alert-danger", data.error || "SQL failed."));
      if (data.failed_statement) output.append(el("div", "small text-secondary", `Statement ${data.failed_statement} failed, so the whole script was rolled back.`));
      return;
    }
    setStatus("success", "Done", `${data.duration_ms} ms`);
    data.results.forEach((r) => {
      output.append(el("div", "small text-secondary mt-2", `Statement ${r.statement}: ${r.sql.split("\n")[0]}`));
      if (!r.columns) {
        output.append(el("div", "", r.rowcount === null ? "OK" : `${r.rowcount} row(s) affected`));
        return;
      }
      const wrap = el("div", "table-responsive");
      const table = el("table", "table table-sm table-striped cl-table");
      const head = el("tr");
      r.columns.forEach((c) => head.append(el("th", "", c)));
      table.append(el("thead")).firstChild.append(head);
      const body = el("tbody");
      r.rows.forEach((row) => {
        const tr = el("tr");
        row.forEach((v) => tr.append(v === null ? el("td", "text-secondary fst-italic", "NULL") : el("td", "", String(v))));
        body.append(tr);
      });
      table.append(body); wrap.append(table); output.append(wrap);
      output.append(el("div", "small text-secondary", `${r.rows.length} row(s)` + (r.truncated ? " (showing the first 200)" : "")));
    });
  }

  // ---- HTML preview (isolated iframe, no same-origin) ----
  function fileText(name) {
    if (project && !project.files.some((f) => f.filename === name)) return null;
    return getDoc(name, "html").getValue();
  }

  function buildPreview() {
    let html = fileText("index.html");
    if (html === null) return null;
    const style = `<style>\n${fileText("style.css") || ""}\n</style>`;
    const link = /<link\b[^>]*href\s*=\s*["']?(?:\.\/)?style\.css["']?[^>]*>/i;
    if (link.test(html)) html = html.replace(link, () => style);
    else if (/<\/head>/i.test(html)) html = html.replace(/<\/head>/i, () => style + "</head>");
    else html = style + html;
    const csp = '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; img-src data: https:; font-src data:">';
    const head = /<head(?=[\s>])[^>]*>/i, doctype = /^\s*<!doctype[^>]*>/i;
    if (head.test(html)) return html.replace(head, (m) => m + csp);
    if (doctype.test(html)) return html.replace(doctype, (m) => m + csp);
    return csp + html;
  }

  function updatePreview() {
    const built = buildPreview();
    if (built === null) {
      preview.srcdoc = "";
      setStatus("warning", "No index.html", "add an index.html file to preview this project");
      return;
    }
    preview.srcdoc = built;
    setStatus("success", "Preview updated", "");
  }

  // ---- running ----
  function setBusy(on) {
    running = on;
    $("#run").disabled = on || !available(lang);
    $("#run-spinner").classList.toggle("d-none", !on);
    if (on) setStatus("info", "Running…", "");
  }

  async function run() {
    if (running) return;
    if (!available(lang)) return;
    if (lang === "html") { updatePreview(); return; }
    if (project && !fileName.endsWith(EXT[lang])) {
      setStatus("warning", "Not run", "");
      message(`Open a ${EXT[lang]} file to run it.`, "warning");
      return;
    }
    setBusy(true);
    try {
      const body = new FormData();
      body.append("csrf_token", csrf);
      body.append("code", editor.getValue());
      if (STDIN_LANGS[lang]) body.append("stdin", $("#stdin").value);
      if (lang === "sql" && exercise) body.append("scratch", "1");  // trials never touch your practice DB
      const resp = await fetch(URLS[lang], { method: "POST", body });
      let data = null;
      try { data = await resp.json(); } catch (e) { /* not JSON */ }
      if (!data) { setStatus("danger", "Error", ""); message(`Server error (${resp.status}). Reload the page and try again.`, "danger"); }
      else if (lang === "sql") showSql(data);
      else showRun(data, resp.ok);
    } catch (e) {
      setStatus("danger", "Offline", "");
      message("Could not reach the server.", "danger");
    } finally {
      setBusy(false);
    }
  }

  // ---- toolbar actions ----
  $("#run").addEventListener("click", run);
  $("#lang").addEventListener("change", (e) => setLang(e.target.value));
  $("#clear").addEventListener("click", () => { output.replaceChildren(); setStatus("secondary", "Ready", ""); });

  $("#examples").addEventListener("change", (e) => {
    const sel = e.target.value;
    e.target.value = "";
    if (sel === "") return;
    if (!confirm("Replace your current code with this example?")) return;
    const ex = EXAMPLES[lang][Number(sel)];
    Object.entries(ex.files).forEach(([f, text]) => { getDoc(f).setValue(text); storageSet(draftKey(lang, f), text); });
    if (lang === "html") updatePreview();
  });

  $("#reset").addEventListener("click", () => {
    if (!confirm("Reset to the starter code? Your changes will be lost.")) return;
    if (exercise) { getDoc(fileName).setValue(exercise.starter); storageDel(currentDraftKey()); return; }
    Object.entries(EXAMPLES[lang][0].files).forEach(([f, text]) => { getDoc(f).setValue(text); storageDel(draftKey(lang, f)); });
    if (lang === "html") updatePreview();
  });

  $("#reset-db").addEventListener("click", async () => {
    if (!confirm("Restore the practice database to its original sample data? Your tables and changes will be lost.")) return;
    const body = new FormData();
    body.append("csrf_token", csrf);
    try {
      const resp = await fetch(URLS.resetSql, { method: "POST", body });
      const data = await resp.json();
      setStatus("success", "Database reset", "");
      message(data.message || "Practice database restored.", "success");
    } catch (e) { message("Could not reset the database.", "danger"); }
  });

  // ---- project saving ----
  async function saveFile() {
    if (!project) return;
    const pf = project.files.find((f) => f.filename === fileName);
    if (!pf) return;
    const doc = getDoc(fileName);
    const body = new FormData();
    body.append("csrf_token", csrf);
    body.append("content", doc.getValue());
    try {
      const resp = await fetch(pf.save_url, { method: "POST", body });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Save failed");
      pf.content = doc.getValue();
      doc.markClean();
      updateDirty();
      setStatus("success", "Saved", fileName);
    } catch (e) {
      setStatus("danger", "Save failed", "");
      if (lang !== "html") message(String(e.message || e), "danger");
    }
  }

  // ---- "save as project / snippet" dialog (standalone mode) ----
  const modalEl = $("#save-modal");
  const modal = new bootstrap.Modal(modalEl);
  let saveKind = null;

  function openSaveDialog(kind) {
    saveKind = kind;
    $("#save-modal-title").textContent = kind === "project" ? "Save as project" : "Save as snippet";
    $("#save-name-label").textContent = kind === "project" ? "Project name" : "Snippet title";
    $("#save-tags-wrap").classList.toggle("d-none", kind !== "snippet");
    $("#save-name").value = ""; $("#save-tags").value = ""; $("#save-error").textContent = "";
    modal.show();
  }
  modalEl.addEventListener("shown.bs.modal", () => $("#save-name").focus());
  $("#save-name").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#save-confirm").click(); });

  $("#save-confirm").addEventListener("click", async () => {
    const name = $("#save-name").value.trim();
    if (!name) { $("#save-error").textContent = "Please enter a name."; return; }
    const body = new FormData();
    body.append("csrf_token", csrf);
    if (saveKind === "project") {
      const files = {};
      fileNames().forEach((f) => { files[f] = getDoc(f).getValue(); });
      body.append("name", name); body.append("language", lang); body.append("files", JSON.stringify(files));
    } else {
      body.append("title", name); body.append("tags", $("#save-tags").value);
      body.append("language", fileName.endsWith(".css") ? "css" : lang);
      body.append("code", editor.getValue());
    }
    try {
      const resp = await fetch(saveKind === "project" ? URLS.saveProject : URLS.saveSnippet, { method: "POST", body });
      const data = await resp.json();
      if (!resp.ok) { $("#save-error").textContent = data.error || "Could not save."; return; }
      modal.hide();
      const alert = el("div", "alert alert-success mt-2 mb-0", saveKind === "project" ? "Saved as a project. " : "Saved to your snippets. ");
      const link = el("a", "", saveKind === "project" ? "Open it" : "View library");
      link.href = data.url;
      alert.append(link);
      if (!$("#output").classList.contains("d-none")) output.prepend(alert);
      setStatus("success", "Saved", name);
    } catch (e) { $("#save-error").textContent = "Could not reach the server."; }
  });

  $("#save").addEventListener("click", saveFile);
  $("#save-project").addEventListener("click", () => openSaveDialog("project"));
  $("#save-snippet").addEventListener("click", () => openSaveDialog("snippet"));
  window.addEventListener("beforeunload", (e) => { if (dirtyAny) { e.preventDefault(); e.returnValue = ""; } });

  editor.on("change", () => {
    if (project) {
      updateDirty();
    } else {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => storageSet(currentDraftKey(), editor.getValue()), 400);
    }
    if (lang === "html" && available("html") && $("#auto").checked) {
      clearTimeout(previewTimer);
      previewTimer = setTimeout(updatePreview, 700);
    }
  });

  // ---- exercise grading ----
  function showGrade(data, ok) {
    output.replaceChildren();
    if (!ok || data.error) {
      setStatus("danger", "Not graded", "");
      message(data.error || "Could not grade the submission.", "warning");
      return;
    }
    setStatus(data.passed ? "success" : "warning", data.passed ? "All tests passed" : `${data.tests_passed} / ${data.tests_total} tests passed`, "");
    if (data.passed) {
      const done = el("div", "alert alert-success", data.newly_completed ? "Exercise complete! Your progress was saved. " : "All tests passed again. ");
      const back = el("a", "", "Back to the exercise");
      back.href = exercise.url;
      done.append(back);
      output.append(done);
    } else {
      output.append(el("div", "small text-secondary mb-2", "Passing needs every test to match. Running without errors is not enough."));
    }
    data.tests.forEach((t) => {
      const box = el("div", "cl-test");
      const head = el("div", "d-flex justify-content-between");
      head.append(el("span", "", `Test ${t.n}${t.hidden ? " (hidden)" : ""}${t.label ? ": " + t.label : ""}`));
      head.append(el("span", `badge text-bg-${t.passed ? "success" : t.skipped ? "secondary" : "danger"}`, t.passed ? "Passed" : t.skipped ? "Skipped" : "Failed"));
      box.append(head);
      if (!t.passed) {
        if (t.error) box.append(el("pre", "cl-pre text-warning mt-1", t.error));
        if (!t.hidden && !t.skipped) {
          const show = (label, value) => {
            const text = typeof value === "string" ? value : value.columns.join(" | ") + "\n" + value.rows.map((r) => r.map((v) => (v === null ? "NULL" : v)).join(" | ")).join("\n");
            box.append(el("div", "small text-secondary mt-1", label));
            box.append(el("pre", "cl-pre", text));
          };
          if (t.input) show("Input / call", t.input);
          if (t.expected !== undefined) show("Expected", t.expected);
          if (t.actual !== undefined) show("Yours", t.actual);
        }
        if (t.hidden && !t.error) box.append(el("div", "small text-secondary mt-1", "A hidden test failed. Check edge cases such as empty or unusual input."));
      }
      output.append(box);
    });
  }

  async function submitExercise() {
    if (!exercise || running) return;
    setBusy(true);
    try {
      const body = new FormData();
      body.append("csrf_token", csrf);
      body.append("code", editor.getValue());
      const resp = await fetch(exercise.submit_url, { method: "POST", body });
      let data = null;
      try { data = await resp.json(); } catch (e) { /* not JSON */ }
      if (!data) { setStatus("danger", "Error", ""); message(`Server error (${resp.status}). Reload the page and try again.`, "danger"); }
      else showGrade(data, resp.ok);
    } catch (e) {
      setStatus("danger", "Offline", "");
      message("Could not reach the server.", "danger");
    } finally { setBusy(false); }
  }
  $("#submit").addEventListener("click", submitExercise);

  // ---- start up ----
  if (project) {
    $("#lang").replaceChildren(new Option(LANG_LABELS[project.language], project.language));
    $("#lang").disabled = true;
    $("#examples").classList.add("d-none");
    $("#reset").classList.add("d-none");
    $("#standalone-note").classList.add("d-none");
    $("#project-bar").classList.remove("d-none");
    $("#save").classList.remove("d-none");
    const link = $("#project-link");
    link.textContent = project.name; link.href = project.url;
    setLang(project.language);
  } else if (exercise) {
    $("#lang").replaceChildren(new Option(LANG_LABELS[exercise.language], exercise.language));
    $("#lang").disabled = true;
    $("#examples").classList.add("d-none");
    $("#standalone-note").classList.add("d-none");
    $("#submit").classList.remove("d-none");
    $("#exercise-card").classList.remove("d-none");
    $("#ex-title").textContent = exercise.title;
    $("#ex-link").href = exercise.url;
    $("#ex-instructions").textContent = exercise.instructions;
    exercise.hints.forEach((h, i) => {
      const d = el("details", "small mb-1");
      d.append(el("summary", "", `Hint ${i + 1}`));
      d.append(el("div", "ps-3", h));
      $("#ex-hints").append(d);
    });
    setLang(exercise.language);
  } else {
    $("#save-project").classList.remove("d-none");
    $("#save-snippet").classList.remove("d-none");
    const snip = boot.snippet;
    setLang(snip ? snip.language : (LANGS[boot.default_lang] ? boot.default_lang : "python"));
    if (snip) {
      const target = getDoc(LANGS[lang].files[0][0]);
      const starter = EXAMPLES[lang][0].files[LANGS[lang].files[0][0]];
      const current = target.getValue();
      if (current === starter || current === snip.code || confirm(`Replace your current ${LANG_LABELS[lang]} draft with the snippet "${snip.title}"?`)) {
        target.setValue(snip.code);
        if (lang === "html") updatePreview();
      }
    }
  }
})();
