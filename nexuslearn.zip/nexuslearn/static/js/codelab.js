/* CodeLab front end: editor, tabs, running code, rendering results.
   All text from the server is inserted with textContent (never innerHTML). */
(() => {
  "use strict";
  const root = document.getElementById("codelab");
  const $ = (sel) => root.querySelector(sel);
  const csrf = $("#csrf").value;
  const boot = JSON.parse(document.getElementById("boot").textContent);
  const URLS = boot.urls;
  const project = boot.project;          // set when opened with ?project=ID
  const RUNNABLE = { python: true, sql: true, html: true };
  const LANG_LABELS = { python: "Python", sql: "SQL", html: "HTML + CSS", javascript: "JavaScript", c: "C", cpp: "C++" };

  function modeFor(name) {
    const ext = name.includes(".") ? name.slice(name.lastIndexOf(".")).toLowerCase() : "";
    return { ".py": "python", ".sql": "text/x-sql", ".html": "htmlmixed", ".css": "css", ".js": "javascript",
             ".c": "text/x-csrc", ".h": "text/x-csrc", ".cpp": "text/x-c++src", ".hpp": "text/x-c++src",
             ".json": "application/json" }[ext] || "text/plain";
  }

  const LANGS = {
    python: { files: [["main.py", "python"]] },
    sql: { files: [["query.sql", "text/x-sql"]] },
    html: { files: [["index.html", "htmlmixed"], ["style.css", "css"]] },
  };

  const EXAMPLES = {
    python: [
      { title: "Hello & variables", files: { "main.py": `name = "NexusLearn"
year = 2026
print(f"Hello from {name}!")
print("Next year is", year + 1)
` } },
      { title: "Loops & conditions (FizzBuzz)", files: { "main.py": `for n in range(1, 16):
    if n % 15 == 0:
        print("FizzBuzz")
    elif n % 3 == 0:
        print("Fizz")
    elif n % 5 == 0:
        print("Buzz")
    else:
        print(n)
` } },
      { title: "Functions, lists & dictionaries", files: { "main.py": `def word_counts(text):
    counts = {}
    for word in text.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return counts

counts = word_counts("the quick brown fox jumps over the lazy dog the end")
for word, n in sorted(counts.items(), key=lambda item: -item[1])[:3]:
    print(word, n)
` } },
      { title: "Input (uses the Program input box)", files: { "main.py": `name = input("Your name: ")
age = int(input("Your age: "))
print(f"Hi {name}! In 10 years you will be {age + 10}.")
` } },
      { title: "Runtime error (see the traceback)", files: { "main.py": `numbers = [1, 2, 3]
print(numbers[5])
` } },
    ],
    sql: [
      { title: "SELECT basics", files: { "query.sql": `-- Tables: students, courses, enrollments
SELECT name, major, gpa
FROM students
WHERE gpa >= 3.5
ORDER BY gpa DESC;
` } },
      { title: "JOIN + GROUP BY", files: { "query.sql": `SELECT c.code, c.title, COUNT(*) AS enrolled
FROM enrollments e
JOIN courses c ON c.id = e.course_id
GROUP BY c.id
ORDER BY enrolled DESC;
` } },
      { title: "INSERT / UPDATE / DELETE", files: { "query.sql": `INSERT INTO students (name, major, year, gpa) VALUES ('Your Name', 'Computer Science', 1, 3.0);
UPDATE students SET gpa = 3.3 WHERE name = 'Your Name';
SELECT * FROM students WHERE name = 'Your Name';
DELETE FROM students WHERE name = 'Your Name';
` } },
      { title: "CREATE TABLE", files: { "query.sql": `CREATE TABLE notes (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT
);
INSERT INTO notes (title, body) VALUES ('First note', 'SQL is fun');
SELECT * FROM notes;
` } },
    ],
    html: [
      { title: "Profile card", files: {
        "index.html": `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>My page</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="card">
    <h1>Hello, web!</h1>
    <p>Edit index.html and style.css, then press Run.</p>
    <button id="btn">Click me</button>
    <p id="msg"></p>
  </div>
  <script>
    document.getElementById("btn").addEventListener("click", () => {
      document.getElementById("msg").textContent = "JavaScript works in the preview.";
    });
  </script>
</body>
</html>
`,
        "style.css": `body { font-family: system-ui, sans-serif; background: #0b1220; color: #e6f1ff; display: grid; place-items: center; min-height: 100vh; margin: 0; }
.card { background: #111a2e; border: 1px solid #22d3ee; border-radius: 14px; padding: 2rem; max-width: 22rem; text-align: center; }
button { background: #22d3ee; border: 0; border-radius: 8px; padding: .5rem 1rem; font-weight: 600; cursor: pointer; }
`,
      } },
    ],
  };

  // ---- state & elements ----
  const editor = CodeMirror.fromTextArea($("#editor"), {
    theme: "dracula", lineNumbers: true, indentUnit: 4, lineWrapping: false,
    extraKeys: {
      "Ctrl-Enter": () => run(), "Cmd-Enter": () => run(),
      "Ctrl-S": () => saveFile(), "Cmd-S": () => saveFile(),
      Tab: (cm) => (cm.somethingSelected() ? cm.indentSelection("add") : cm.replaceSelection("    ", "end")),
    },
  });
  const docs = {};
  let lang = "python", fileName = "main.py", running = false, saveTimer = null, previewTimer = null;
  const output = $("#output"), preview = $("#preview"), statusEl = $("#status"), statusText = $("#status-text");

  const draftKey = (l, f) => `nl:draft:${l}/${f}`;
  const storageGet = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const storageSet = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } };
  const storageDel = (k) => { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } };

  function getDoc(f, l = lang) {
    const key = (project ? "project" : l) + "/" + f;
    if (!docs[key]) {
      let text, mode;
      if (project) {
        text = project.files.find((x) => x.filename === f).content;
        mode = modeFor(f);
      } else {
        mode = LANGS[l].files.find((x) => x[0] === f)[1];
        const draft = storageGet(draftKey(l, f));
        text = draft !== null ? draft : EXAMPLES[l][0].files[f];
      }
      docs[key] = new CodeMirror.Doc(text, mode);
      docs[key].markClean();
    }
    return docs[key];
  }

  const fileNames = () => (project ? project.files.map((f) => f.filename) : LANGS[lang].files.map((f) => f[0]));
  let dirtyAny = false;

  function updateDirty() {
    if (!project) return;
    let any = false;
    $("#tabs").querySelectorAll("button").forEach((b) => {
      const d = docs["project/" + b.dataset.file];
      const dirty = !!d && !d.isClean();
      b.textContent = b.dataset.file + (dirty ? " ●" : "");
      any = any || dirty;
    });
    dirtyAny = any;
    $("#dirty").classList.toggle("d-none", !any);
  }

  function el(tag, cls, text) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  // ---- language / file switching ----
  function showFile(f) {
    fileName = f;
    editor.swapDoc(getDoc(f));
    $("#tabs").querySelectorAll("button").forEach((b) => b.classList.toggle("active", b.dataset.file === f));
    editor.refresh();
  }

  function setLang(l) {
    lang = project ? project.language : l;
    $("#lang").value = lang;
    const tabs = $("#tabs");
    tabs.replaceChildren();
    fileNames().forEach((f) => {
      const li = el("li", "nav-item");
      const b = el("button", "nav-link", f);
      b.type = "button"; b.dataset.file = f;
      b.addEventListener("click", () => showFile(f));
      li.append(b); tabs.append(li);
    });
    if (!project) {
      const ex = $("#examples");
      ex.replaceChildren(new Option("Examples…", ""));
      EXAMPLES[lang].forEach((e, i) => ex.append(new Option(e.title, String(i))));
    }
    const runnable = !!RUNNABLE[lang];
    $("#run").disabled = !runnable;
    $("#stdin-wrap").classList.toggle("d-none", lang !== "python");
    $("#reset-db").classList.toggle("d-none", lang !== "sql");
    $("#auto-wrap").classList.toggle("d-none", !(lang === "html" && runnable));
    output.classList.toggle("d-none", lang === "html");
    preview.classList.toggle("d-none", lang !== "html");
    $("#run-label").textContent = lang === "html" ? "▶ Refresh preview" : "▶ Run";
    output.replaceChildren();
    setStatus("secondary", "Ready", "");
    if (!runnable) {
      setStatus("secondary", "Edit only", "");
      message(`Running ${LANG_LABELS[lang]} code is not available yet (planned for Phase 8). You can still edit and save files.`, "info");
    }
    const names = fileNames();
    if (names.length) {
      showFile(project && project.open && names.includes(project.open) ? project.open : names[0]);
    } else {
      editor.swapDoc(new CodeMirror.Doc("", "text/plain"));
      editor.setOption("readOnly", "nocursor");
      message("This project has no files. Add one on the project page.", "info");
    }
    if (lang === "html" && runnable) updatePreview();
  }

  // ---- status & output rendering ----
  function setStatus(color, label, text) {
    statusEl.className = "badge text-bg-" + color;
    statusEl.textContent = label;
    statusText.textContent = text || "";
  }

  function message(text, color) {
    output.replaceChildren(el("div", `alert alert-${color} mb-0`, text));
  }

  function showPython(data, httpOk) {
    output.replaceChildren();
    if (!httpOk || data.error) {
      setStatus(data.status === "busy" ? "warning" : "danger", data.status === "busy" ? "Busy" : "Not run", "");
      message(data.error || "Could not run the program.", "warning");
      return;
    }
    const t = `${data.duration_ms} ms`;
    if (data.status === "ok") setStatus("success", "Finished", t);
    else if (data.status === "timeout") setStatus("warning", "Timed out", `stopped after ${data.timeout_s} s`);
    else if (data.status === "output_limit") setStatus("warning", "Output limit", "the program wrote too much");
    else setStatus("danger", "Error", `exit code ${data.exit_code} · ${t}`);
    if (data.stdout) output.append(el("pre", "cl-pre", data.stdout));
    if (data.stderr) output.append(el("pre", "cl-pre text-danger", data.stderr));
    if (data.status === "timeout") output.append(el("div", "small text-warning", "Your program ran longer than the allowed time. Check for infinite loops."));
    if (data.truncated || data.status === "output_limit") output.append(el("div", "small text-warning", "Output was cut off."));
    if (!data.stdout && !data.stderr && data.status === "ok") output.append(el("div", "text-secondary", "(the program printed nothing)"));
  }

  function showSql(data) {
    output.replaceChildren();
    if (data.status !== "ok") {
      setStatus("danger", "SQL error", "");
      output.append(el("div", "alert alert-danger", data.error || "SQL failed."));
      if (data.failed_statement) output.append(el("div", "small text-secondary", `Statement ${data.failed_statement} failed, so the whole script was rolled back.`));
      return;
    }
    setStatus("success", "Done", `${data.duration_ms} ms`);
    data.results.forEach((r) => {
      output.append(el("div", "small text-secondary mt-2", `Statement ${r.statement}: ${r.sql.split("\n")[0]}`));
      if (!r.columns) {
        output.append(el("div", "", r.rowcount === null ? "OK" : `${r.rowcount} row(s) affected`));
        return;
      }
      const wrap = el("div", "table-responsive");
      const table = el("table", "table table-sm table-striped cl-table");
      const head = el("tr");
      r.columns.forEach((c) => head.append(el("th", "", c)));
      table.append(el("thead")).firstChild.append(head);
      const body = el("tbody");
      r.rows.forEach((row) => {
        const tr = el("tr");
        row.forEach((v) => tr.append(v === null ? el("td", "text-secondary fst-italic", "NULL") : el("td", "", String(v))));
        body.append(tr);
      });
      table.append(body); wrap.append(table); output.append(wrap);
      output.append(el("div", "small text-secondary", `${r.rows.length} row(s)` + (r.truncated ? " (showing the first 200)" : "")));
    });
  }

  // ---- HTML preview (isolated iframe, no same-origin) ----
  function fileText(name) {
    if (project && !project.files.some((f) => f.filename === name)) return null;
    return getDoc(name, "html").getValue();
  }

  function buildPreview() {
    let html = fileText("index.html");
    if (html === null) return null;
    const style = `<style>\n${fileText("style.css") || ""}\n</style>`;
    const link = /<link\b[^>]*href\s*=\s*["']?(?:\.\/)?style\.css["']?[^>]*>/i;
    if (link.test(html)) html = html.replace(link, () => style);
    else if (/<\/head>/i.test(html)) html = html.replace(/<\/head>/i, () => style + "</head>");
    else html = style + html;
    const csp = '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; img-src data: https:; font-src data:">';
    const head = /<head(?=[\s>])[^>]*>/i, doctype = /^\s*<!doctype[^>]*>/i;
    if (head.test(html)) return html.replace(head, (m) => m + csp);
    if (doctype.test(html)) return html.replace(doctype, (m) => m + csp);
    return csp + html;
  }

  function updatePreview() {
    const built = buildPreview();
    if (built === null) {
      preview.srcdoc = "";
      setStatus("warning", "No index.html", "add an index.html file to preview this project");
      return;
    }
    preview.srcdoc = built;
    setStatus("success", "Preview updated", "");
  }

  // ---- running ----
  function setBusy(on) {
    running = on;
    $("#run").disabled = on || !RUNNABLE[lang];
    $("#run-spinner").classList.toggle("d-none", !on);
    if (on) setStatus("info", "Running…", "");
  }

  async function run() {
    if (running) return;
    if (!RUNNABLE[lang]) return;
    if (lang === "html") { updatePreview(); return; }
    if (project && !fileName.endsWith(lang === "python" ? ".py" : ".sql")) {
      setStatus("warning", "Not run", "");
      message(`Open a ${lang === "python" ? ".py" : ".sql"} file to run it.`, "warning");
      return;
    }
    setBusy(true);
    try {
      const body = new FormData();
      body.append("csrf_token", csrf);
      body.append("code", editor.getValue());
      if (lang === "python") body.append("stdin", $("#stdin").value);
      const resp = await fetch(URLS[lang], { method: "POST", body });
      let data = null;
      try { data = await resp.json(); } catch (e) { /* not JSON */ }
      if (!data) { setStatus("danger", "Error", ""); message(`Server error (${resp.status}). Reload the page and try again.`, "danger"); }
      else if (lang === "python") showPython(data, resp.ok);
      else showSql(data);
    } catch (e) {
      setStatus("danger", "Offline", "");
      message("Could not reach the server.", "danger");
    } finally {
      setBusy(false);
    }
  }

  // ---- toolbar actions ----
  $("#run").addEventListener("click", run);
  $("#lang").addEventListener("change", (e) => setLang(e.target.value));
  $("#clear").addEventListener("click", () => { output.replaceChildren(); setStatus("secondary", "Ready", ""); });

  $("#examples").addEventListener("change", (e) => {
    const sel = e.target.value;
    e.target.value = "";
    if (sel === "") return;
    if (!confirm("Replace your current code with this example?")) return;
    const ex = EXAMPLES[lang][Number(sel)];
    Object.entries(ex.files).forEach(([f, text]) => { getDoc(f).setValue(text); storageSet(draftKey(lang, f), text); });
    if (lang === "html") updatePreview();
  });

  $("#reset").addEventListener("click", () => {
    if (!confirm("Reset to the starter code? Your changes will be lost.")) return;
    Object.entries(EXAMPLES[lang][0].files).forEach(([f, text]) => { getDoc(f).setValue(text); storageDel(draftKey(lang, f)); });
    if (lang === "html") updatePreview();
  });

  $("#reset-db").addEventListener("click", async () => {
    if (!confirm("Restore the practice database to its original sample data? Your tables and changes will be lost.")) return;
    const body = new FormData();
    body.append("csrf_token", csrf);
    try {
      const resp = await fetch(URLS.resetSql, { method: "POST", body });
      const data = await resp.json();
      setStatus("success", "Database reset", "");
      message(data.message || "Practice database restored.", "success");
    } catch (e) { message("Could not reset the database.", "danger"); }
  });

  // ---- project saving ----
  async function saveFile() {
    if (!project) return;
    const pf = project.files.find((f) => f.filename === fileName);
    if (!pf) return;
    const doc = getDoc(fileName);
    const body = new FormData();
    body.append("csrf_token", csrf);
    body.append("content", doc.getValue());
    try {
      const resp = await fetch(pf.save_url, { method: "POST", body });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Save failed");
      pf.content = doc.getValue();
      doc.markClean();
      updateDirty();
      setStatus("success", "Saved", fileName);
    } catch (e) {
      setStatus("danger", "Save failed", "");
      if (lang !== "html") message(String(e.message || e), "danger");
    }
  }

  // ---- "save as project / snippet" dialog (standalone mode) ----
  const modalEl = $("#save-modal");
  const modal = new bootstrap.Modal(modalEl);
  let saveKind = null;

  function openSaveDialog(kind) {
    saveKind = kind;
    $("#save-modal-title").textContent = kind === "project" ? "Save as project" : "Save as snippet";
    $("#save-name-label").textContent = kind === "project" ? "Project name" : "Snippet title";
    $("#save-tags-wrap").classList.toggle("d-none", kind !== "snippet");
    $("#save-name").value = ""; $("#save-tags").value = ""; $("#save-error").textContent = "";
    modal.show();
  }
  modalEl.addEventListener("shown.bs.modal", () => $("#save-name").focus());
  $("#save-name").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#save-confirm").click(); });

  $("#save-confirm").addEventListener("click", async () => {
    const name = $("#save-name").value.trim();
    if (!name) { $("#save-error").textContent = "Please enter a name."; return; }
    const body = new FormData();
    body.append("csrf_token", csrf);
    if (saveKind === "project") {
      const files = {};
      fileNames().forEach((f) => { files[f] = getDoc(f).getValue(); });
      body.append("name", name); body.append("language", lang); body.append("files", JSON.stringify(files));
    } else {
      body.append("title", name); body.append("tags", $("#save-tags").value);
      body.append("language", fileName.endsWith(".css") ? "css" : lang);
      body.append("code", editor.getValue());
    }
    try {
      const resp = await fetch(saveKind === "project" ? URLS.saveProject : URLS.saveSnippet, { method: "POST", body });
      const data = await resp.json();
      if (!resp.ok) { $("#save-error").textContent = data.error || "Could not save."; return; }
      modal.hide();
      const alert = el("div", "alert alert-success mt-2 mb-0", saveKind === "project" ? "Saved as a project. " : "Saved to your snippets. ");
      const link = el("a", "", saveKind === "project" ? "Open it" : "View library");
      link.href = data.url;
      alert.append(link);
      if (!$("#output").classList.contains("d-none")) output.prepend(alert);
      setStatus("success", "Saved", name);
    } catch (e) { $("#save-error").textContent = "Could not reach the server."; }
  });

  $("#save").addEventListener("click", saveFile);
  $("#save-project").addEventListener("click", () => openSaveDialog("project"));
  $("#save-snippet").addEventListener("click", () => openSaveDialog("snippet"));
  window.addEventListener("beforeunload", (e) => { if (dirtyAny) { e.preventDefault(); e.returnValue = ""; } });

  editor.on("change", () => {
    if (project) {
      updateDirty();
    } else {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => storageSet(draftKey(lang, fileName), editor.getValue()), 400);
    }
    if (lang === "html" && RUNNABLE.html && $("#auto").checked) {
      clearTimeout(previewTimer);
      previewTimer = setTimeout(updatePreview, 700);
    }
  });

  // ---- start up ----
  if (project) {
    $("#lang").replaceChildren(new Option(LANG_LABELS[project.language], project.language));
    $("#lang").disabled = true;
    $("#examples").classList.add("d-none");
    $("#reset").classList.add("d-none");
    $("#standalone-note").classList.add("d-none");
    $("#project-bar").classList.remove("d-none");
    $("#save").classList.remove("d-none");
    const link = $("#project-link");
    link.textContent = project.name; link.href = project.url;
    setLang(project.language);
  } else {
    $("#save-project").classList.remove("d-none");
    $("#save-snippet").classList.remove("d-none");
    const snip = boot.snippet;
    setLang(snip ? snip.language : (LANGS[boot.default_lang] ? boot.default_lang : "python"));
    if (snip) {
      const target = getDoc(LANGS[lang].files[0][0]);
      const starter = EXAMPLES[lang][0].files[LANGS[lang].files[0][0]];
      const current = target.getValue();
      if (current === starter || current === snip.code || confirm(`Replace your current ${LANG_LABELS[lang]} draft with the snippet "${snip.title}"?`)) {
        target.setValue(snip.code);
        if (lang === "html") updatePreview();
      }
    }
  }
})();
