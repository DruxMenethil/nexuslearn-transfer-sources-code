(function () {
  // Question form: show only the fields that fit the chosen type.
  var type = document.querySelector("[data-qtype]");
  if (type) {
    var sync = function () {
      document.querySelectorAll("[data-show]").forEach(function (el) {
        el.hidden = el.dataset.show.split(" ").indexOf(type.value) === -1;
      });
      document.querySelectorAll("[data-help]").forEach(function (el) { el.hidden = el.dataset.help !== type.value; });
    };
    type.addEventListener("change", sync); sync();
  }

  // Quiz taking: one question at a time, progress, optional timer, confirm before finishing.
  var form = document.getElementById("quiz-form");
  if (!form) return;
  var blocks = Array.prototype.slice.call(form.querySelectorAll(".q-block"));
  var cur = 0, submitting = false;
  var show = function (i) {
    cur = Math.max(0, Math.min(blocks.length - 1, i));
    blocks.forEach(function (b, k) { b.hidden = k !== cur; });
    document.getElementById("prev").disabled = cur === 0;
    document.getElementById("next").disabled = cur === blocks.length - 1;
    document.getElementById("qcount").textContent = "Question " + (cur + 1) + " of " + blocks.length + " · " + answered() + " answered";
    document.getElementById("qprogress").style.width = Math.round(100 * answered() / blocks.length) + "%";
  };
  var answered = function () {
    return blocks.filter(function (b) {
      var r = b.querySelector("input[type=radio]:checked"), t = b.querySelector("input[type=text], input:not([type])");
      return !!r || (t && t.value.trim() !== "");
    }).length;
  };
  document.getElementById("prev").onclick = function () { show(cur - 1); };
  document.getElementById("next").onclick = function () { show(cur + 1); };
  form.addEventListener("input", function () { show(cur); });
  form.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target.tagName === "INPUT" && e.target.type !== "radio") { e.preventDefault(); show(cur + 1); } });
  form.addEventListener("submit", function (e) {
    if (submitting) return;
    var left = blocks.length - answered();
    var msg = left ? "You left " + left + " question" + (left === 1 ? "" : "s") + " unanswered. Finish the quiz anyway?" : "Finish and see your score?";
    if (!confirm(msg)) e.preventDefault();
  });
  show(0);
  var timer = document.getElementById("timer");
  if (timer) {
    var left = parseInt(timer.dataset.seconds, 10);
    var tick = function () {
      timer.textContent = Math.floor(left / 60) + ":" + String(left % 60).padStart(2, "0");
      if (left <= 0) { submitting = true; form.submit(); return; }
      left -= 1; setTimeout(tick, 1000);
    };
    tick();
  }
})();
