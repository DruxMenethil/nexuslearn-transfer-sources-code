"""Learning Hub (Phase 6): graded exercises. Notes now live in notes.py (Study Studio)."""
import json

from flask import (Blueprint, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)

import codelab
import grading
from helpers import get_db, local_dt, login_required, tz_offset_minutes

bp = Blueprint("learn", __name__)

DIFFICULTIES = ("beginner", "intermediate", "advanced")
MAX_CODE = 50_000
MAX_NOTE = 20_000

EXERCISE_LIST_SQL = """
    SELECT * FROM (
        SELECT e.id, e.slug, e.title, e.language, e.topic, e.difficulty, e.position,
               (SELECT COUNT(*) FROM exercise_attempts a WHERE a.exercise_id = e.id AND a.user_id = :uid) AS attempts,
               (SELECT MIN(a.created_at) FROM exercise_attempts a
                 WHERE a.exercise_id = e.id AND a.user_id = :uid AND a.passed = 1) AS completed_at
        FROM exercises e)
    WHERE {where} ORDER BY language, position"""


def like(text):
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def get_exercise(db, slug):
    ex = db.execute("SELECT * FROM exercises WHERE slug = ?", (slug,)).fetchone()
    if ex is None:
        abort(404)
    return ex


# ------------------------------------------------------------- exercises ----
@bp.route("/learn")
@login_required
def hub():
    db, uid = get_db(), session["user_id"]
    f = {k: request.args.get(k, "").strip() for k in ("q", "language", "topic", "difficulty", "status")}
    where, params = ["1 = 1"], {"uid": uid}
    if f["q"]:
        where.append("(title LIKE :q ESCAPE '\\' OR topic LIKE :q ESCAPE '\\')")
        params["q"] = like(f["q"])
    if f["language"] in ("python", "sql"):
        where.append("language = :language")
        params["language"] = f["language"]
    if f["topic"]:
        where.append("topic = :topic")
        params["topic"] = f["topic"]
    if f["difficulty"] in DIFFICULTIES:
        where.append("difficulty = :difficulty")
        params["difficulty"] = f["difficulty"]
    if f["status"] == "completed":
        where.append("completed_at IS NOT NULL")
    elif f["status"] == "in_progress":
        where.append("attempts > 0 AND completed_at IS NULL")
    elif f["status"] == "not_started":
        where.append("attempts = 0")
    exercises = db.execute(EXERCISE_LIST_SQL.format(where=" AND ".join(where)), params).fetchall()
    progress = db.execute(EXERCISE_LIST_SQL.format(where="1 = 1"), {"uid": uid}).fetchall()
    offset = tz_offset_minutes()
    return render_template(
        "learn.html", exercises=exercises, f=f,
        topics=[r[0] for r in db.execute("SELECT DISTINCT topic FROM exercises ORDER BY topic")],
        total=len(progress), done=sum(1 for r in progress if r["completed_at"]),
        by_language={lang: (sum(1 for r in progress if r["language"] == lang and r["completed_at"]),
                            sum(1 for r in progress if r["language"] == lang)) for lang in ("python", "sql")},
        local=lambda t: local_dt(t, offset, "%b %d"))


@bp.route("/learn/exercises/<slug>")
@login_required
def exercise_detail(slug):
    db, uid = get_db(), session["user_id"]
    ex = get_exercise(db, slug)
    tests = json.loads(ex["tests"])
    visible = [t for t in tests if not t.get("hidden")]
    examples = [{"input": t.get("call") or t.get("stdin", ""), "expected": t.get("expected"),
                 "label": t.get("label")} for t in visible]
    offset = tz_offset_minutes()
    attempts = [{**dict(a), "when": local_dt(a["created_at"], offset)} for a in db.execute(
        """SELECT id, passed, tests_passed, tests_total, created_at FROM exercise_attempts
           WHERE user_id = ? AND exercise_id = ? ORDER BY id DESC LIMIT 20""", (uid, ex["id"]))]
    done = db.execute("SELECT MIN(created_at) FROM exercise_attempts WHERE user_id = ? AND exercise_id = ? AND passed = 1",
                      (uid, ex["id"])).fetchone()[0]
    return render_template("exercise.html", ex=ex, hints=json.loads(ex["hints"]), examples=examples,
                           hidden_count=len(tests) - len(visible), attempts=attempts,
                           completed=local_dt(done, offset, "%b %d, %H:%M") if done else None)


@bp.route("/learn/exercises/<slug>/submit", methods=["POST"])
@login_required
def submit_exercise(slug):
    db, uid = get_db(), session["user_id"]
    ex = get_exercise(db, slug)
    code = request.form.get("code", "").replace("\r\n", "\n")
    if not code.strip():
        return jsonify(error="Write your solution first."), 400
    if len(code) > MAX_CODE:
        return jsonify(error=f"Solutions are limited to {MAX_CODE} characters."), 400
    if not codelab.slots.acquire(blocking=False):
        return jsonify(error="The runner is busy. Try again in a moment."), 429
    try:
        result = grading.grade(ex, code, json.loads(ex["tests"]))
    except OSError:
        return jsonify(error="Code execution is unavailable on this server, so this could not be graded."), 503
    finally:
        codelab.slots.release()

    already = db.execute("SELECT 1 FROM exercise_attempts WHERE user_id = ? AND exercise_id = ? AND passed = 1",
                         (uid, ex["id"])).fetchone() is not None
    cur = db.execute(
        """INSERT INTO exercise_attempts (user_id, exercise_id, code, passed, tests_passed, tests_total)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (uid, ex["id"], code, int(result["passed"]), result["tests_passed"], result["tests_total"]))
    db.commit()
    return jsonify({**result, "attempt_id": cur.lastrowid, "newly_completed": result["passed"] and not already})
