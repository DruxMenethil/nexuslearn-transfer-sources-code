"""A tiny, safe Markdown renderer for notes.

Supports headings (#..###), bullet and numbered lists, **bold**, *italic*, `inline code`,
fenced ``` code blocks and paragraphs. Everything is HTML-escaped FIRST, so raw HTML or
scripts typed into a note are displayed as text and can never run.
"""
import re
from html import escape

from markupsafe import Markup

INLINE_CODE = re.compile(r"`([^`\n]+)`")
BOLD = re.compile(r"\*\*(.+?)\*\*")
ITALIC = re.compile(r"(?<!\*)\*(?!\s)([^*\n]+?)(?<!\s)\*(?!\*)")


def inline(text):
    parts = INLINE_CODE.split(escape(text))
    out = []
    for i, part in enumerate(parts):
        if i % 2:                                   # odd positions are code spans
            out.append(f"<code>{part}</code>")
        else:
            out.append(ITALIC.sub(r"<em>\1</em>", BOLD.sub(r"<strong>\1</strong>", part)))
    return "".join(out)


def render(text):
    lines, html, i = (text or "").replace("\r\n", "\n").split("\n"), [], 0
    para, list_kind = [], None

    def close_para():
        if para:
            html.append("<p>" + "<br>".join(inline(p) for p in para) + "</p>")
            para.clear()

    def close_list():
        nonlocal list_kind
        if list_kind:
            html.append(f"</{list_kind}>")
            list_kind = None

    while i < len(lines):
        line = lines[i]
        if line.strip().startswith("```"):
            close_para(); close_list()
            code, i = [], i + 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code.append(lines[i]); i += 1
            html.append("<pre class=\"nl-code\"><code>" + escape("\n".join(code)) + "</code></pre>")
        elif re.match(r"^#{1,3} ", line):
            close_para(); close_list()
            level = len(line.split(" ")[0]) + 2        # '#' -> h3 so the page keeps one h1
            html.append(f"<h{level}>{inline(line.lstrip('# ').strip())}</h{level}>")
        elif re.match(r"^\s*[-*] ", line) or re.match(r"^\s*\d+[.)] ", line):
            close_para()
            kind = "ul" if re.match(r"^\s*[-*] ", line) else "ol"
            if list_kind != kind:
                close_list(); html.append(f"<{kind}>"); list_kind = kind
            html.append("<li>" + inline(re.sub(r"^\s*([-*]|\d+[.)]) ", "", line)) + "</li>")
        elif not line.strip():
            close_para(); close_list()
        else:
            close_list(); para.append(line)
        i += 1
    close_para(); close_list()
    return Markup("\n".join(html))
