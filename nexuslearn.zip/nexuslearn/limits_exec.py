"""Tiny launcher: apply OS resource limits, then replace this process with the real command.

    python -I -B limits_exec.py --cpu 5 --as 268435456 --fsize 262144 --nofile 64 -- ./main

Used by execution.py so limits are in place BEFORE student code starts (no thread-unsafe preexec_fn).
"""
import os
import resource
import signal
import sys

FLAGS = {"--cpu": resource.RLIMIT_CPU, "--as": resource.RLIMIT_AS, "--data": resource.RLIMIT_DATA,
         "--fsize": resource.RLIMIT_FSIZE, "--nofile": resource.RLIMIT_NOFILE}


def main():
    args = sys.argv[1:]
    split = args.index("--")
    options, command = args[:split], args[split + 1:]
    for flag, value in zip(options[::2], options[1::2]):
        resource.setrlimit(FLAGS[flag], (int(value), int(value)))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    signal.signal(signal.SIGXFSZ, signal.SIG_DFL)  # Python ignores it, and ignored signals survive exec
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    os.execvp(command[0], command)


if __name__ == "__main__":
    main()
