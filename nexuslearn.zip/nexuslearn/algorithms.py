"""Step-by-step traces of classic algorithms, produced by running the real algorithm.

Every step records the array, the indices being compared or swapped, and the running counters.
The browser only replays this recorded trace, so counts shown on screen are never made up.
"""

INFO = {
    "bubble": {"name": "Bubble Sort", "time": "O(n²) worst/average, O(n) best (already sorted, with early stop)", "space": "O(1)",
               "explain": "Walk through the list comparing neighbours and swap them if they are in the wrong order. After each pass the next largest (or smallest) value has bubbled to its final place. Stop early when a pass makes no swaps."},
    "selection": {"name": "Selection Sort", "time": "O(n²) in every case", "space": "O(1)",
                  "explain": "Each pass finds the smallest remaining value and swaps it into the next position of the sorted part at the front."},
    "insertion": {"name": "Insertion Sort", "time": "O(n²) worst/average, O(n) best (already sorted)", "space": "O(1)",
                  "explain": "Grow a sorted section from the left. Take the next value and move it left, one swap at a time, until it sits in the right place."},
    "linear": {"name": "Linear Search", "time": "O(n)", "space": "O(1)",
               "explain": "Check each value from left to right until the target is found or the list ends. Works on unsorted lists."},
    "binary": {"name": "Binary Search", "time": "O(log n)", "space": "O(1)",
               "explain": "On a SORTED list, look at the middle value. If it is the target, stop. Otherwise discard the half that cannot contain it and repeat."},
}
MAX_ITEMS, LIMIT = 30, 999


class Tracer:
    def __init__(self, arr):
        self.arr, self.steps = list(arr), []
        self.comparisons = self.swaps = self.passes = 0

    def add(self, note, compare=(), swap=(), done=(), **extra):
        self.steps.append({"array": list(self.arr), "compare": list(compare), "swap": list(swap), "sorted": sorted(done),
                           "comparisons": self.comparisons, "swaps": self.swaps, "passes": self.passes, "note": note, **extra})

    def result(self, algorithm, **extra):
        return {"algorithm": algorithm, **INFO[algorithm], "steps": self.steps, "final": list(self.arr),
                "stats": {"comparisons": self.comparisons, "swaps": self.swaps, "passes": self.passes}, **extra}


def before(a, b, descending):
    """True when a must come AFTER b in the requested order (i.e. the pair is out of order)."""
    return a < b if descending else a > b


def bubble_sort(arr, descending=False):
    t, n = Tracer(arr), len(arr)
    t.add("Start: the original array.")
    done = set()
    for p in range(n - 1):
        t.passes += 1
        swapped = False
        for i in range(n - 1 - p):
            t.comparisons += 1
            if before(t.arr[i], t.arr[i + 1], descending):
                t.arr[i], t.arr[i + 1] = t.arr[i + 1], t.arr[i]
                t.swaps += 1; swapped = True
                t.add(f"Pass {t.passes}: {t.arr[i + 1]} and {t.arr[i]} were out of order, so they were swapped.", (i, i + 1), (i, i + 1), done)
            else:
                t.add(f"Pass {t.passes}: {t.arr[i]} and {t.arr[i + 1]} are already in order.", (i, i + 1), (), done)
        done.add(n - 1 - p)
        t.add(f"End of pass {t.passes}: position {n - 1 - p} is now final.", (), (), done)
        if not swapped:
            done = set(range(n))
            t.add("No swaps in that pass, so the array is sorted. Stopping early.", (), (), done)
            break
    done = set(range(n))
    t.add("Sorted.", (), (), done)
    return t.result("bubble", order="descending" if descending else "ascending")


def selection_sort(arr, descending=False):
    t, n = Tracer(arr), len(arr)
    t.add("Start: the original array.")
    done = set()
    for i in range(n - 1):
        t.passes += 1
        best = i
        for j in range(i + 1, n):
            t.comparisons += 1
            better = t.arr[j] > t.arr[best] if descending else t.arr[j] < t.arr[best]
            t.add(f"Pass {t.passes}: compare {t.arr[j]} with the current {'largest' if descending else 'smallest'} {t.arr[best]}.", (best, j), (), done)
            if better:
                best = j
        if best != i:
            t.arr[i], t.arr[best] = t.arr[best], t.arr[i]
            t.swaps += 1
            t.add(f"Swap {t.arr[i]} into position {i}.", (i, best), (i, best), done | {i})
        done.add(i)
        t.add(f"End of pass {t.passes}: position {i} is final.", (), (), done)
    done = set(range(n))
    t.add("Sorted.", (), (), done)
    return t.result("selection", order="descending" if descending else "ascending")


def insertion_sort(arr, descending=False):
    t, n = Tracer(arr), len(arr)
    t.add("Start: the original array.")
    for i in range(1, n):
        t.passes += 1
        j = i
        while j > 0:
            t.comparisons += 1
            if before(t.arr[j - 1], t.arr[j], descending):
                t.arr[j - 1], t.arr[j] = t.arr[j], t.arr[j - 1]
                t.swaps += 1
                t.add(f"Pass {t.passes}: move {t.arr[j - 1]} one place left.", (j - 1, j), (j - 1, j), range(i + 1))
                j -= 1
            else:
                t.add(f"Pass {t.passes}: {t.arr[j]} is in the right place.", (j - 1, j), (), range(i + 1))
                break
    t.add("Sorted.", (), (), range(n))
    return t.result("insertion", order="descending" if descending else "ascending")


def linear_search(arr, target):
    t = Tracer(arr)
    t.add(f"Looking for {target} from left to right.", target=target)
    found = -1
    for i, v in enumerate(arr):
        t.comparisons += 1
        if v == target:
            found = i
            t.add(f"Index {i} holds {v}: found it.", (i,), (), (), target=target, found=i)
            break
        t.add(f"Index {i} holds {v}: not {target}.", (i,), (), (), target=target)
    if found < 0:
        t.add(f"Reached the end: {target} is not in the list.", (), (), (), target=target, found=-1)
    return t.result("linear", target=target, found=found)


def binary_search(arr, target):
    """`arr` must be sorted ascending (the caller sorts and tells the student)."""
    t = Tracer(arr)
    lo, hi, found = 0, len(arr) - 1, -1
    t.add(f"Looking for {target} in a sorted list.", (), (), (), target=target, low=lo, high=hi)
    while lo <= hi:
        t.passes += 1
        mid = (lo + hi) // 2
        t.comparisons += 1
        if arr[mid] == target:
            found = mid
            t.add(f"Middle index {mid} holds {arr[mid]}: found it.", (mid,), (), (), target=target, low=lo, high=hi, mid=mid, found=mid)
            break
        if arr[mid] < target:
            t.add(f"Middle {arr[mid]} is smaller than {target}: discard the left half.", (mid,), (), (), target=target, low=lo, high=hi, mid=mid)
            lo = mid + 1
        else:
            t.add(f"Middle {arr[mid]} is larger than {target}: discard the right half.", (mid,), (), (), target=target, low=lo, high=hi, mid=mid)
            hi = mid - 1
    if found < 0:
        t.add(f"The search range is empty: {target} is not in the list.", (), (), (), target=target, found=-1)
    return t.result("binary", target=target, found=found)


SORTS = {"bubble": bubble_sort, "selection": selection_sort, "insertion": insertion_sort}


def parse_array(raw):
    """'5, 3 8' -> [5, 3, 8]. Raises ValueError with a student-friendly message."""
    parts = [p for p in raw.replace(",", " ").split() if p]
    if not parts:
        raise ValueError("Enter at least one whole number, separated by commas.")
    if len(parts) > MAX_ITEMS:
        raise ValueError(f"Use at most {MAX_ITEMS} numbers.")
    try:
        values = [int(p) for p in parts]
    except ValueError:
        raise ValueError("Only whole numbers are allowed (for example 5, 3, 8, 1).")
    if any(abs(v) > LIMIT for v in values):
        raise ValueError(f"Numbers must be between -{LIMIT} and {LIMIT}.")
    return values


def run(algorithm, raw_array, order="asc", raw_target=""):
    if algorithm not in INFO:
        raise ValueError("Choose an algorithm.")
    arr = parse_array(raw_array)
    notice = ""
    if algorithm in SORTS:
        return {**SORTS[algorithm](arr, order == "desc"), "notice": notice, "input": arr}
    try:
        target = int(raw_target)
    except ValueError:
        raise ValueError("Enter a whole number to search for.")
    if algorithm == "binary" and arr != sorted(arr):
        arr = sorted(arr)
        notice = "Binary search needs a sorted list, so your numbers were sorted first: " + ", ".join(map(str, arr)) + "."
    fn = linear_search if algorithm == "linear" else binary_search
    return {**fn(arr, target), "notice": notice, "input": arr}
