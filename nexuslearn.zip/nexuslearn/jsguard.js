// Preloaded into student JavaScript when the OS cannot isolate the network.
// Best effort: makes the network modules and fetch unusable. Real isolation comes from
// bubblewrap or a network namespace (see execution.py).
"use strict";
const Module = require("module");
const BLOCKED = new Set(["net", "tls", "http", "https", "http2", "dgram", "dns", "dns/promises", "cluster", "inspector"]);
const originalLoad = Module._load;
Module._load = function (request, ...rest) {
  if (BLOCKED.has(String(request).replace(/^node:/, ""))) {
    throw new Error(`The '${request}' module is not available in CodeLab`);
  }
  return originalLoad.call(this, request, ...rest);
};
for (const name of ["fetch", "WebSocket", "EventSource", "XMLHttpRequest"]) {
  try { delete globalThis[name]; } catch (e) { /* ignore */ }
}
