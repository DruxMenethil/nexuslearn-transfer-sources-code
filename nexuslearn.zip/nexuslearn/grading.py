"""Grades exercise submissions by running them in the isolated runners and comparing REAL results.

A submission passes only if every test case matches. Running without errors is never enough.
"""
import codelab

GRADING_TIMEOUT = 3      # seconds per Python test case
SHOW_CHARS = 500         # how much actual output a failing visible test shows

# Function-mode wrapper: loads the student's file with its own output suppressed, then runs the call.
FUNCTION_WRAPPER = (
    "import contextlib, io, runpy\n"
    "with contextlib.redirect_stdout(io.StringIO()):\n"
    "    _ns = runpy.run_path('solution.py')\n"
    "exec(open('call.txt').read(), _ns)\n"
)


def normalize(text):
    """Ignore trailing spaces on each line and trailing blank lines; everything else must match."""
    return "\n".join(line.rstrip() for line in text.replace("\r\n", "\n").split("\n")).rstrip("\n")


def last_lines(stderr, count=3):
    lines = [line for line in stderr.strip().splitlines() if line.strip()]
    return "\n".join(lines[-count:])


# ------------------------------------------------------------------ Python ----
def grade_python(code, tests):
    results, stopped = [], None
    for number, test in enumerate(tests, 1):
        item = {"n": number, "hidden": bool(test.get("hidden")), "passed": False}
        if not item["hidden"]:
            item["input"] = test.get("call") or test.get("stdin", "")
            item["expected"] = test["expected"]
        if stopped:
            item.update(skipped=True, error=stopped)
            results.append(item)
            continue
        if test.get("call"):
            run = codelab.run_python(FUNCTION_WRAPPER, "", timeout=GRADING_TIMEOUT,
                                     extra_files={"solution.py": code, "call.txt": test["call"]})
        else:
            run = codelab.run_python(code, test.get("stdin", ""), timeout=GRADING_TIMEOUT)

        if run["status"] == "timeout":
            stopped = item["error"] = "Time limit exceeded. Check for an infinite loop. Remaining tests were skipped."
        elif run["status"] == "output_limit":
            stopped = item["error"] = "Your program printed far too much output. Remaining tests were skipped."
        elif run["status"] == "error":
            item["error"] = last_lines(run["stderr"]) or "The program crashed."
        else:
            item["passed"] = normalize(run["stdout"]) == normalize(test["expected"])
            if not item["hidden"]:
                item["actual"] = run["stdout"][:SHOW_CHARS]
        results.append(item)
    return results


# --------------------------------------------------------------------- SQL ----
def _norm_value(value):
    return round(float(value), 4) if isinstance(value, (int, float)) and not isinstance(value, bool) else value


def _final_result(code, check):
    """Run `code` on a fresh sample database; return (columns, rows) of the check query or of the
    script's last result set, or an error string."""
    with codelab.scratch_database() as path:
        run = codelab.execute_script(path, code)
        if run["status"] != "ok":
            return None, run.get("error", "SQL failed.")
        if check:
            checked = codelab.execute_script(path, check)
            if checked["status"] != "ok":
                return None, checked.get("error", "Check failed.")
            run = checked
        sets = [r for r in run["results"] if "columns" in r]
        if not sets:
            return None, "Your script did not return any rows. End it with a SELECT."
        last = sets[-1]
        if last.get("truncated"):
            return None, "Too many rows returned."
        return (last["columns"], last["rows"]), None


def grade_sql(code, tests, solution):
    results = []
    for number, test in enumerate(tests, 1):
        item = {"n": number, "hidden": bool(test.get("hidden")), "passed": False, "label": test.get("label", "")}
        expected, _ = _final_result(solution, test.get("check"))
        actual, error = _final_result(code, test.get("check"))
        if not item["hidden"] and expected:
            item["expected"] = {"columns": expected[0], "rows": expected[1][:10]}
        if error:
            item["error"] = error
        else:
            a_cols, a_rows = actual
            e_cols, e_rows = expected
            a = [tuple(_norm_value(v) for v in row) for row in a_rows]
            e = [tuple(_norm_value(v) for v in row) for row in e_rows]
            if not test.get("ordered", True):
                a, e = sorted(a, key=repr), sorted(e, key=repr)
            columns_ok = (len(a_cols) == len(e_cols) and
                          (not test.get("columns") or [c.lower() for c in a_cols] == [c.lower() for c in test["columns"]]))
            item["passed"] = columns_ok and a == e
            if not item["hidden"]:
                item["actual"] = {"columns": a_cols, "rows": a_rows[:10]}
                if not columns_ok:
                    item["error"] = "Column names or count differ. Expected: " + ", ".join(test.get("columns") or e_cols)
        results.append(item)
    return results


def grade(exercise, code, tests):
    """Return a result dict for an exercise row (sqlite3.Row) and the student's code."""
    if exercise["language"] == "python":
        results = grade_python(code, tests)
    else:
        results = grade_sql(code, tests, exercise["solution"])
    passed = sum(1 for r in results if r["passed"])
    return {"passed": bool(results) and passed == len(results), "tests_passed": passed,
            "tests_total": len(results), "tests": results}
