"""Settings (Phase 7): profile, preferences, timer, password, account deletion."""
import os
import shutil

from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

import codelab
import focus
from helpers import get_db, login_required
from projects import LANGUAGES

bp = Blueprint("settings", __name__)


def back():
    return redirect(url_for("settings.settings_page"))


@bp.route("/settings")
@login_required
def settings_page():
    user = get_db().execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return render_template("settings.html", user=user, languages=LANGUAGES)


@bp.route("/settings/profile", methods=["POST"])
@login_required
def save_profile():
    name = " ".join(request.form.get("display_name", "").split())
    if len(name) > 50:
        flash("Display name must be 50 characters or fewer.", "danger")
        return back()
    db = get_db()
    db.execute("UPDATE users SET display_name = ? WHERE id = ?", (name, session["user_id"]))
    db.commit()
    flash("Profile saved.", "success")
    return back()


@bp.route("/settings/preferences", methods=["POST"])
@login_required
def save_preferences():
    theme, language = request.form.get("theme", ""), request.form.get("default_language", "")
    if theme not in ("dark", "light") or language not in LANGUAGES:
        flash("Choose a valid theme and default language.", "danger")
        return back()
    db = get_db()
    db.execute("UPDATE users SET theme = ?, default_language = ? WHERE id = ?", (theme, language, session["user_id"]))
    db.commit()
    flash("Preferences saved.", "success")
    return back()


@bp.route("/settings/timer", methods=["POST"])
@login_required
def save_timer():
    values, problem = focus.parse_timer_settings(request.form)
    if problem:
        flash(problem, "danger")
    else:
        focus.store_timer_settings(get_db(), session["user_id"], values)
        flash("Timer settings saved.", "success")
    return back()


@bp.route("/settings/password", methods=["POST"])
@login_required
def change_password():
    db = get_db()
    user = db.execute("SELECT password_hash FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    current, new, confirm = (request.form.get(k, "") for k in ("current_password", "new_password", "confirmation"))
    if not check_password_hash(user["password_hash"], current):
        flash("Your current password is incorrect.", "danger")
    elif len(new) < 8:
        flash("The new password must be at least 8 characters.", "danger")
    elif new != confirm:
        flash("The new passwords do not match.", "danger")
    elif check_password_hash(user["password_hash"], new):
        flash("Choose a password different from the current one.", "danger")
    else:
        db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(new), session["user_id"]))
        db.commit()
        flash("Password changed.", "success")
    return back()


@bp.route("/settings/delete", methods=["POST"])
@login_required
def delete_account():
    db, uid = get_db(), session["user_id"]
    user = db.execute("SELECT username, password_hash FROM users WHERE id = ?", (uid,)).fetchone()
    if not check_password_hash(user["password_hash"], request.form.get("password", "")):
        flash("Your password is incorrect. Nothing was deleted.", "danger")
        return back()
    if request.form.get("confirm", "").strip().lower() != user["username"].lower():
        flash("Type your username exactly to confirm. Nothing was deleted.", "danger")
        return back()
    practice = codelab.practice_path(uid)
    db.execute("DELETE FROM users WHERE id = ?", (uid,))  # ON DELETE CASCADE removes everything they own
    db.commit()
    if os.path.exists(practice):
        os.remove(practice)
    shutil.rmtree(os.path.join(current_app.instance_path, "uploads", str(uid)), ignore_errors=True)  # imported documents
    session.clear()
    flash("Your account and all of its data were deleted.", "info")
    return redirect(url_for("login"))
