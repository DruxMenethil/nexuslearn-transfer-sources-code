"""Writing Assistant.

Two engines, always labelled honestly:
  * "basic": local, rule-based checks (spacing, repeated words, common misspellings, capitalisation,
    contractions, wordy phrases). It is NOT a full grammar checker and cannot understand meaning.
  * "ai": an optional language-model API, used only when ANTHROPIC_API_KEY is set on the server.
    The key never reaches the browser. Code blocks are swapped for placeholders before the text
    is sent and put back afterwards; if a placeholder is lost the AI result is rejected.
The student always reviews changes. Nothing is applied or saved silently, and on any failure the
original text is kept.
"""
import difflib
import json
import os
import re
import urllib.error
import urllib.request
from html import escape

from flask import (Blueprint, abort, flash, redirect, render_template, request, session, url_for)
from markupsafe import Markup

from helpers import get_db, login_required, owned_or_404

bp = Blueprint("writing", __name__)
MAX_TEXT = 8_000
STYLES = {"academic": "Formal academic", "professional": "Professional", "simple": "Simple English"}

# ------------------------------------------------------------- protection ----
PROTECTED = re.compile(r"""
    ```.*?```                                  # fenced code
  | `[^`\n]+`                                  # inline code
  | https?://\S+ | www\.\S+                    # links
  | \b[\w.+-]+@[\w-]+\.[\w.-]+                 # e-mail
  | (?m:^(?:\ {4}|\t).*$)                      # indented code lines
  | \b\w+\([^)\n]*\)                           # function calls like print(x)
  | \b[A-Za-z0-9]*_[A-Za-z0-9_]*\b             # snake_case identifiers
  | \b[a-z]+[A-Z]\w*\b                         # camelCase identifiers
  | \b\w+\.\w+(?:\.\w+)*\b                     # dotted names / file names (os.path, main.py)
""", re.S | re.X)

MISSPELLINGS = {w.split(":")[0]: w.split(":")[1] for w in """teh:the recieve:receive definately:definitely seperate:separate
occured:occurred untill:until wich:which adress:address algorithim:algorithm databse:database lenght:length
begining:beginning acheive:achieve accomodate:accommodate enviroment:environment existance:existence
goverment:government independant:independent necesary:necessary occurence:occurrence refered:referred
succesful:successful tommorow:tomorrow thier:their wierd:weird writting:writing fucntion:function
varaible:variable paramter:parameter programing:programming implmentation:implementation arguement:argument
beleive:believe calender:calendar collegue:colleague comming:coming commited:committed dependancy:dependency
neccessary:necessary reccomend:recommend responsability:responsibility sucess:success usefull:useful""".split()}

CONTRACTIONS = {"don't": "do not", "doesn't": "does not", "didn't": "did not", "can't": "cannot", "won't": "will not",
                "isn't": "is not", "aren't": "are not", "wasn't": "was not", "weren't": "were not", "shouldn't": "should not",
                "couldn't": "could not", "wouldn't": "would not", "it's": "it is", "i'm": "I am", "we're": "we are",
                "they're": "they are", "you're": "you are", "let's": "let us", "gonna": "going to", "wanna": "want to"}
WORDY = {"in order to": "to", "utilize": "use", "utilise": "use", "approximately": "about", "commence": "begin",
         "due to the fact that": "because", "a number of": "several", "at this point in time": "now", "prior to": "before",
         "subsequently": "later", "demonstrate": "show", "facilitate": "help", "numerous": "many", "in the event that": "if"}
ABBREV = {"e.g", "i.e", "etc", "vs", "approx", "fig", "no", "dr", "mr", "ms", "mrs", "prof", "inc"}


def match_case(original, replacement):
    if original.isupper() and len(original) > 1:
        return replacement.upper()
    if original[:1].isupper():
        return replacement[:1].upper() + replacement[1:]
    return replacement


def protected_spans(text):
    return [(m.start(), m.end()) for m in PROTECTED.finditer(text)]


def starts_sentence(text, pos):
    """True when `pos` is the first word of the text, a paragraph or a sentence."""
    before = text[:pos]
    return before.strip() == "" or bool(re.search(r"(?:[.!?]\s+|\n\n)$", before))


def find_edits(text, style="academic"):
    """-> list of edits {start, end, old, new, reason, kind}, sorted, non-overlapping, never inside code."""
    edits = []

    def add(m, new, reason, kind, group=0):
        start, end = m.span(group)
        if text[start:end] != new:
            edits.append({"start": start, "end": end, "old": text[start:end], "new": new, "reason": reason, "kind": kind})

    for m in re.finditer(r"(?<=\S)[ ]{2,}(?=\S)", text):
        add(m, " ", "Use a single space between words.", "spacing")
    for m in re.finditer(r"(?<=\S)[ \t]+([,.;:!?])(?=\s|$)", text):
        add(m, m.group(1), "Remove the space before punctuation.", "punctuation")
    for m in re.finditer(r"(?<=\S)[ \t]+([,;])(?=[A-Za-z])", text):
        add(m, m.group(1) + " ", "Move the punctuation next to the word and add a space after it.", "punctuation")
    for m in re.finditer(r"([,;])(?=[A-Za-z])", text):
        add(m, m.group(1) + " ", "Add a space after the punctuation mark.", "punctuation")
    for m in re.finditer(r"\b([A-Za-z]+)\s+\1\b", text, re.I):
        if m.group(1).lower() not in ("had", "that"):
            add(m, m.group(1), "A word is repeated.", "repetition")
    for m in re.finditer(r"\b[A-Za-z]+\b", text):
        fix = MISSPELLINGS.get(m.group(0).lower())
        if fix:
            new = match_case(m.group(0), fix)
            if starts_sentence(text, m.start()):
                new = new[:1].upper() + new[1:]
            add(m, new, "Likely spelling mistake.", "spelling")
    for m in re.finditer(r"\bi(?=['’](?:m|ve|ll|d)\b)", text):
        add(m, "I", "The pronoun “I” is always capitalised.", "capitalisation")
    for m in re.finditer(r"(?:(?<=[.!?]\s)|(?<=[.!?]\n)|^|(?<=\n\n))([a-z][a-z]+)\b(?![\w(._])", text):
        before = text[:m.start()].rstrip()
        prev = re.findall(r"[\w.]+$", before)
        if prev and prev[0].rstrip(".").lower() in ABBREV:
            continue
        add(m, m.group(1)[:1].upper() + m.group(1)[1:], "Start a sentence with a capital letter.", "capitalisation", 1)
    if style == "academic":
        for m in re.finditer(r"\b[A-Za-z]+['’][a-z]+\b", text):
            fix = CONTRACTIONS.get(m.group(0).lower().replace("’", "'"))
            if fix:
                add(m, match_case(m.group(0), fix), "Formal academic writing avoids contractions.", "style")
        for m in re.finditer(r"\b(gonna|wanna)\b", text, re.I):
            add(m, match_case(m.group(0), CONTRACTIONS[m.group(0).lower()]), "Too informal for academic writing.", "style")
    if style in ("professional", "simple"):
        for phrase, repl in WORDY.items():
            for m in re.finditer(r"\b" + re.escape(phrase) + r"\b", text, re.I):
                add(m, match_case(m.group(0), repl), f"Plainer wording: “{repl}”. Check that the meaning is the same.", "clarity")
    spans = protected_spans(text)
    edits = [e for e in edits if not any(e["start"] < b and e["end"] > a for a, b in spans)]
    edits.sort(key=lambda e: (e["start"], e["end"]))
    kept, last = [], -1
    for e in edits:
        if e["start"] >= last:
            kept.append(e); last = e["end"]
    for i, e in enumerate(kept):
        e["id"] = i
    return kept


def long_sentences(text, limit=40):
    """Advice only (never edited): sentences that are hard to read."""
    out = []
    for s in re.split(r"(?<=[.!?])\s+", re.sub(r"```.*?```", " ", text, flags=re.S)):
        n = len(s.split())
        if n > limit:
            out.append({"words": n, "text": s[:90] + ("…" if len(s) > 90 else "")})
    return out


def apply_edits(text, edits, accepted_ids):
    for e in sorted((e for e in edits if e["id"] in accepted_ids), key=lambda e: e["start"], reverse=True):
        text = text[:e["start"]] + e["new"] + text[e["end"]:]
    return text


def readability(text):
    words = re.findall(r"[A-Za-z']+", text)
    sentences = [s for s in re.split(r"[.!?]+\s", text) if s.strip()]
    return {"chars": len(text), "words": len(words), "sentences": len(sentences),
            "avg": round(len(words) / len(sentences), 1) if sentences else 0}


# -------------------------------------------------------------------- AI ----
class ServiceError(Exception):
    pass


def ai_configured():
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def ai_model():
    return os.environ.get("NEXUSLEARN_LLM_MODEL", "claude-sonnet-5-5")


def call_model(system, user):   # separate function so tests can replace it
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({"model": ai_model(), "max_tokens": 4000, "system": system,
                         "messages": [{"role": "user", "content": user}]}).encode(),
        headers={"content-type": "application/json", "x-api-key": os.environ.get("ANTHROPIC_API_KEY", ""),
                 "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.load(resp)
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    except (urllib.error.URLError, TimeoutError, ValueError, OSError):
        raise ServiceError("The writing service could not be reached.")


def ai_revise(text, style):
    """Returns the revised text, or raises ServiceError. Code blocks are protected by placeholders."""
    if not ai_configured():
        raise ServiceError("No writing service is configured on this server.")
    spans, parts, last = protected_spans(text), [], 0
    held = []
    for a, b in spans:
        if a < last:
            continue
        parts.append(text[last:a]); parts.append(f"⟦{len(held)}⟧"); held.append(text[a:b]); last = b
    parts.append(text[last:])
    masked = "".join(parts)
    system = ("You are a careful copy editor for students. Fix grammar, spelling and punctuation and improve clarity in the "
              f"requested style ({STYLES.get(style, style)}). Never change meaning, technical terms or numbers, never invent "
              "citations or facts, and keep every ⟦n⟧ placeholder exactly as written. Reply with the revised text only.")
    out = call_model(system, masked).strip()
    for i, original in enumerate(held):
        if out.count(f"⟦{i}⟧") != 1:
            raise ServiceError("The service altered protected content, so its answer was discarded.")
        out = out.replace(f"⟦{i}⟧", original)
    if not out:
        raise ServiceError("The service returned an empty answer.")
    return out[:MAX_TEXT * 2]


# ------------------------------------------------------------------ diff ----
def diff_html(a, b):
    """Word-level side-by-side diff. Everything is escaped before markup is added."""
    ta, tb = re.findall(r"\s+|\S+", a), re.findall(r"\s+|\S+", b)
    left, right = [], []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ta, tb, autojunk=False).get_opcodes():
        x, y = escape("".join(ta[i1:i2])), escape("".join(tb[j1:j2]))
        if op == "equal":
            left.append(x); right.append(y)
        else:
            if x: left.append(f'<span class="diff-del">{x}</span>')
            if y: right.append(f'<span class="diff-ins">{y}</span>')
    return Markup("".join(left)), Markup("".join(right))


# ---------------------------------------------------------------- routes ----
def read_input():
    text = request.form.get("text", "").replace("\r\n", "\n")
    style = request.form.get("style", "academic")
    style = style if style in STYLES else "academic"
    if not text.strip():
        return text, style, "Enter some text to check."
    if len(text) > MAX_TEXT:
        return text, style, f"Text is limited to {MAX_TEXT} characters (yours is {len(text)}). Check it in parts."
    return text, style, None


def page(**ctx):
    db, uid = get_db(), session["user_id"]
    ctx.setdefault("text", ""); ctx.setdefault("style", "academic")
    saved = db.execute("SELECT id, title, style, engine, created_at FROM writing_docs WHERE user_id = ? ORDER BY id DESC LIMIT 10", (uid,)).fetchall()
    return render_template("writing.html", styles=STYLES, max_text=MAX_TEXT, ai_available=ai_configured(), ai_model=ai_model(),
                           saved=saved, **ctx)


@bp.route("/study/writing")
@login_required
def assistant():
    text = ""
    note_id = request.args.get("note_id", "")
    if note_id.isdigit():
        note = get_db().execute("SELECT body FROM notes WHERE id = ? AND user_id = ?", (int(note_id), session["user_id"])).fetchone()
        if note is None:
            abort(404)
        text = note["body"][:MAX_TEXT]
    return page(text=text)


@bp.route("/study/writing/check", methods=["POST"])
@login_required
def check():
    text, style, problem = read_input()
    if problem:
        flash(problem, "danger")
        return page(text=text, style=style)
    stats = readability(text)
    if request.form.get("engine") == "ai":
        try:
            revised = ai_revise(text, style)
            left, right = diff_html(text, revised)
            return page(text=text, style=style, stats=stats, result={"engine": "ai", "revised": revised, "left": left, "right": right,
                                                                    "edits": [], "advice": long_sentences(text)})
        except ServiceError as e:
            flash(f"{e} Your text is unchanged. Showing the basic local checks instead.", "warning")
    edits = find_edits(text, style)
    return page(text=text, style=style, stats=stats, result={"engine": "basic", "edits": edits, "advice": long_sentences(text),
                                                            "revised": apply_edits(text, edits, {e["id"] for e in edits})})


@bp.route("/study/writing/apply", methods=["POST"])
@login_required
def apply():
    """Apply only the suggestions the student ticked. Suggestions are recomputed from the same text."""
    text, style, problem = read_input()
    if problem:
        flash(problem, "danger")
        return page(text=text, style=style)
    edits = find_edits(text, style)
    accepted = {int(x) for x in request.form.getlist("accept") if x.isdigit()}
    revised = apply_edits(text, edits, accepted)
    left, right = diff_html(text, revised)
    return page(text=text, style=style, stats=readability(text),
                result={"engine": "basic", "edits": edits, "advice": long_sentences(text), "revised": revised,
                        "left": left, "right": right, "applied": len(accepted & {e["id"] for e in edits}), "accepted": accepted})


@bp.route("/study/writing/save", methods=["POST"])
@login_required
def save():
    f = request.form
    title, original, revised = f.get("title", "").strip(), f.get("text", ""), f.get("revised", "")
    style, engine = f.get("style", "academic"), f.get("engine", "basic")
    if not 1 <= len(title) <= 100 or style not in STYLES or engine not in ("basic", "ai") or not original.strip() \
            or len(original) > MAX_TEXT or len(revised) > MAX_TEXT * 2:
        flash("Give the text a title (100 characters or fewer) and keep it within the length limit.", "danger")
        return page(text=original, style=style if style in STYLES else "academic")
    db = get_db()
    cur = db.execute("INSERT INTO writing_docs (user_id, title, original, revised, style, engine) VALUES (?, ?, ?, ?, ?, ?)",
                     (session["user_id"], title, original, revised, style, engine))
    db.commit()
    flash("Saved.", "success")
    return redirect(url_for("writing.view_doc", doc_id=cur.lastrowid))


@bp.route("/study/writing/<int:doc_id>")
@login_required
def view_doc(doc_id):
    doc = owned_or_404(get_db(), "writing_docs", doc_id)
    left, right = diff_html(doc["original"], doc["revised"])
    return render_template("writing_doc.html", doc=doc, left=left, right=right, styles=STYLES)


@bp.route("/study/writing/<int:doc_id>/to-note", methods=["POST"])
@login_required
def to_note(doc_id):
    db, uid = get_db(), session["user_id"]
    doc = owned_or_404(db, "writing_docs", doc_id)
    cur = db.execute("INSERT INTO notes (user_id, title, topic, body) VALUES (?, ?, 'Writing', ?)",
                     (uid, doc["title"][:100], doc["revised"][:20_000]))
    db.commit()
    flash("Saved as a note.", "success")
    return redirect(url_for("notes.view_note", note_id=cur.lastrowid))


@bp.route("/study/writing/<int:doc_id>/delete", methods=["POST"])
@login_required
def delete_doc(doc_id):
    db = get_db()
    owned_or_404(db, "writing_docs", doc_id)
    db.execute("DELETE FROM writing_docs WHERE id = ? AND user_id = ?", (doc_id, session["user_id"]))
    db.commit()
    flash("Deleted.", "info")
    return redirect(url_for("writing.assistant"))
