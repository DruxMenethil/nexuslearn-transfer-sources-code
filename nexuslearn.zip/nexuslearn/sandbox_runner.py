"""Runs ONE student Python file inside a restricted child process.

Started by codelab.py as:  python -I -B -u -X utf8 sandbox_runner.py <sandbox_dir> main.py <project_dir>

Layers of protection (best effort, designed for a student project):
  1. OS resource limits: CPU time, memory, file size, open files.
  2. A Python audit hook that refuses network, subprocess/exec/fork, ctypes,
     reads outside the sandbox and the Python installation, writes outside the
     sandbox, and the project directory (database, secret key).
  3. An empty environment (no secrets) and a throw-away working directory.
The parent process also enforces a wall-clock timeout and cleans up.
This is NOT container-grade isolation; see the README before exposing it publicly.
"""
import builtins
import os
import resource
import sys
import traceback

CPU_SECONDS = 5
MEMORY_BYTES = 512 * 1024 * 1024
FILE_BYTES = 256 * 1024       # keep in sync with FILE_LIMIT in codelab.py
OPEN_FILES = 64
MAX_FILES_CREATED = 10


def inside(path, root):
    return path == root or path.startswith(root.rstrip(os.sep) + os.sep)


def main():
    sandbox = os.path.realpath(sys.argv[1])
    script = sys.argv[2]
    private = os.path.realpath(sys.argv[3])

    for name, value in (("RLIMIT_CPU", CPU_SECONDS), ("RLIMIT_AS", MEMORY_BYTES),
                        ("RLIMIT_FSIZE", FILE_BYTES), ("RLIMIT_NOFILE", OPEN_FILES),
                        ("RLIMIT_CORE", 0)):
        resource.setrlimit(getattr(resource, name), (value, value))

    read_roots = {os.path.realpath(p) for p in (sys.prefix, sys.exec_prefix,
                                                sys.base_prefix, sys.base_exec_prefix)}
    read_roots |= {os.path.realpath("/usr/lib"), os.path.realpath("/lib")}
    devices = {"/dev/null", "/dev/urandom", "/dev/random"}

    def can_read(p):
        if inside(p, sandbox) or p in devices:
            return True
        if inside(p, private):  # the app itself: only a venv inside it may be read
            return any(inside(p, r) for r in read_roots if inside(r, private))
        return any(inside(p, r) for r in read_roots)

    blocked = ("socket.", "subprocess.", "ctypes.", "pty.", "webbrowser.", "os.exec", "os.fork",
               "os.spawn", "os.posix_spawn", "os.system", "os.kill", "os.killpg", "os.chmod",
               "os.chown", "os.link", "os.symlink", "os.mkfifo", "os.mknod", "shutil.chown")
    sandbox_only = {"os.remove": (0,), "os.rmdir": (0,), "os.mkdir": (0,), "os.truncate": (0,),
                    "os.rename": (0, 1), "os.utime": (0,)}
    created = [0]

    def resolve(p):
        return os.path.realpath(os.fsdecode(p))

    def hook(event, args):
        if event.startswith(blocked):
            raise PermissionError(f"'{event}' is not allowed in CodeLab")
        if event == "open":
            path, _mode, flags = args
            if path is None or isinstance(path, int):
                return
            p = resolve(path)
            writing = isinstance(flags, int) and bool(
                flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC))
            if writing:
                if p == "/dev/null":
                    return
                if not inside(p, sandbox):
                    raise PermissionError(f"Writing to '{path}' is not allowed in CodeLab")
                created[0] += 1
                if created[0] > MAX_FILES_CREATED:
                    raise PermissionError("Too many file writes in one run")
            elif not can_read(p):
                raise PermissionError(f"Reading '{path}' is not allowed in CodeLab")
        elif event in sandbox_only:
            for i in sandbox_only[event]:
                if i < len(args) and isinstance(args[i], (str, bytes, os.PathLike)):
                    if not inside(resolve(args[i]), sandbox):
                        raise PermissionError(f"'{event}' outside the sandbox is not allowed")
        elif event in ("os.listdir", "os.scandir", "os.chdir"):
            if args and isinstance(args[0], (str, bytes, os.PathLike)) and not can_read(resolve(args[0])):
                raise PermissionError("Listing that folder is not allowed in CodeLab")

    os.chdir(sandbox)
    with open(script, "rb") as f:
        source = f.read()
    sys.argv = [script]
    sys.addaudithook(hook)

    namespace = {"__name__": "__main__", "__file__": script, "__builtins__": builtins}
    try:
        exec(compile(source, script, "exec"), namespace)
    except SystemExit:
        raise
    except BaseException:
        etype, value, tb = sys.exc_info()
        traceback.print_exception(etype, value, tb.tb_next if tb else None)  # hide runner frame
        sys.stderr.flush()
        sys.exit(1)


if __name__ == "__main__":
    main()
