"""Smart Notes: folders, tags, favorites, Markdown rendering, autosave, import and export.

Every query filters on user_id; a note, task or project that is not yours is a 404.
"""
import os
import re

from flask import (Blueprint, Response, abort, current_app, flash, jsonify, redirect,
                   render_template, request, send_file, session, url_for)

import documents
from helpers import clean_tags, get_db, like, login_required, owned_or_404
from mdrender import render

bp = Blueprint("notes", __name__)
MAX_NOTE = 20_000
SORTS = {"updated": "n.updated_at DESC, n.id DESC", "title": "n.title COLLATE NOCASE, n.id",
         "favorites": "n.favorite DESC, n.updated_at DESC, n.id DESC"}


def get_owned_note(db, note_id):
    return owned_or_404(db, "notes", note_id)


def owned_id_or_none(db, table, raw):
    """A task/project id from a form, only if it is yours; otherwise None."""
    if not raw or not str(raw).isdigit():
        return None
    row = db.execute(f"SELECT id FROM {table} WHERE id = ? AND user_id = ?", (int(raw), session["user_id"])).fetchone()
    return row["id"] if row else None


def validate_note(form, full=True):
    values = {"title": form.get("title", "").strip(), "topic": " ".join(form.get("topic", "").split()),
              "body": form.get("body", "").replace("\r\n", "\n"),
              "folder": " ".join(form.get("folder", "").split()), "tags": clean_tags(form.get("tags", ""))}
    errors = []
    if not values["title"]:
        errors.append("Title is required.")
    elif len(values["title"]) > 100:
        errors.append("Title must be 100 characters or fewer.")
    if len(values["topic"]) > 40:
        errors.append("Topic must be 40 characters or fewer.")
    if len(values["folder"]) > 40:
        errors.append("Folder must be 40 characters or fewer.")
    if len(values["body"]) > MAX_NOTE:
        errors.append(f"Notes are limited to {MAX_NOTE} characters.")
    if full:
        values["favorite"] = 1 if form.get("favorite") else 0
    return values, errors


def lists_for_form(db, uid):
    return {"topics": [r[0] for r in db.execute("SELECT DISTINCT topic FROM notes WHERE user_id = ? AND topic != '' ORDER BY topic", (uid,))],
            "folders": [r[0] for r in db.execute("SELECT DISTINCT folder FROM notes WHERE user_id = ? AND folder != '' ORDER BY folder", (uid,))],
            "tasks": db.execute("SELECT id, title FROM tasks WHERE user_id = ? ORDER BY status, due_date IS NULL, due_date LIMIT 100", (uid,)).fetchall(),
            "projects": db.execute("SELECT id, name FROM projects WHERE user_id = ? ORDER BY updated_at DESC LIMIT 100", (uid,)).fetchall()}


@bp.route("/learn/notes")
@login_required
def list_notes():
    db, uid = get_db(), session["user_id"]
    q, topic = request.args.get("q", "").strip(), request.args.get("topic", "").strip()
    folder, tag = request.args.get("folder", "").strip(), request.args.get("tag", "").strip().lower()
    fav = request.args.get("favorite") == "1"
    sort = request.args.get("sort") if request.args.get("sort") in SORTS else "updated"
    where, params = ["n.user_id = ?"], [uid]
    if q:
        where.append("(n.title LIKE ? ESCAPE '\\' OR n.body LIKE ? ESCAPE '\\' OR n.topic LIKE ? ESCAPE '\\' "
                     "OR n.tags LIKE ? ESCAPE '\\' OR n.folder LIKE ? ESCAPE '\\')")
        params += [like(q)] * 5
    if topic:
        where.append("n.topic = ?"); params.append(topic)
    if folder:
        where.append("n.folder = ?"); params.append(folder)
    if tag:
        where.append("(',' || n.tags || ',') LIKE ? ESCAPE '\\'"); params.append(like("," + tag + ","))
    if fav:
        where.append("n.favorite = 1")
    notes = db.execute(f"SELECT n.* FROM notes n WHERE {' AND '.join(where)} ORDER BY {SORTS[sort]}", params).fetchall()
    form_lists = lists_for_form(db, uid)
    all_tags = sorted({t for r in db.execute("SELECT tags FROM notes WHERE user_id = ? AND tags != ''", (uid,)) for t in r[0].split(",")})
    return render_template(
        "notes.html", notes=notes, q=q, topic=topic, folder=folder, tag=tag, fav=fav, sort=sort, sorts=list(SORTS),
        total=db.execute("SELECT COUNT(*) FROM notes WHERE user_id = ?", (uid,)).fetchone()[0],
        topics=form_lists["topics"], folders=form_lists["folders"], all_tags=all_tags,
        formats=documents.ALLOWED, max_mb=documents.MAX_UPLOAD // (1024 * 1024))


def save_links(db, note_id, form):
    db.execute("UPDATE notes SET task_id = ?, project_id = ? WHERE id = ? AND user_id = ?",
               (owned_id_or_none(db, "tasks", form.get("task_id")), owned_id_or_none(db, "projects", form.get("project_id")),
                note_id, session["user_id"]))


@bp.route("/learn/notes/new", methods=["GET", "POST"])
@login_required
def new_note():
    db, uid = get_db(), session["user_id"]
    values, errors = {}, []
    if request.method == "GET":
        values = {"task_id": request.args.get("task_id", ""), "project_id": request.args.get("project_id", "")}
    if request.method == "POST":
        values, errors = validate_note(request.form)
        if not errors:
            cur = db.execute("INSERT INTO notes (user_id, title, topic, body, folder, tags, favorite) VALUES (?, ?, ?, ?, ?, ?, ?)",
                             (uid, values["title"], values["topic"], values["body"], values["folder"], values["tags"], values["favorite"]))
            save_links(db, cur.lastrowid, request.form)
            db.commit()
            flash("Note saved.", "success")
            return redirect(url_for("notes.list_notes"))
        values.update(task_id=request.form.get("task_id", ""), project_id=request.form.get("project_id", ""))
    return render_template("note_form.html", note=None, values=values, errors=errors, **lists_for_form(db, uid))


@bp.route("/learn/notes/<int:note_id>")
@login_required
def view_note(note_id):
    db, uid = get_db(), session["user_id"]
    note = get_owned_note(db, note_id)
    return render_template(
        "note_view.html", note=note, body_html=render(note["body"]),
        task=db.execute("SELECT id, title FROM tasks WHERE id = ? AND user_id = ?", (note["task_id"], uid)).fetchone(),
        project=db.execute("SELECT id, name FROM projects WHERE id = ? AND user_id = ?", (note["project_id"], uid)).fetchone(),
        quizzes=db.execute("""SELECT q.id, q.title FROM quizzes q JOIN quiz_notes qn ON qn.quiz_id = q.id
                              WHERE qn.note_id = ? AND q.user_id = ?""", (note_id, uid)).fetchall(),
        decks=db.execute("""SELECT d.id, d.name FROM decks d JOIN deck_notes dn ON dn.deck_id = d.id
                            WHERE dn.note_id = ? AND d.user_id = ?""", (note_id, uid)).fetchall(),
        document=db.execute("SELECT id, original_name FROM note_documents WHERE note_id = ? AND user_id = ?", (note_id, uid)).fetchone())


@bp.route("/learn/notes/<int:note_id>/edit", methods=["GET", "POST"])
@login_required
def edit_note(note_id):
    db, uid = get_db(), session["user_id"]
    note = get_owned_note(db, note_id)
    values = {k: note[k] for k in ("title", "topic", "body", "folder", "tags", "favorite", "task_id", "project_id")}
    errors = []
    if request.method == "POST":
        values, errors = validate_note(request.form)
        if not errors:
            db.execute("""UPDATE notes SET title = ?, topic = ?, body = ?, folder = ?, tags = ?, favorite = ?,
                          updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?""",
                       (values["title"], values["topic"], values["body"], values["folder"], values["tags"],
                        values["favorite"], note_id, uid))
            save_links(db, note_id, request.form)
            db.commit()
            flash("Note updated.", "success")
            return redirect(url_for("notes.list_notes"))
        values.update(task_id=request.form.get("task_id", ""), project_id=request.form.get("project_id", ""))
    return render_template("note_form.html", note=note, values=values, errors=errors, **lists_for_form(db, uid))


@bp.route("/learn/notes/<int:note_id>/autosave", methods=["POST"])
@login_required
def autosave_note(note_id):
    """Called by the editor a moment after typing stops. Returns JSON either way."""
    db = get_db()
    get_owned_note(db, note_id)
    values, errors = validate_note(request.form, full=False)
    if errors:
        return jsonify(ok=False, error=" ".join(errors)), 400
    db.execute("""UPDATE notes SET title = ?, topic = ?, body = ?, folder = ?, tags = ?, updated_at = CURRENT_TIMESTAMP
                  WHERE id = ? AND user_id = ?""",
               (values["title"], values["topic"], values["body"], values["folder"], values["tags"], note_id, session["user_id"]))
    db.commit()
    return jsonify(ok=True)


@bp.route("/learn/notes/<int:note_id>/favorite", methods=["POST"])
@login_required
def toggle_favorite(note_id):
    db = get_db()
    note = get_owned_note(db, note_id)
    db.execute("UPDATE notes SET favorite = ? WHERE id = ? AND user_id = ?", (0 if note["favorite"] else 1, note_id, session["user_id"]))
    db.commit()
    return redirect(request.referrer or url_for("notes.list_notes")) if request.form.get("back") != "view" \
        else redirect(url_for("notes.view_note", note_id=note_id))


@bp.route("/learn/notes/<int:note_id>/delete", methods=["POST"])
@login_required
def delete_note(note_id):
    db = get_db()
    get_owned_note(db, note_id)
    db.execute("DELETE FROM notes WHERE id = ? AND user_id = ?", (note_id, session["user_id"]))
    db.commit()
    flash("Note deleted.", "info")
    return redirect(url_for("notes.list_notes"))


@bp.route("/learn/notes/<int:note_id>/export.<fmt>")
@login_required
def export_note(note_id, fmt):
    if fmt not in ("txt", "md"):
        abort(404)
    note = get_owned_note(get_db(), note_id)
    text = note["body"]
    if fmt == "md":
        text = f"# {note['title']}\n\n" + ("*Topic: " + note["topic"] + "*\n\n" if note["topic"] else "") + note["body"] + "\n"
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", note["title"]).strip("_")[:50] or "note"
    return Response(text, mimetype="text/plain; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}.{fmt}"'})


# ----------------------------------------------------------- document import ----
@bp.route("/learn/notes/import", methods=["POST"])
@login_required
def import_document():
    """Step 1: validate, keep the original, extract text. Nothing becomes a note yet."""
    db, uid = get_db(), session["user_id"]
    file = request.files.get("document")
    if file is None or not file.filename:
        flash("Choose a file to import.", "danger")
        return redirect(url_for("notes.list_notes"))
    data = file.read(documents.MAX_UPLOAD + 1)
    try:
        kind = documents.detect_kind(file.filename, data)
        text, warnings = documents.extract_text(kind, data)
    except documents.DocumentError as e:
        flash(str(e), "danger")
        return redirect(url_for("notes.list_notes"))
    stored = documents.save_original(current_app.instance_path, uid, kind, data)
    cur = db.execute("INSERT INTO note_documents (user_id, original_name, stored_name, kind, size_bytes) VALUES (?, ?, ?, ?, ?)",
                     (uid, os.path.basename(file.filename)[:120], stored, kind, len(data)))
    db.commit()
    for w in warnings:
        flash(w, "warning")
    return redirect(url_for("notes.import_review", doc_id=cur.lastrowid))


def load_document_text(doc):
    path = os.path.join(documents.upload_dir(current_app.instance_path, doc["user_id"]), doc["stored_name"])
    with open(path, "rb") as f:
        return documents.extract_text(doc["kind"], f.read())


@bp.route("/learn/notes/import/<int:doc_id>", methods=["GET", "POST"])
@login_required
def import_review(doc_id):
    """Step 2: the student reviews and edits the extracted text, then creates the note."""
    db, uid = get_db(), session["user_id"]
    doc = owned_or_404(db, "note_documents", doc_id)
    text, warnings = load_document_text(doc)
    errors = []
    title = os.path.splitext(doc["original_name"])[0][:100]
    if request.method == "POST":
        values, errors = validate_note(request.form)
        if not values["body"].strip():
            errors.append("There is no text to save. Edit the text or discard this import.")
        if not errors:
            cur = db.execute("INSERT INTO notes (user_id, title, topic, body, folder, tags) VALUES (?, ?, ?, ?, ?, ?)",
                             (uid, values["title"], values["topic"], values["body"], values["folder"], values["tags"]))
            db.execute("UPDATE note_documents SET note_id = ? WHERE id = ? AND user_id = ?", (cur.lastrowid, doc_id, uid))
            db.commit()
            flash("Note created from your document. The original file is kept.", "success")
            return redirect(url_for("notes.view_note", note_id=cur.lastrowid))
        title, text = values["title"], values["body"]
    truncated = len(text) > MAX_NOTE
    return render_template("note_import.html", doc=doc, title=title, text=text[:MAX_NOTE], truncated=truncated,
                           warnings=warnings, errors=errors, max_note=MAX_NOTE, **lists_for_form(db, uid))


@bp.route("/learn/documents/<int:doc_id>/discard", methods=["POST"])
@login_required
def discard_document(doc_id):
    db, uid = get_db(), session["user_id"]
    doc = owned_or_404(db, "note_documents", doc_id)
    path = os.path.join(documents.upload_dir(current_app.instance_path, uid), doc["stored_name"])
    db.execute("DELETE FROM note_documents WHERE id = ? AND user_id = ?", (doc_id, uid))
    db.commit()
    if os.path.exists(path):
        os.remove(path)
    flash("Import discarded and the uploaded file removed.", "info")
    return redirect(url_for("notes.list_notes"))


@bp.route("/learn/documents/<int:doc_id>/download")
@login_required
def download_document(doc_id):
    doc = owned_or_404(get_db(), "note_documents", doc_id)
    path = os.path.join(documents.upload_dir(current_app.instance_path, session["user_id"]), doc["stored_name"])
    if not os.path.exists(path):
        abort(404)
    return send_file(path, as_attachment=True, download_name=doc["original_name"], mimetype="application/octet-stream")
