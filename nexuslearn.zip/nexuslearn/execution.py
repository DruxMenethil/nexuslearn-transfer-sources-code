"""Phase 8: JavaScript (Node.js) and C/C++ (real compiler) execution for CodeLab.

Isolation, strongest first. Each run gets a throw-away directory, an empty environment,
resource limits (applied by limits_exec.py before student code starts) and a wall-clock timeout.

  1. bubblewrap (`bwrap`): new namespaces for everything, no network, read-only /usr, only the
     run directory visible. Used for C/C++/JS when it works on this machine.
  2. JavaScript without bubblewrap: Node's permission model (file reads and writes limited to the
     run directory, no child processes, no workers) plus a network namespace when `unshare` works,
     otherwise a best-effort block of network modules.
  3. C/C++ without bubblewrap: native code cannot be restrained by Python alone, so it is
     REFUSED by default. Set NEXUSLEARN_ALLOW_UNSANDBOXED_NATIVE=1 to run it with resource limits
     only. Do that only on a private machine where the only person running code is you.

Nothing here pretends: capabilities() reports what is really available and why, and every result
says which sandbox ran it.
"""
import functools
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
LAUNCHER = os.path.join(HERE, "limits_exec.py")
JS_GUARD = os.path.join(HERE, "jsguard.js")
UNSANDBOXED_ENV = "NEXUSLEARN_ALLOW_UNSANDBOXED_NATIVE"

RUN_TIMEOUT = 5
COMPILE_TIMEOUT = 10
MAX_OUTPUT = 20_000
RUN_FILE_LIMIT = 256 * 1024          # per-file write limit while running
COMPILE_FILE_LIMIT = 16 * 1024 * 1024
NODE_HEAP_MB = 128

RUN_LIMITS = {"cpu": 5, "as": 256 * 1024 * 1024, "fsize": RUN_FILE_LIMIT, "nofile": 64}
JS_LIMITS = {"cpu": 5, "data": 768 * 1024 * 1024, "fsize": RUN_FILE_LIMIT, "nofile": 128}  # V8 reserves huge address space, so no RLIMIT_AS
COMPILE_LIMITS = {"cpu": 10, "as": 2 * 1024 ** 3, "fsize": COMPILE_FILE_LIMIT, "nofile": 128}

COMPILERS = {"c": (("gcc", "clang"), "main.c", ["-std=c11", "-Wall", "-Wextra", "-O0"], ["-lm"]),
             "cpp": (("g++", "clang++"), "main.cpp", ["-std=c++17", "-Wall", "-Wextra", "-O0"], [])}
SIGNAL_TEXT = {"SIGSEGV": "Segmentation fault (invalid memory access)", "SIGFPE": "Arithmetic error (such as division by zero)",
               "SIGABRT": "Aborted (failed assertion or abort())", "SIGBUS": "Bus error", "SIGILL": "Illegal instruction",
               "SIGKILL": "Killed (out of memory or too slow)", "SIGXCPU": "CPU time limit exceeded",
               "SIGPIPE": "Broken pipe", "SIGTERM": "Terminated"}


# ------------------------------------------------------------ detection ----
def _under_usr(path):
    return bool(path) and os.path.realpath(path).startswith(("/usr/", "/bin/", "/lib"))


def bwrap_argv(bwrap, sandbox, inner):
    """The bubblewrap command line for running `inner` with only `sandbox` writable."""
    argv = [bwrap, "--unshare-all", "--die-with-parent", "--new-session", "--ro-bind", "/usr", "/usr"]
    for d in ("/bin", "/sbin", "/lib", "/lib64", "/lib32"):
        if os.path.islink(d):
            argv += ["--symlink", os.readlink(d), d]
        elif os.path.isdir(d):
            argv += ["--ro-bind", d, d]
    argv += ["--ro-bind-try", "/etc/ld.so.cache", "/etc/ld.so.cache", "--proc", "/proc", "--dev", "/dev",
             "--tmpfs", "/tmp", "--bind", sandbox, "/work", "--chdir", "/work", "--clearenv",
             "--setenv", "PATH", "/usr/bin:/bin", "--setenv", "HOME", "/work", "--setenv", "LANG", "C.UTF-8"]
    return argv + list(inner)


@functools.lru_cache(maxsize=None)
def bwrap_path():
    """Path to a bubblewrap that actually works here (user namespaces can be disabled), else None."""
    path = shutil.which("bwrap")
    if not path:
        return None
    folder = tempfile.mkdtemp(prefix="nexuslearn_probe_")
    try:
        probe = subprocess.run(bwrap_argv(path, folder, ["/usr/bin/true"]), capture_output=True, timeout=10)
        return path if probe.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        shutil.rmtree(folder, ignore_errors=True)


@functools.lru_cache(maxsize=None)
def netns_works():
    """True if `unshare -rn` (a private, empty network namespace) works for this user."""
    unshare = shutil.which("unshare")
    if not unshare:
        return False
    try:
        return subprocess.run([unshare, "-rn", "true"], capture_output=True, timeout=10).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


@functools.lru_cache(maxsize=None)
def node_info():
    """(path, permission_flag) for Node.js, or (None, None). The flag enables the permission model."""
    node = shutil.which("node")
    if not node:
        return None, None
    for flag in ("--permission", "--experimental-permission"):
        try:
            if subprocess.run([node, flag, "-e", "1"], capture_output=True, timeout=10).returncode == 0:
                return node, flag
        except (OSError, subprocess.SubprocessError):
            pass
    return node, None


def find_compiler(language):
    for name in COMPILERS[language][0]:
        path = shutil.which(name)
        if path:
            return path
    return None


def unsandboxed_native_allowed():
    return os.environ.get(UNSANDBOXED_ENV) == "1"


def capabilities():
    """What CodeLab can really run on this machine, with plain-language reasons."""
    caps = {}
    bwrap = bwrap_path()
    node, flag = node_info()
    if bwrap and node and _under_usr(node):
        caps["javascript"] = {"available": True, "sandbox": "bubblewrap", "reason": ""}
    elif node and flag:
        how = "Node permission model + private network" if netns_works() else "Node permission model (network modules blocked, no OS network isolation)"
        caps["javascript"] = {"available": True, "sandbox": how, "reason": ""}
    elif node:
        caps["javascript"] = {"available": False, "sandbox": "", "reason":
                              "This Node.js has no permission model (needs Node 20+). Upgrade Node.js or install bubblewrap to run JavaScript safely."}
    else:
        caps["javascript"] = {"available": False, "sandbox": "", "reason": "Node.js was not found on this server, so JavaScript cannot run. You can still edit and save it."}
    for language, label in (("c", "C"), ("cpp", "C++")):
        compiler = find_compiler(language)
        if not compiler:
            caps[language] = {"available": False, "sandbox": "", "reason":
                              f"No {label} compiler (gcc or clang) was found, so {label} cannot be compiled or run. You can still edit and save it."}
        elif bwrap and _under_usr(compiler):
            caps[language] = {"available": True, "sandbox": "bubblewrap", "reason": ""}
        elif unsandboxed_native_allowed():
            caps[language] = {"available": True, "sandbox": "none (resource limits only)", "reason": ""}
        else:
            caps[language] = {"available": False, "sandbox": "", "reason":
                              f"Running {label} needs an OS sandbox, and bubblewrap is not available here. Install it (sudo apt-get install bubblewrap) "
                              f"or, on a private machine only, set {UNSANDBOXED_ENV}=1. You can still edit and save {label} code."}
    return caps


# ------------------------------------------------------------ running ----
def _read(path):
    with open(path, "rb") as f:
        data = f.read(MAX_OUTPUT + 1)
    return data[:MAX_OUTPUT].decode("utf-8", errors="replace"), len(data) > MAX_OUTPUT


def run_limited(argv, sandbox, timeout, limits, stdin_path=None):
    """Run argv (already wrapped for isolation) with limits and a wall-clock timeout.
    Output goes to files, so a runaway program cannot fill memory."""
    flags = []
    for name in ("cpu", "as", "data", "fsize", "nofile"):
        if limits.get(name):
            flags += [f"--{name}", str(limits[name])]
    out_path, err_path = os.path.join(sandbox, "_stdout"), os.path.join(sandbox, "_stderr")
    env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "HOME": sandbox}
    started = time.monotonic()
    timed_out = False
    with open(stdin_path or os.devnull, "rb") as fin, open(out_path, "wb") as fout, open(err_path, "wb") as ferr:
        proc = subprocess.Popen([sys.executable, "-I", "-B", LAUNCHER, *flags, "--", *argv], stdin=fin, stdout=fout,
                                stderr=ferr, cwd=sandbox, env=env, start_new_session=True, close_fds=True)
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
    stdout, cut_out = _read(out_path)
    stderr, cut_err = _read(err_path)
    return {"rc": proc.returncode, "timed_out": timed_out, "stdout": stdout, "stderr": stderr,
            "truncated": cut_out or cut_err, "out_size": os.path.getsize(out_path),
            "ms": int((time.monotonic() - started) * 1000)}


def classify(result, file_limit=RUN_FILE_LIMIT):
    rc = result["rc"]
    if result["out_size"] >= file_limit or rc == -signal.SIGXFSZ:
        return "output_limit"            # checked first: a flooding loop also runs out of time
    if result["timed_out"] or rc == -signal.SIGXCPU:
        return "timeout"
    return "ok" if rc == 0 else "error"


def signal_name(rc):
    if rc is not None and rc < 0:
        try:
            return signal.Signals(-rc).name
        except ValueError:
            return f"signal {-rc}"
    return None


def _finish(result, status, sandbox_label, extra=None):
    name = signal_name(result["rc"])
    stderr = result["stderr"]
    if name and status == "error" and name in SIGNAL_TEXT:
        stderr = (stderr + ("\n" if stderr and not stderr.endswith("\n") else "") + f"[{SIGNAL_TEXT[name]}]").lstrip("\n")
    out = {"status": status, "exit_code": result["rc"], "signal": name, "stdout": result["stdout"], "stderr": stderr,
           "truncated": result["truncated"], "duration_ms": result["ms"], "timeout_s": RUN_TIMEOUT, "sandbox": sandbox_label}
    out.update(extra or {})
    return out


def _unavailable(language):
    return {"status": "unavailable", "error": capabilities()[language]["reason"] or "Execution is unavailable."}


def run_javascript(code, stdin_text, timeout=None):
    caps = capabilities()["javascript"]
    if not caps["available"]:
        return _unavailable("javascript")
    timeout = timeout or RUN_TIMEOUT
    node, flag = node_info()
    sandbox = tempfile.mkdtemp(prefix="nexuslearn_js_")
    try:
        with open(os.path.join(sandbox, "main.js"), "w", encoding="utf-8") as f:
            f.write(code)
        with open(os.path.join(sandbox, "stdin.txt"), "w", encoding="utf-8") as f:
            f.write(stdin_text)
        stdin_path = os.path.join(sandbox, "stdin.txt")
        heap = f"--max-old-space-size={NODE_HEAP_MB}"
        if caps["sandbox"] == "bubblewrap":
            argv = bwrap_argv(bwrap_path(), sandbox, [node, heap, "main.js"])
            where = "/work/"
        else:
            argv = [node, flag, f"--allow-fs-read={sandbox}", f"--allow-fs-read={JS_GUARD}", f"--allow-fs-write={sandbox}",
                    "--require", JS_GUARD, heap, "main.js"]
            if netns_works():
                argv = [shutil.which("unshare"), "-rn", *argv]
            where = sandbox + os.sep
        result = run_limited(argv, sandbox, timeout, JS_LIMITS, stdin_path)
        for key in ("stderr", "stdout"):
            result[key] = result[key].replace(where, "./").replace(HERE + os.sep, "<codelab>/")
        return _finish(result, classify(result), caps["sandbox"])
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)


def run_native(language, code, stdin_text, timeout=None):
    """Compile C or C++ with a real compiler, then run the program. Never fakes a successful compile."""
    caps = capabilities()[language]
    if not caps["available"]:
        return _unavailable(language)
    timeout = timeout or RUN_TIMEOUT
    compiler = find_compiler(language)
    _, source, flags, libs = COMPILERS[language]
    sandbox = tempfile.mkdtemp(prefix="nexuslearn_native_")
    try:
        os.chmod(sandbox, 0o777 if caps["sandbox"] == "bubblewrap" else 0o700)
        with open(os.path.join(sandbox, source), "w", encoding="utf-8") as f:
            f.write(code)
        with open(os.path.join(sandbox, "stdin.txt"), "w", encoding="utf-8") as f:
            f.write(stdin_text)
        wrap = (lambda inner: bwrap_argv(bwrap_path(), sandbox, inner)) if caps["sandbox"] == "bubblewrap" else (lambda inner: inner)

        build = run_limited(wrap([compiler, *flags, source, "-o", "main", *libs]), sandbox, COMPILE_TIMEOUT, COMPILE_LIMITS)
        compiler_text = (build["stderr"] + build["stdout"]).strip()
        if build["timed_out"]:
            return {"status": "compile_error", "compile_output": "Compilation took too long and was stopped.\n" + compiler_text,
                    "stdout": "", "stderr": "", "exit_code": None, "signal": None, "truncated": False,
                    "duration_ms": build["ms"], "timeout_s": timeout, "sandbox": caps["sandbox"]}
        if build["rc"] != 0 or not os.path.exists(os.path.join(sandbox, "main")):
            return {"status": "compile_error", "compile_output": compiler_text or "Compilation failed.", "stdout": "", "stderr": "",
                    "exit_code": build["rc"], "signal": None, "truncated": build["truncated"], "duration_ms": build["ms"],
                    "timeout_s": timeout, "sandbox": caps["sandbox"]}

        run = run_limited(wrap(["./main"]), sandbox, timeout, RUN_LIMITS, os.path.join(sandbox, "stdin.txt"))
        run["ms"] += build["ms"]
        return _finish(run, classify(run), caps["sandbox"], {"compile_output": compiler_text})  # warnings, if any
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
