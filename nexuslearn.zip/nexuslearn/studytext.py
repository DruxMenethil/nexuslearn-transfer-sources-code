"""Template-based text analysis used to DRAFT quiz questions and flashcards from notes.

This is NOT artificial intelligence. It finds "Term: definition" lines, markdown headings with
a paragraph under them, and sentences with a long key word to blank out. Every draft is shown
to the student for editing before anything is saved.
"""
import re

PAIR_RE = re.compile(r"^\s*(?:[-*]\s+)?\**([^:\n=]{2,60}?)\**\s*(?::|=|\u2014|\u2013| - )\s*(.{10,300}?)\s*$")
STOP = set("""about after again against because before being between could during either every first from
having however includes including might other should since their there these those through under until
using where whether which while would across always another cannot often within without""".split())


def clean(text):
    """Remove fenced code blocks and markdown markers so only prose remains."""
    text = re.sub(r"```.*?```", " ", text or "", flags=re.S)
    return text.replace("\r\n", "\n")


def extract_pairs(text):
    """[(term, definition)] from lines like 'Primary key: a column that uniquely identifies a row'."""
    pairs, seen = [], set()
    for line in clean(text).split("\n"):
        if line.lstrip().startswith("#"):
            continue
        m = PAIR_RE.match(line)
        if not m:
            continue
        term = m.group(1).strip(" *`_")
        definition = m.group(2).strip(" *`")
        if not term or len(term.split()) > 6 or term.lower() in seen:
            continue
        seen.add(term.lower())
        pairs.append((term, definition))
    return pairs


def extract_sections(text):
    """[(heading, first paragraph)] for markdown headings followed by prose."""
    lines, out, i = clean(text).split("\n"), [], 0
    while i < len(lines):
        m = re.match(r"^#{1,4}\s+(.+?)\s*$", lines[i])
        if m:
            j, para = i + 1, []
            while j < len(lines) and not lines[j].startswith("#"):
                if lines[j].strip() and not PAIR_RE.match(lines[j]):
                    para.append(lines[j].strip(" -*"))
                elif para:
                    break
                j += 1
            body = " ".join(para)
            if len(body) >= 15:
                out.append((m.group(1).strip(), body[:400]))
            i = j
        else:
            i += 1
    return out


def extract_sentences(text, pair_lines=()):
    """Plain sentences of 40-220 characters, skipping lines already used as term/definition pairs."""
    sentences = []
    for line in clean(text).split("\n"):
        line = line.strip(" -*>")
        if not line or line.startswith("#") or PAIR_RE.match(line):
            continue
        for s in re.split(r"(?<=[.!?])\s+", line):
            s = s.strip()
            if 40 <= len(s) <= 220:
                sentences.append(s)
    return sentences


def key_word(sentence):
    """The longest plain word (>= 6 letters, not a stop word) - the word to blank out."""
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z\-]{5,}", sentence) if w.lower() not in STOP]
    return max(words, key=len) if words else None
