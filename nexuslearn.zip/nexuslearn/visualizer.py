"""Algorithm Visualizer routes: the server runs the algorithm and returns the recorded trace."""
from flask import Blueprint, jsonify, render_template, request

import algorithms
from helpers import login_required

bp = Blueprint("visualizer", __name__)


@bp.route("/learn/visualizer")
@login_required
def page():
    return render_template("visualizer.html", info=algorithms.INFO, max_items=algorithms.MAX_ITEMS)


@bp.route("/learn/visualizer/trace")
@login_required
def trace():
    try:
        result = algorithms.run(request.args.get("algorithm", ""), request.args.get("array", ""),
                                request.args.get("order", "asc"), request.args.get("target", ""))
    except ValueError as e:
        return jsonify(error=str(e)), 400
    return jsonify(result)
