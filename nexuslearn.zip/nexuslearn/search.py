"""Global search: your own tasks, projects, snippets, notes, quizzes, flashcards and exercises."""
from flask import Blueprint, render_template, request, session

from helpers import get_db, login_required

bp = Blueprint("search", __name__)

TYPES = ("tasks", "projects", "snippets", "notes", "quizzes", "flashcards", "exercises")
MIN_LENGTH = 2
LIMIT = 20


def like(text):
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


@bp.route("/search")
@login_required
def search():
    db, uid = get_db(), session["user_id"]
    q = request.args.get("q", "").strip()
    kind = request.args.get("type", "")
    kind = kind if kind in TYPES else ""
    results, searched = {}, len(q) >= MIN_LENGTH
    if searched:
        p = like(q)
        queries = {
            "tasks": ("""SELECT id, title, status, due_date FROM tasks WHERE user_id = ?
                         AND (title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\')
                         ORDER BY status = 'completed', due_date IS NULL, due_date LIMIT ?""", [uid, p, p, LIMIT]),
            "projects": ("""SELECT id, name, language, description FROM projects WHERE user_id = ?
                            AND (name LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\'
                                 OR EXISTS (SELECT 1 FROM project_files f WHERE f.project_id = projects.id
                                            AND f.filename LIKE ? ESCAPE '\\'))
                            ORDER BY updated_at DESC LIMIT ?""", [uid, p, p, p, LIMIT]),
            "snippets": ("""SELECT id, title, language, tags FROM code_snippets WHERE user_id = ?
                            AND (title LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\'
                                 OR tags LIKE ? ESCAPE '\\' OR code LIKE ? ESCAPE '\\')
                            ORDER BY updated_at DESC LIMIT ?""", [uid, p, p, p, p, LIMIT]),
            "notes": ("""SELECT id, title, topic FROM notes WHERE user_id = ?
                         AND (title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\' OR topic LIKE ? ESCAPE '\\'
                              OR tags LIKE ? ESCAPE '\\' OR folder LIKE ? ESCAPE '\\')
                         ORDER BY favorite DESC, updated_at DESC LIMIT ?""", [uid, p, p, p, p, p, LIMIT]),
            "quizzes": ("""SELECT z.id, z.title, z.status, z.topic,
                                  (SELECT COUNT(*) FROM quiz_questions k WHERE k.quiz_id = z.id) AS n_questions,
                                  (SELECT k.prompt FROM quiz_questions k WHERE k.quiz_id = z.id AND k.prompt LIKE ? ESCAPE '\\' LIMIT 1) AS match
                           FROM quizzes z WHERE z.user_id = ?
                            AND (z.title LIKE ? ESCAPE '\\' OR z.topic LIKE ? ESCAPE '\\' OR z.subject LIKE ? ESCAPE '\\'
                                 OR EXISTS (SELECT 1 FROM quiz_questions k WHERE k.quiz_id = z.id AND k.prompt LIKE ? ESCAPE '\\'))
                           ORDER BY z.updated_at DESC LIMIT ?""", [p, uid, p, p, p, p, LIMIT]),
            "flashcards": ("""SELECT d.id, d.name, d.topic,
                                     (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id) AS n_cards,
                                     (SELECT c.front FROM cards c WHERE c.deck_id = d.id AND (c.front LIKE ? ESCAPE '\\' OR c.back LIKE ? ESCAPE '\\') LIMIT 1) AS match
                              FROM decks d WHERE d.user_id = ?
                               AND (d.name LIKE ? ESCAPE '\\' OR d.topic LIKE ? ESCAPE '\\' OR d.subject LIKE ? ESCAPE '\\'
                                    OR EXISTS (SELECT 1 FROM cards c WHERE c.deck_id = d.id AND (c.front LIKE ? ESCAPE '\\' OR c.back LIKE ? ESCAPE '\\')))
                              ORDER BY d.updated_at DESC LIMIT ?""", [p, p, uid, p, p, p, p, p, LIMIT]),
            "exercises": ("""SELECT slug, title, language, difficulty, topic FROM exercises
                             WHERE title LIKE ? ESCAPE '\\' OR topic LIKE ? ESCAPE '\\' OR instructions LIKE ? ESCAPE '\\'
                             ORDER BY language, position LIMIT ?""", [p, p, p, LIMIT]),
        }
        for name, (sql, params) in queries.items():
            if not kind or kind == name:
                results[name] = db.execute(sql, params).fetchall()
    return render_template("search.html", q=q, kind=kind, results=results, searched=searched,
                           count=sum(len(v) for v in results.values()), min_length=MIN_LENGTH, limit=LIMIT)
