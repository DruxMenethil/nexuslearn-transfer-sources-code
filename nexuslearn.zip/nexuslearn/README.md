# NexusLearn: The Student Developer Workspace

*Learn. Build. Focus. Progress.*

Video demo: *(add the URL here after you record it; do not invent one)*

## Overview
NexusLearn is a Flask web app for IT and computer science students. It combines an assignment planner, a coding workspace called **CodeLab**, saved projects and snippets, a study timer, graded programming exercises, notes, and a progress dashboard. Everything shown is computed from records in the database; nothing is hard-coded.

## Run it in CS50's VS Code (cs50.dev / Codespaces)
    cd nexuslearn
    pip install -r requirements.txt      # Flask is usually already installed
    flask run --debug                    # then open the forwarded port 5000
    python -m unittest discover -s tests # 178 tests
The SQLite database and a generated secret key are created in `instance/` on first start (both git-ignored). Set `SECRET_KEY` in the environment to use your own key.

## Features (all implemented and tested)
- **Accounts:** registration, login, logout, hashed passwords, CSRF protection on every form, change password, delete account (removes all of a user's data).
- **Academic Planner:** create/edit/complete/delete tasks, subjects, priorities, deadlines, search, filters, sort by deadline, overdue highlighting, deadline reminders when you open the app.
- **CodeLab:** CodeMirror editor with tabs, examples, reset, unsaved-changes indicator, output/status panels, and runners for **Python, JavaScript, C, C++, SQL** plus a live **HTML/CSS** preview in a sandboxed iframe.
- **My Projects and Snippets:** multi-file projects linked to assignments, saved from or opened in CodeLab; private tagged snippet library with copy and open-in-CodeLab.
- **Focus Mode:** server-authoritative timer (refresh-safe, duplicate-safe), pause/resume/finish early/reset, optional long breaks, subject/assignment/project links, history, daily/weekly summaries.
- **Learning Hub:** 19 Python and SQL exercises graded against real test cases (some hidden), attempt tracking and completion times, searchable private notes.
- **Progress Center:** task, study, exercise and project analytics with 7/30/90-day periods and charts; definitions on the page; no claims of "improvement" the data cannot support.
- **Search and Settings:** one search across tasks, projects, snippets and notes; theme, default language, timer, profile, password, account deletion.

## Technology
Python 3 and Flask, SQLite (`sqlite3`, parameterized SQL), Jinja templates, Bootstrap 5, vanilla JavaScript, CodeMirror 5, Chart.js. Front-end libraries load from CDNs, so the browser needs internet access.

## Files
- `app.py`: app setup, auth routes, dashboard, blueprint registration. `helpers.py`: DB access, migrations, CSRF, login decorator, time-zone helpers.
- `schema.sql`: all tables. `planner.py`, `projects.py`, `snippets.py`, `focus.py`, `learn.py`, `progress.py`, `search.py`, `settings.py`: one module per feature.
- `codelab.py`: run routes and the SQL practice engine. `sandbox_runner.py`: restricted Python runner. `execution.py`, `limits_exec.py`, `jsguard.js`: JavaScript and C/C++ execution. `grading.py` and `exercises_data.py`: exercise tests and content.
- `templates/`, `static/css/styles.css`, `static/js/` (`codelab.js`, `timer.js`, `progress.js`, `snippets.js`), `tests/`.

## Database
`users`, `subjects`, `tasks`, `projects` (optional `task_id`), `project_files`, `code_snippets`, `focus_sessions` (one unfinished session per user via a unique partial index), `exercises`, `exercise_attempts` (completion = earliest passing attempt), `notes`. Foreign keys cascade on user deletion. Older databases are upgraded in place at startup.

## Code execution and security (read this)
- **Python:** a separate process with an empty environment, a temporary directory, CPU/memory/file limits, a wall-clock timeout, and an audit hook that blocks network, subprocesses, ctypes, and any file access outside the run directory and the Python install (the app database and secret key are unreachable).
- **JavaScript:** Node's permission model (reads and writes limited to the run directory, no child processes or workers) plus a private network namespace when `unshare` works, otherwise a best-effort block of network modules. With bubblewrap installed it runs inside bubblewrap instead.
- **C and C++:** compiled by a real compiler (gcc or clang); compile errors show real line numbers and a failed compile is never run. Native code cannot be restrained by Python alone, so it **runs only inside bubblewrap** (`sudo apt-get install bubblewrap`). If bubblewrap is unavailable CodeLab says so and still lets you edit and save C/C++. On a private machine where you are the only user you can opt in with `NEXUSLEARN_ALLOW_UNSANDBOXED_NATIVE=1` (resource limits only, and the result is labelled "none"). The bubblewrap path could not be run in the environment this project was built in; its command line is unit-tested, but test it on your machine.
- The Python and SQL layers are strong for a student project but are not container-grade. Before exposing CodeLab to untrusted users on the internet, run the runners in containers or a dedicated execution service.
- SQL practice uses a separate SQLite file per user (never the app database), an authorizer that blocks `ATTACH`, `VACUUM INTO` and most `PRAGMA`s, a size cap, a time limit and a row cap; scripts run in one transaction.
- The HTML preview is a sandboxed iframe without same-origin access and with a Content-Security-Policy that blocks network requests.
- Secrets: the secret key comes from the environment or a git-ignored file; the execution environments never see it.

## Design choices
Server-rendered Flask with small amounts of JavaScript; plain `sqlite3` instead of an ORM so the SQL is visible; a server-side timer instead of trusting the browser; one blueprint per feature; exercises seeded from code with hidden reference solutions so expected SQL results can never drift from the sample data.

## Testing
178 automated tests cover authentication, CSRF, validation, authorization between two accounts for every private resource, SQL-injection-style input, sandbox escape attempts (secrets, filesystem, network, subprocesses, memory and output floods), grading (including that hard-coding examples fails), timer accounting, analytics, account deletion and accessibility basics. Manual browser testing is still needed for the front end: the JavaScript was syntax-checked and smoke-tested with stubs but not driven in a real browser during development.

## Known limitations
- Running a multi-file project executes the open file only (no imports between project files).
- Exercises exist for Python and SQL only; HTML/JS/C/C++ are not auto-graded.
- Reminders appear when you open the app; there are no background notifications.
- Changing your password does not sign out other devices (sessions are cookie-based).
- Days and weeks use the browser's time zone via a cookie.

## Future improvements
Container-based execution service, project-wide imports, more exercises and languages, shared snippets, email reminders.

---

## Study Studio and Algorithm Visualizer (added in the final phase)

**New features**

- **Smart Notes** (`notes.py`): folders, tags, favorites, safe Markdown rendering (headings, lists, bold, code blocks), autosave with a Saved/Unsaved/Failed indicator, links to a task and a project, export to `.txt`/`.md`, and import of `.txt`, `.md`, `.pdf` and `.docx`. Imports show a progress bar, validate type, size (5 MB) and content, keep the original file privately in `instance/uploads/<user_id>/`, and let you review/edit the extracted text before a note is created. **Scanned PDFs have no text layer and OCR is not implemented**, so they cannot be imported.
- **Quiz Builder** (`quizzes.py`): multiple choice, true/false, identification and fill-in-the-blank; draft/publish, duplicate, reorder, link to notes, optional timer, one-question-at-a-time taking with a finish confirmation, server-side grading, results with explanations, retakes that never overwrite old attempts. Written answers that do not match the key are left for you to mark yourself. The answer key is never sent to the quiz-taking page.
- **Flashcard Studio** (`flashcards.py`): decks, cards (front/back/example/explanation), search, duplicate, rename, shuffled or sequential study sessions with a size limit, difficult/uncertain/easy ratings, missed cards repeat in the session, a due-today queue and a simple spaced-repetition scheduler (rules are shown on the deck page and documented in the module).
- **Generation from notes is template-based, not AI** (`studytext.py`): `Term: definition` lines, headings with a paragraph, and sentences with a keyword to blank out. Every draft is editable and must be approved before saving. The UI says so.
- **Algorithm Visualizer** (`algorithms.py`, `visualizer.py`): bubble (asc/desc), selection, insertion, linear and binary search. The server runs the real algorithm and records every step; the page only replays that trace (play, pause, next, previous, reset, speed) so counters are never made up.
- **Writing Assistant** (`writing.py`): *basic local checks* (spacing, repeated words, common misspellings, capitals, contractions, wordy phrases). It is **not** a full grammar checker. Code, links and identifiers are protected. You accept or reject each change, see a side-by-side diff, edit, copy and save. An optional AI engine is used only if `ANTHROPIC_API_KEY` is set on the server (`NEXUSLEARN_LLM_MODEL` overrides the model); failures fall back to the basic checks and never lose your text. The AI path is tested with a mocked service only, not against the live API.
- Search, Progress Center (quiz scores, missed questions, flashcards due, reviews per day, suggestions based only on real records) and the dashboard include the new data; the sidebar is grouped into Learn / Study Studio / Build / Track.

**Setup**: `pip install -r requirements.txt` (Flask, pypdf, python-docx), then `flask --app app run` or `python app.py` as before. Tests: `python -m unittest discover -s tests` (235 tests).

**Database**: new tables are created with `CREATE TABLE IF NOT EXISTS`; new `notes` columns (`folder`, `tags`, `favorite`, `task_id`, `project_id`) are added with `ALTER TABLE`, so existing databases keep all data and migration is repeatable (tested).

**Limitations (honest list)**: no OCR; quiz/flashcard generation is templates, not AI; the optional AI writing engine is untested against the live service; Learning Hub still grades Python and SQL only; Focus Mode cannot yet be started from a note, quiz or deck; CodeLab was not changed in this phase; no automated browser (Selenium) tests, so test the pages by hand before recording the demo.

**Demo checklist**: register; add a task; write a note with `Term: definition` lines; generate a quiz and edit a question; publish, take and finish it; check results and retake; generate flashcards, study the due queue and rate cards; open the Visualizer and step through bubble sort; check text in the Writing Assistant; import a `.docx`; search a word; open the Progress Center.
