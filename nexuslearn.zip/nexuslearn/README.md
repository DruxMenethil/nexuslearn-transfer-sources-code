# NexusLearn

Work in progress (Phase 5 of 9: Focus Mode). The full README is written in Phase 9.

## Run in CS50's VS Code (cs50.dev / Codespaces)
    cd nexuslearn
    pip install -r requirements.txt   # Flask is usually already installed
    flask run --debug
Open the "Open in Browser" popup or the forwarded port 5000.

## Run tests
    python -m unittest discover -s tests -v

## What CodeLab can run today
| Language | Status |
|---|---|
| Python | Real execution in a restricted child process (5 s, 512 MB, 256 KB output) |
| SQL | Private per-user SQLite practice database, reset button, 3 s limit |
| HTML + CSS | Live preview in a sandboxed iframe (no same-origin access) |
| JavaScript, C, C++ | **Not implemented yet** (Phase 8); disabled in the UI |

There is no Stop button: runs are short-lived (5 s) and stopping a server process
from the browser is not implemented.

## Security notes for the Python runner
Student code runs in a separate process (`sandbox_runner.py`) with an empty
environment, a temporary working directory, OS resource limits, and a Python
audit hook that blocks network access, subprocesses, ctypes, and any read or
write outside the sandbox (so the app database and secret key are unreachable).
This is a strong layer for a student project but not container-grade isolation.
Before exposing CodeLab to untrusted users on the internet, run the runner in a
container or a dedicated execution service.

## Projects and snippets (Phase 4)
- **My Projects:** create, edit/rename and delete projects; add, rename and delete files; link a project to an assignment (shown on the task page). Files open in CodeLab and are saved with the Save button or Ctrl/Cmd+S. CodeLab shows an unsaved-changes indicator and warns before leaving.
- **Save from CodeLab:** "Save as project" and "Save as snippet" work from the standalone editor.
- **Snippets:** private library with tags, search, language filter, Copy, and Open in CodeLab (Python, SQL and HTML only, since those are the languages CodeLab can run).
- Running a multi-file project executes the open file only; imports between project files are not supported yet.
- Every project, file and snippet lookup is scoped to the logged-in user; other users get a 404.

## Focus Mode (Phase 5)
- **Server-authoritative timer:** the database stores when a session was (re)started and how much time was used before. The browser countdown is only a display, so refreshing, closing the tab, or double-clicking cannot change what is recorded.
- **No duplicates:** a unique index allows at most one unfinished session per user, starting twice returns the existing session, and completion is a conditional UPDATE that succeeds once.
- **Controls:** start, pause, resume, finish early (after 1+ minute, records the time studied), reset (discards, records nothing), optional long break every N sessions (0 turns it off), subject, linked assignment and project.
- **What counts as study time:** completed focus sessions only. Breaks and reset sessions are not counted. A timer left running counts down on the server; if you return after it ran out it is recorded as completed, capped at the planned length.
- **Summaries:** today, this week (Monday start), all time, last 7 days, and this week by subject. Day and week boundaries use the browser's time zone (sent in a `tz_offset` cookie). In-app only: there are no background notifications when the app is closed.
- Databases created before Phase 5 are upgraded automatically (two new columns on `users`).
