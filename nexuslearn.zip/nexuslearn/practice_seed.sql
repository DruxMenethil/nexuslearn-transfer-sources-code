CREATE TABLE students (
    id    INTEGER PRIMARY KEY,
    name  TEXT NOT NULL,
    major TEXT NOT NULL,
    year  INTEGER NOT NULL,
    gpa   REAL
);
INSERT INTO students (id, name, major, year, gpa) VALUES
    (1, 'Ada Lovelace',  'Computer Science', 3, 3.9),
    (2, 'Alan Turing',   'Mathematics',      4, 3.8),
    (3, 'Grace Hopper',  'Computer Science', 2, 3.7),
    (4, 'Linus Torvalds','Information Tech', 1, 3.2),
    (5, 'Margaret Hamilton','Engineering',   4, 3.95),
    (6, 'Dennis Ritchie','Computer Science', 3, 3.5),
    (7, 'Radia Perlman', 'Information Tech', 2, 3.6),
    (8, 'Tim Berners-Lee','Physics',         3, 3.4);

CREATE TABLE courses (
    id      INTEGER PRIMARY KEY,
    code    TEXT NOT NULL UNIQUE,
    title   TEXT NOT NULL,
    credits INTEGER NOT NULL
);
INSERT INTO courses (id, code, title, credits) VALUES
    (1, 'CS50',  'Intro to Computer Science', 4),
    (2, 'DB101', 'Database Design',           3),
    (3, 'WEB201','Web Development',           3),
    (4, 'MATH110','Discrete Mathematics',     3),
    (5, 'NET220','Computer Networks',         3);

CREATE TABLE enrollments (
    student_id INTEGER NOT NULL REFERENCES students(id),
    course_id  INTEGER NOT NULL REFERENCES courses(id),
    grade      TEXT,
    PRIMARY KEY (student_id, course_id)
);
INSERT INTO enrollments (student_id, course_id, grade) VALUES
    (1,1,'A'),(1,2,'A'),(2,4,'A'),(2,1,'B'),(3,1,'A'),(3,3,'B'),(4,1,'C'),
    (4,5,'B'),(5,2,'A'),(5,4,'A'),(6,1,'B'),(6,5,'B'),(7,3,'A'),(7,5,'A'),(8,3,'B');
