"""CodeLab (Phase 3): sandboxed Python runner and isolated SQL practice database.

HTML/CSS preview runs entirely in the browser inside a sandboxed iframe
(see static/js/codelab.js), so it has no server route.
JavaScript, C and C++ are NOT implemented yet (Phase 8) and are not offered.
"""
import os
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time

from flask import Blueprint, current_app, jsonify, render_template, request, session, url_for

from helpers import get_db, login_required
from projects import get_owned_project
from snippets import OPENABLE, get_owned_snippet

bp = Blueprint("codelab", __name__)

PY_TIMEOUT = 5          # wall-clock seconds for a Python run
SQL_TIMEOUT = 3         # seconds for one SQL script
MAX_CODE = 50_000
MAX_STDIN = 10_000
MAX_OUTPUT = 20_000     # characters returned to the browser
FILE_LIMIT = 256 * 1024 # must match FILE_BYTES in sandbox_runner.py
MAX_ROWS = 200
MAX_STATEMENTS = 20

RUNNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sandbox_runner.py")
PROJECT_DIR = os.path.dirname(RUNNER)
slots = threading.BoundedSemaphore(3)  # at most 3 student programs at once


@bp.route("/codelab")
@login_required
def codelab():
    db = get_db()
    row = db.execute("SELECT default_language FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    lang = row["default_language"] if row and row["default_language"] in ("python", "sql", "html") else "python"
    boot = {"default_lang": lang, "project": None, "snippet": None,
            "urls": {"python": url_for("codelab.run_python_route"), "sql": url_for("codelab.run_sql_route"),
                     "resetSql": url_for("codelab.reset_sql_route"),
                     "saveProject": url_for("projects.from_codelab"),
                     "saveSnippet": url_for("snippets.from_codelab")}}

    project_id = request.args.get("project", type=int)
    if project_id is not None:
        project = get_owned_project(db, project_id)  # 404 unless it is yours
        files = db.execute("SELECT id, filename, content FROM project_files WHERE project_id = ? ORDER BY filename",
                           (project_id,)).fetchall()
        open_id = request.args.get("file", type=int)
        boot["project"] = {
            "id": project["id"], "name": project["name"], "language": project["language"],
            "url": url_for("projects.project_detail", project_id=project_id),
            "open": next((f["filename"] for f in files if f["id"] == open_id), None),
            "files": [{"id": f["id"], "filename": f["filename"], "content": f["content"],
                       "save_url": url_for("projects.save_file", project_id=project_id, file_id=f["id"])}
                      for f in files]}

    snippet_id = request.args.get("snippet", type=int)
    if snippet_id is not None and project_id is None:
        snippet = get_owned_snippet(db, snippet_id)
        if snippet["language"] in OPENABLE:
            boot["snippet"] = {"title": snippet["title"], "language": snippet["language"], "code": snippet["code"]}
    return render_template("codelab.html", boot=boot)


# ---------------------------------------------------------------- Python ----
def read_capped(path):
    with open(path, "rb") as f:
        data = f.read(MAX_OUTPUT + 1)
    return data[:MAX_OUTPUT].decode("utf-8", errors="replace"), len(data) > MAX_OUTPUT


def run_python(code, stdin_text):
    sandbox = tempfile.mkdtemp(prefix="nexuslearn_run_")
    try:
        with open(os.path.join(sandbox, "main.py"), "w", encoding="utf-8") as f:
            f.write(code)
        with open(os.path.join(sandbox, "stdin.txt"), "w", encoding="utf-8") as f:
            f.write(stdin_text)
        out_path, err_path = os.path.join(sandbox, "stdout.txt"), os.path.join(sandbox, "stderr.txt")
        env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}  # nothing secret is passed on

        start = time.monotonic()
        timed_out = False
        with open(os.path.join(sandbox, "stdin.txt"), "rb") as fin, \
                open(out_path, "wb") as fout, open(err_path, "wb") as ferr:
            proc = subprocess.Popen(
                [sys.executable, "-I", "-B", "-u", "-X", "utf8", RUNNER, sandbox, "main.py", PROJECT_DIR],
                stdin=fin, stdout=fout, stderr=ferr, cwd=sandbox, env=env,
                start_new_session=True, close_fds=True)
            try:
                proc.wait(timeout=PY_TIMEOUT)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
        elapsed = int((time.monotonic() - start) * 1000)

        stdout, cut_out = read_capped(out_path)
        stderr, cut_err = read_capped(err_path)
        rc = proc.returncode
        if timed_out or rc == -signal.SIGXCPU:
            status = "timeout"
        elif os.path.getsize(out_path) >= FILE_LIMIT:
            status = "output_limit"
        elif rc == 0:
            status = "ok"
        else:
            status = "error"
        return {"status": status, "exit_code": rc, "stdout": stdout, "stderr": stderr,
                "truncated": cut_out or cut_err, "duration_ms": elapsed, "timeout_s": PY_TIMEOUT}
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)


@bp.route("/codelab/run/python", methods=["POST"])
@login_required
def run_python_route():
    code = request.form.get("code", "")
    stdin_text = request.form.get("stdin", "")
    if not code.strip():
        return jsonify(error="Write some code first."), 400
    if len(code) > MAX_CODE or len(stdin_text) > MAX_STDIN:
        return jsonify(error=f"Code is limited to {MAX_CODE} characters and input to {MAX_STDIN}."), 400
    if not slots.acquire(blocking=False):
        return jsonify(status="busy", error="The runner is busy. Try again in a moment."), 429
    try:
        return jsonify(run_python(code, stdin_text))
    except OSError:
        return jsonify(status="unavailable", error="Python execution is unavailable on this server."), 503
    finally:
        slots.release()


# ------------------------------------------------------------------- SQL ----
SAFE_PRAGMAS = {"table_info", "table_xinfo", "table_list", "index_list", "index_info", "foreign_key_list"}
VACUUM_RE = re.compile(r"^(?:\s|--[^\n]*\n|/\*.*?\*/)*vacuum\b", re.IGNORECASE | re.DOTALL)


def authorizer(action, arg1, arg2, dbname, source):
    if action in (sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH):
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_PRAGMA and (arg1 or "").lower() not in SAFE_PRAGMAS:
        return sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_FUNCTION and (arg2 or "").lower() == "load_extension":
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


def practice_path(uid):
    folder = current_app.config["PRACTICE_DIR"]
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, f"user_{int(uid)}.db")


def create_practice_db(path):
    """Build a fresh sample database (written to a temp name, then moved into place)."""
    tmp = path + ".tmp"
    if os.path.exists(tmp):
        os.remove(tmp)
    conn = sqlite3.connect(tmp)
    try:
        with open(os.path.join(current_app.root_path, "practice_seed.sql"), encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.commit()
    finally:
        conn.close()
    os.replace(tmp, path)


def split_statements(sql):
    statements, start = [], 0
    for i, ch in enumerate(sql):
        if ch == ";" and sqlite3.complete_statement(sql[start:i + 1]):
            statements.append(sql[start:i + 1])
            start = i + 1
    if sql[start:].strip():
        statements.append(sql[start:])
    return [s.strip() for s in statements if s.strip() not in ("", ";")]


def friendly_sql_error(exc):
    msg = str(exc)
    low = msg.lower()
    if "not authorized" in low:
        return "That operation is not allowed in the practice database."
    if "interrupted" in low:
        return f"The script took longer than {SQL_TIMEOUT} seconds and was stopped."
    if "database or disk is full" in low:
        return "The practice database reached its size limit."
    if "locked" in low:
        return "The practice database is busy. Try again."
    return msg


def cell(value):
    return f"<{len(value)} bytes>" if isinstance(value, bytes) else value


def run_sql(uid, sql):
    statements = split_statements(sql)
    if not statements:
        return {"status": "error", "error": "Write a query first."}
    if len(statements) > MAX_STATEMENTS:
        return {"status": "error", "error": f"At most {MAX_STATEMENTS} statements per run."}

    path = practice_path(uid)
    if not os.path.exists(path):
        create_practice_db(path)

    conn = sqlite3.connect(path, timeout=2, isolation_level=None)
    started = time.monotonic()
    current = 0
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA max_page_count = 2560")  # ~10 MB cap, set before the authorizer
        conn.set_authorizer(authorizer)
        deadline = started + SQL_TIMEOUT
        conn.set_progress_handler(lambda: 1 if time.monotonic() > deadline else 0, 10_000)
        cur = conn.cursor()
        cur.execute("BEGIN")  # one transaction: a failing script changes nothing
        results = []
        for current, stmt in enumerate(statements, 1):
            if VACUUM_RE.match(stmt):
                raise sqlite3.DatabaseError("not authorized: VACUUM is disabled")
            cur.execute(stmt)
            item = {"statement": current, "sql": stmt[:100]}
            if cur.description:
                rows = cur.fetchmany(MAX_ROWS + 1)
                item.update(columns=[d[0] for d in cur.description],
                            rows=[[cell(v) for v in r] for r in rows[:MAX_ROWS]],
                            truncated=len(rows) > MAX_ROWS)
            else:
                item["rowcount"] = cur.rowcount if cur.rowcount >= 0 else None
            results.append(item)
        if conn.in_transaction:
            cur.execute("COMMIT")
        return {"status": "ok", "results": results,
                "duration_ms": int((time.monotonic() - started) * 1000)}
    except sqlite3.Error as exc:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        return {"status": "error", "error": friendly_sql_error(exc), "failed_statement": current,
                "duration_ms": int((time.monotonic() - started) * 1000)}
    finally:
        conn.close()


@bp.route("/codelab/run/sql", methods=["POST"])
@login_required
def run_sql_route():
    sql = request.form.get("code", "")
    if len(sql) > MAX_CODE:
        return jsonify(status="error", error=f"SQL is limited to {MAX_CODE} characters."), 400
    return jsonify(run_sql(session["user_id"], sql))


@bp.route("/codelab/sql/reset", methods=["POST"])
@login_required
def reset_sql_route():
    path = practice_path(session["user_id"])
    create_practice_db(path)
    return jsonify(status="ok", message="Practice database restored to its sample data.")
