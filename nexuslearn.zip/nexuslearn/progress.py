"""Progress Center (Phase 7): analytics computed ONLY from saved records.

Definitions (also shown on the page):
  * Completion rate     = completed tasks / all tasks (all time). Not shown with no tasks.
  * Study time          = completed focus sessions (see focus.py). Breaks are excluded.
  * Exercise pass rate  = passing attempts / attempts in the period.
  * Days follow the browser's time zone. Comparisons only use the previous period of the
    same length and are never described as "improvement": a difference is not proof of progress.
"""
import json
from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, session

import focus
import learn
from helpers import get_db, local_dt, local_today, login_required, tz_offset_minutes

bp = Blueprint("progress", __name__)
PERIODS = (7, 30, 90)


def period_bounds(now, offset, days):
    start_utc, start_local = focus.day_start(now, offset, days - 1)
    end_utc = focus.day_start(now, offset, 0)[0] + timedelta(days=1)
    return start_utc, end_utc, [start_local + timedelta(days=i) for i in range(days)]


def per_day(rows, labels, offset, weight=lambda row: 1):
    """Bucket rows (first column = UTC timestamp text) into the student's local days."""
    index = {d.date(): i for i, d in enumerate(labels)}
    totals = [0] * len(labels)
    for row in rows:
        local = datetime.strptime(row[0], focus.FMT) - timedelta(minutes=offset)
        if local.date() in index:
            totals[index[local.date()]] += weight(row)
    return totals


def compare_text(current, previous, days):
    if previous == 0:
        return "There is no study time in the previous period to compare with."
    change = round(100 * (current - previous) / previous)
    if change == 0:
        return f"About the same as the previous {days} days."
    return f"{abs(change)}% {'more' if change > 0 else 'less'} study time than the previous {days} days."


@bp.route("/progress")
@login_required
def progress_page():
    db, uid, now, offset = get_db(), session["user_id"], focus.clock(), tz_offset_minutes()
    days = int(request.args.get("days", "30")) if request.args.get("days") in {"7", "30", "90"} else 30
    start, end, labels = period_bounds(now, offset, days)
    s, e = focus.dt_str(start), focus.dt_str(end)
    prev_s = focus.dt_str(start - timedelta(days=days))

    # ---- tasks ----
    t = db.execute("""SELECT COUNT(*) AS total, COALESCE(SUM(status = 'pending'), 0) AS pending,
                             COALESCE(SUM(status = 'completed'), 0) AS completed,
                             COALESCE(SUM(status = 'pending' AND due_date < date('now')), 0) AS overdue
                      FROM tasks WHERE user_id = ?""", (uid,)).fetchone()
    done_rows = db.execute("SELECT completed_at FROM tasks WHERE user_id = ? AND completed_at >= ? AND completed_at < ?",
                           (uid, s, e)).fetchall()
    created_in_period = db.execute("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND created_at >= ? AND created_at < ?",
                                   (uid, s, e)).fetchone()[0]
    tasks = {"total": t["total"], "pending": t["pending"], "completed": t["completed"], "overdue": t["overdue"],
             "rate": round(100 * t["completed"] / t["total"]) if t["total"] else None,
             "completed_in_period": len(done_rows), "created_in_period": created_in_period}

    # ---- study time ----
    focus_rows = db.execute("""SELECT ended_at, duration_seconds FROM focus_sessions
                               WHERE user_id = ? AND kind = 'focus' AND status = 'completed'
                                 AND ended_at >= ? AND ended_at < ?""", (uid, s, e)).fetchall()
    study_by_day = per_day(focus_rows, labels, offset, weight=lambda r: r[1])
    study_total = sum(study_by_day)
    previous_total = focus.focus_seconds(db, uid, start - timedelta(days=days), start)[0]
    active_days = sum(1 for x in study_by_day if x > 0)
    study = {"total": study_total, "sessions": len(focus_rows), "active_days": active_days,
             "avg_active_day": round(study_total / active_days) if active_days else 0,
             "comparison": compare_text(study_total, previous_total, days), "few_days": 0 < active_days < 3}

    # ---- exercises ----
    attempts = db.execute("""SELECT a.created_at, a.passed, e.language FROM exercise_attempts a
                             JOIN exercises e ON e.id = a.exercise_id
                             WHERE a.user_id = ? AND a.created_at >= ? AND a.created_at < ?""", (uid, s, e)).fetchall()
    passed_n = sum(r["passed"] for r in attempts)
    first_pass = db.execute("""SELECT COUNT(*) FROM (SELECT exercise_id, MIN(created_at) AS first FROM exercise_attempts
                               WHERE user_id = ? AND passed = 1 GROUP BY exercise_id) WHERE first >= ? AND first < ?""",
                            (uid, s, e)).fetchone()[0]
    overall = db.execute(learn.EXERCISE_LIST_SQL.format(where="1 = 1"), {"uid": uid}).fetchall()
    exercises = {"attempts": len(attempts), "passed_attempts": passed_n,
                 "attempted": db.execute(
                     "SELECT COUNT(DISTINCT exercise_id) FROM exercise_attempts "
                     "WHERE user_id = ? AND created_at >= ? AND created_at < ?", (uid, s, e)).fetchone()[0],
                 "completed_in_period": first_pass,
                 "pass_rate": round(100 * passed_n / len(attempts)) if attempts else None,
                 "total": len(overall), "completed_total": sum(1 for r in overall if r["completed_at"]),
                 "by_language": {lang: (sum(1 for r in overall if r["language"] == lang and r["completed_at"]),
                                        sum(1 for r in overall if r["language"] == lang)) for lang in ("python", "sql")}}

    # ---- projects ----
    projects = {"created": db.execute("SELECT COUNT(*) FROM projects WHERE user_id = ? AND created_at >= ? AND created_at < ?",
                                      (uid, s, e)).fetchone()[0],
                "updated": db.execute("SELECT COUNT(*) FROM projects WHERE user_id = ? AND updated_at >= ? AND updated_at < ?",
                                      (uid, s, e)).fetchone()[0],
                "total": db.execute("SELECT COUNT(*) FROM projects WHERE user_id = ?", (uid,)).fetchone()[0],
                "recent": db.execute("SELECT id, name, language, updated_at FROM projects WHERE user_id = ? "
                                     "ORDER BY updated_at DESC, id DESC LIMIT 5", (uid,)).fetchall()}

    recent_sessions = [{**dict(r), "when": local_dt(r["ended_at"], offset)} for r in db.execute(
        """SELECT f.duration_seconds, f.finished_early, f.ended_at, s.name AS subject FROM focus_sessions f
           LEFT JOIN subjects s ON s.id = f.subject_id
           WHERE f.user_id = ? AND f.kind = 'focus' AND f.status = 'completed'
           ORDER BY f.ended_at DESC, f.id DESC LIMIT 8""", (uid,))]

    # ---- quizzes (submitted attempts only; score counts graded or self-marked answers) ----
    qa = db.execute("""SELECT a.id, a.finished_at, a.score, a.total, z.title FROM quiz_attempts a JOIN quizzes z ON z.id = a.quiz_id
                       WHERE a.user_id = ? AND a.status = 'submitted' AND a.finished_at >= ? AND a.finished_at < ?
                       ORDER BY a.finished_at DESC, a.id DESC""", (uid, s, e)).fetchall()
    scored = [r for r in qa if r["total"]]
    quizzes = {"attempts": len(qa), "history": [{**dict(r), "pct": round(100 * r["score"] / r["total"]), "when": local_dt(r["finished_at"], offset)}
                                                    for r in scored[:8]],
               "average": round(sum(100 * r["score"] / r["total"] for r in scored) / len(scored)) if scored else None,
               "pending_review": db.execute("""SELECT COUNT(*) FROM quiz_responses r JOIN quiz_attempts a ON a.id = r.attempt_id
                                               WHERE a.user_id = ? AND r.is_correct IS NULL""", (uid,)).fetchone()[0],
               "missed": db.execute("""SELECT r.prompt, r.answer_key, z.title, COUNT(*) AS times, MAX(a.finished_at) AS last
                                       FROM quiz_responses r JOIN quiz_attempts a ON a.id = r.attempt_id JOIN quizzes z ON z.id = a.quiz_id
                                       WHERE a.user_id = ? AND r.is_correct = 0 AND a.finished_at >= ? AND a.finished_at < ?
                                       GROUP BY r.prompt, r.answer_key, z.title ORDER BY times DESC, last DESC LIMIT 8""", (uid, s, e)).fetchall(),
               "weak_topics": db.execute("""SELECT z.topic, SUM(r.is_correct = 0) AS wrong, COUNT(*) AS answered
                                            FROM quiz_responses r JOIN quiz_attempts a ON a.id = r.attempt_id JOIN quizzes z ON z.id = a.quiz_id
                                            WHERE a.user_id = ? AND z.topic != '' AND r.is_correct IS NOT NULL AND a.finished_at >= ? AND a.finished_at < ?
                                            GROUP BY z.topic HAVING answered >= 5 AND wrong * 2 >= answered ORDER BY wrong DESC LIMIT 5""",
                                         (uid, s, e)).fetchall()}

    # ---- flashcards ----
    today = local_today(offset)
    rv = db.execute("SELECT reviewed_at, rating FROM card_reviews WHERE user_id = ? AND reviewed_at >= ? AND reviewed_at < ?", (uid, s, e)).fetchall()
    cards = {"reviews": len(rv), "by_rating": {k: sum(1 for r in rv if r["rating"] == k) for k in ("difficult", "uncertain", "easy")},
             "total": db.execute("SELECT COUNT(*) FROM cards c JOIN decks d ON d.id = c.deck_id WHERE d.user_id = ?", (uid,)).fetchone()[0],
             "due": db.execute("SELECT COUNT(*) FROM cards c JOIN decks d ON d.id = c.deck_id WHERE d.user_id = ? AND c.due_date <= ?",
                               (uid, today)).fetchone()[0],
             "decks": db.execute("SELECT COUNT(*) FROM decks WHERE user_id = ?", (uid,)).fetchone()[0]}

    # ---- upcoming deadlines and suggestions: derived only from the records above ----
    upcoming = db.execute("""SELECT id, title, due_date FROM tasks WHERE user_id = ? AND status = 'pending' AND due_date IS NOT NULL
                             AND due_date <= date(?, '+7 days') ORDER BY due_date LIMIT 5""", (uid, today)).fetchall()
    suggestions = []
    for t_ in upcoming:
        late = t_["due_date"] < today
        suggestions.append({"text": f"{'Overdue' if late else 'Due ' + t_['due_date']}: {t_['title']}", "kind": "deadline",
                            "url": f"/tasks/{t_['id']}"})
    if cards["due"]:
        suggestions.append({"text": f"Review {min(cards['due'], 10)} of your {cards['due']} flashcards due today", "kind": "cards", "url": "/study/review"})
    for r in db.execute("""SELECT z.id, z.title, a.score * 100 / a.total AS pct FROM quiz_attempts a JOIN quizzes z ON z.id = a.quiz_id
                           WHERE a.user_id = ? AND a.status = 'submitted' AND a.total > 0 AND a.id = (SELECT MAX(id) FROM quiz_attempts
                             WHERE quiz_id = z.id AND user_id = a.user_id AND status = 'submitted') AND a.score * 100 / a.total < 60
                           ORDER BY a.finished_at DESC LIMIT 2""", (uid,)):
        suggestions.append({"text": f"Retake “{r['title']}” (last score {r['pct']}%)", "kind": "quiz", "url": f"/study/quizzes/{r['id']}/take"})
    for r in db.execute("""SELECT z.id, z.title FROM quizzes z WHERE z.user_id = ? AND z.status = 'published'
                           AND NOT EXISTS (SELECT 1 FROM quiz_attempts a WHERE a.quiz_id = z.id AND a.status = 'submitted') LIMIT 2""", (uid,)):
        suggestions.append({"text": f"Try your quiz “{r['title']}” (never attempted)", "kind": "quiz", "url": f"/study/quizzes/{r['id']}/take"})
    suggestions = suggestions[:6]

    chart = {"labels": [d.strftime("%b %d") for d in labels],
             "study_minutes": [round(x / 60, 1) for x in study_by_day],
             "tasks_completed": per_day(done_rows, labels, offset),
             "attempts_passed": per_day([r for r in attempts if r["passed"]], labels, offset),
             "attempts_failed": per_day([r for r in attempts if not r["passed"]], labels, offset),
             "cards_reviewed": per_day(rv, labels, offset)}
    return render_template("progress.html", days=days, periods=PERIODS, tasks=tasks, study=study, exercises=exercises,
                           projects=projects, recent_sessions=recent_sessions, chart=chart,
                           quizzes=quizzes, cards=cards, upcoming=upcoming, suggestions=suggestions,
                           has_any_activity=bool(t["total"] or study_total or attempts or projects["total"] or qa or cards["total"]))
