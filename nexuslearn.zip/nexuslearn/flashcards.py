"""Flashcard Studio with a simple spaced-repetition scheduler.

Scheduling rules (also shown to the student), applied only when a card is reviewed:
  difficult : back to the start, due tomorrow, ease -0.20 (min 1.3), lapse count +1
  uncertain : interval grows slowly (x1.2, at least +1 day), ease -0.05 (min 1.3)
  easy      : first success 3 days, second 6 days, then interval x ease x 1.3; ease +0.10 (max 3.0)
Saved cards are never regenerated or reshuffled in the database; shuffling only affects one session.
"""
import json
import random
import sqlite3
from datetime import date, timedelta

from flask import (Blueprint, abort, flash, jsonify, redirect, render_template, request,
                   session, url_for)

import studytext
from helpers import get_db, like, local_today, login_required, owned_or_404

bp = Blueprint("flashcards", __name__)
RATINGS = ("difficult", "uncertain", "easy")
MAX_SESSION = 100


def schedule(interval, ease, repetitions, lapses, rating, today):
    """Pure function: -> dict of the new scheduling state. `today` is an ISO date string."""
    base = date.fromisoformat(today)
    if rating == "difficult":
        interval, ease, repetitions, lapses = 1, max(1.3, ease - 0.2), 0, lapses + 1
    elif rating == "uncertain":
        interval = 1 if repetitions == 0 else max(interval + 1, round(interval * 1.2))
        ease, repetitions = max(1.3, ease - 0.05), repetitions + 1
    elif rating == "easy":
        interval = 3 if repetitions == 0 else 6 if repetitions == 1 else max(interval + 1, round(interval * ease * 1.3))
        ease, repetitions = min(3.0, ease + 0.1), repetitions + 1
    else:
        raise ValueError("unknown rating")
    return {"interval_days": interval, "ease": round(ease, 2), "repetitions": repetitions, "lapses": lapses,
            "due_date": (base + timedelta(days=interval)).isoformat()}


def get_deck(db, deck_id):
    return owned_or_404(db, "decks", deck_id)


def get_card(db, card_id):
    card = db.execute("""SELECT c.* FROM cards c JOIN decks d ON d.id = c.deck_id
                         WHERE c.id = ? AND d.user_id = ?""", (card_id, session["user_id"])).fetchone()
    if card is None:
        abort(404)
    return card


def validate_card(form):
    v = {k: form.get(k, "").strip() for k in ("front", "back", "example", "explanation")}
    errors = []
    if not v["front"] or len(v["front"]) > 500:
        errors.append("The front is required (500 characters or fewer).")
    if not v["back"] or len(v["back"]) > 1000:
        errors.append("The back is required (1000 characters or fewer).")
    v["example"], v["explanation"] = v["example"][:500], v["explanation"][:500]
    return v, errors


def validate_deck(form):
    v = {"name": " ".join(form.get("name", "").split()), "subject": " ".join(form.get("subject", "").split())[:60],
         "topic": " ".join(form.get("topic", "").split())[:60], "description": form.get("description", "").strip()[:300]}
    errors = [] if 1 <= len(v["name"]) <= 80 else ["The deck name is required (80 characters or fewer)."]
    return v, errors


def add_card(db, deck_id, v):
    db.execute("INSERT INTO cards (deck_id, front, back, example, explanation, due_date) VALUES (?, ?, ?, ?, ?, ?)",
               (deck_id, v["front"], v["back"], v.get("example", ""), v.get("explanation", ""), local_today()))


DECK_SQL = """SELECT d.*, (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id) AS n_cards,
                     (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.due_date <= :today) AS n_due,
                     (SELECT COUNT(*) FROM cards c WHERE c.deck_id = d.id AND c.last_reviewed IS NOT NULL) AS n_reviewed
              FROM decks d WHERE d.user_id = :uid {extra} ORDER BY d.updated_at DESC, d.id DESC"""


@bp.route("/study/flashcards")
@login_required
def list_decks():
    db, uid = get_db(), session["user_id"]
    q = request.args.get("q", "").strip()
    extra, params = "", {"uid": uid, "today": local_today()}
    if q:   # deck fields or any card text
        extra = """AND (d.name LIKE :q ESCAPE '\\' OR d.subject LIKE :q ESCAPE '\\' OR d.topic LIKE :q ESCAPE '\\'
                   OR EXISTS (SELECT 1 FROM cards c WHERE c.deck_id = d.id AND (c.front LIKE :q ESCAPE '\\' OR c.back LIKE :q ESCAPE '\\')))"""
        params["q"] = like(q)
    decks = db.execute(DECK_SQL.format(extra=extra), params).fetchall()
    due_total = db.execute("""SELECT COUNT(*) FROM cards c JOIN decks d ON d.id = c.deck_id
                              WHERE d.user_id = ? AND c.due_date <= ?""", (uid, params["today"])).fetchone()[0]
    all_decks = db.execute("SELECT COUNT(*) FROM decks WHERE user_id = ?", (uid,)).fetchone()[0]
    return render_template("decks.html", decks=decks, q=q, due_total=due_total, total=all_decks)


@bp.route("/study/flashcards/new", methods=["GET", "POST"])
@login_required
def new_deck():
    db = get_db()
    values, errors = {}, []
    if request.method == "POST":
        values, errors = validate_deck(request.form)
        if not errors:
            try:
                cur = db.execute("INSERT INTO decks (user_id, name, subject, topic, description) VALUES (?, ?, ?, ?, ?)",
                                 (session["user_id"], values["name"], values["subject"], values["topic"], values["description"]))
                db.commit()
                flash("Deck created. Add your first cards.", "success")
                return redirect(url_for("flashcards.view_deck", deck_id=cur.lastrowid))
            except sqlite3.IntegrityError:
                errors = ["You already have a deck with that name."]
    return render_template("deck_form.html", deck=None, values=values, errors=errors)


@bp.route("/study/flashcards/<int:deck_id>")
@login_required
def view_deck(deck_id):
    db, uid = get_db(), session["user_id"]
    deck = get_deck(db, deck_id)
    q = request.args.get("q", "").strip()
    where, params = ["deck_id = ?"], [deck_id]
    if q:
        where.append("(front LIKE ? ESCAPE '\\' OR back LIKE ? ESCAPE '\\')"); params += [like(q)] * 2
    cards = db.execute(f"SELECT * FROM cards WHERE {' AND '.join(where)} ORDER BY id", params).fetchall()
    stats = db.execute(DECK_SQL.format(extra="AND d.id = :id"), {"uid": uid, "today": local_today(), "id": deck_id}).fetchone()
    reviews = db.execute("""SELECT r.rating, r.reviewed_at, r.interval_after, c.front FROM card_reviews r JOIN cards c ON c.id = r.card_id
                            WHERE c.deck_id = ? AND r.user_id = ? ORDER BY r.id DESC LIMIT 10""", (deck_id, uid)).fetchall()
    total_reviews = db.execute("""SELECT COUNT(*) FROM card_reviews r JOIN cards c ON c.id = r.card_id WHERE c.deck_id = ?""",
                               (deck_id,)).fetchone()[0]
    return render_template("deck.html", deck=deck, cards=cards, q=q, stats=stats, reviews=reviews, total_reviews=total_reviews,
                           today=local_today())


@bp.route("/study/flashcards/<int:deck_id>/edit", methods=["GET", "POST"])
@login_required
def edit_deck(deck_id):
    db = get_db()
    deck = get_deck(db, deck_id)
    values, errors = dict(deck), []
    if request.method == "POST":
        values, errors = validate_deck(request.form)
        if not errors:
            try:
                db.execute("""UPDATE decks SET name = ?, subject = ?, topic = ?, description = ?, updated_at = CURRENT_TIMESTAMP
                              WHERE id = ? AND user_id = ?""",
                           (values["name"], values["subject"], values["topic"], values["description"], deck_id, session["user_id"]))
                db.commit()
                flash("Deck saved.", "success")
                return redirect(url_for("flashcards.view_deck", deck_id=deck_id))
            except sqlite3.IntegrityError:
                errors = ["You already have a deck with that name."]
    return render_template("deck_form.html", deck=deck, values=values, errors=errors)


@bp.route("/study/flashcards/<int:deck_id>/delete", methods=["POST"])
@login_required
def delete_deck(deck_id):
    db = get_db()
    get_deck(db, deck_id)
    db.execute("DELETE FROM decks WHERE id = ? AND user_id = ?", (deck_id, session["user_id"]))
    db.commit()
    flash("Deck deleted with its cards and review history.", "info")
    return redirect(url_for("flashcards.list_decks"))


@bp.route("/study/flashcards/<int:deck_id>/duplicate", methods=["POST"])
@login_required
def duplicate_deck(deck_id):
    db, uid = get_db(), session["user_id"]
    deck = get_deck(db, deck_id)
    name, n = deck["name"][:70] + " (copy)", 1
    while db.execute("SELECT 1 FROM decks WHERE user_id = ? AND name = ?", (uid, name)).fetchone():
        n += 1
        name = f"{deck['name'][:66]} (copy {n})"
    cur = db.execute("INSERT INTO decks (user_id, name, subject, topic, description) VALUES (?, ?, ?, ?, ?)",
                     (uid, name, deck["subject"], deck["topic"], deck["description"]))
    # The copy starts with fresh scheduling: review history belongs to the original cards.
    db.execute("""INSERT INTO cards (deck_id, front, back, example, explanation, due_date)
                  SELECT ?, front, back, example, explanation, ? FROM cards WHERE deck_id = ?""",
               (cur.lastrowid, local_today(), deck_id))
    db.commit()
    flash("Deck duplicated (the copy starts with fresh review scheduling).", "success")
    return redirect(url_for("flashcards.view_deck", deck_id=cur.lastrowid))


@bp.route("/study/flashcards/<int:deck_id>/cards", methods=["POST"])
@login_required
def create_card(deck_id):
    db = get_db()
    get_deck(db, deck_id)
    v, errors = validate_card(request.form)
    if errors:
        for e in errors:
            flash(e, "danger")
    else:
        add_card(db, deck_id, v)
        db.execute("UPDATE decks SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", (deck_id,))
        db.commit()
        flash("Card added.", "success")
    return redirect(url_for("flashcards.view_deck", deck_id=deck_id))


@bp.route("/study/cards/<int:card_id>/edit", methods=["GET", "POST"])
@login_required
def edit_card(card_id):
    db = get_db()
    card = get_card(db, card_id)
    values, errors = dict(card), []
    if request.method == "POST":
        values, errors = validate_card(request.form)
        if not errors:
            db.execute("""UPDATE cards SET front = ?, back = ?, example = ?, explanation = ?, updated_at = CURRENT_TIMESTAMP
                          WHERE id = ?""", (values["front"], values["back"], values["example"], values["explanation"], card_id))
            db.commit()
            flash("Card saved. Its review schedule is unchanged.", "success")
            return redirect(url_for("flashcards.view_deck", deck_id=card["deck_id"]))
    return render_template("card_form.html", card=card, values=values, errors=errors)


@bp.route("/study/cards/<int:card_id>/delete", methods=["POST"])
@login_required
def delete_card(card_id):
    db = get_db()
    card = get_card(db, card_id)
    db.execute("DELETE FROM cards WHERE id = ?", (card_id,))
    db.commit()
    flash("Card deleted.", "info")
    return redirect(url_for("flashcards.view_deck", deck_id=card["deck_id"]))


# ------------------------------------------------------------ generation ----
def draft_cards(text, limit=40):
    """Template-based card drafts (no AI): 'Term: definition' lines and heading + paragraph."""
    cards = [{"front": t, "back": d, "example": "", "explanation": ""} for t, d in studytext.extract_pairs(text)]
    have = {c["front"].lower() for c in cards}
    for heading, body in studytext.extract_sections(text):
        if heading.lower() not in have:
            cards.append({"front": heading, "back": body, "example": "", "explanation": ""})
    return cards[:limit]


@bp.route("/study/flashcards/generate", methods=["GET", "POST"])
@login_required
def generate():
    db, uid = get_db(), session["user_id"]
    notes = db.execute("SELECT id, title FROM notes WHERE user_id = ? ORDER BY updated_at DESC", (uid,)).fetchall()
    decks = db.execute("SELECT id, name FROM decks WHERE user_id = ? ORDER BY name", (uid,)).fetchall()
    if request.method == "POST":
        ids = [int(x) for x in request.form.getlist("note_ids") if x.isdigit()]
        rows = db.execute(f"SELECT id, body FROM notes WHERE user_id = ? AND id IN ({','.join('?' * len(ids))})", [uid, *ids]).fetchall() if ids else []
        text = ("\n\n".join(r["body"] for r in rows) + "\n\n" + request.form.get("text", "")).strip()[:40_000]
        if not text:
            flash("Choose a note or paste some text first.", "danger")
        else:
            drafts = draft_cards(text)
            return render_template("card_review.html", drafts=drafts, note_ids=[r["id"] for r in rows], decks=decks,
                                   deck_name=request.form.get("deck_name", "").strip())
    return render_template("card_generate.html", notes=notes, selected=request.args.get("note_id", ""))


@bp.route("/study/flashcards/generate/save", methods=["POST"])
@login_required
def save_generated():
    db, uid = get_db(), session["user_id"]
    name = " ".join(request.form.get("deck_name", "").split())[:80]
    if not name:
        flash("Give the deck a name.", "danger")
        return redirect(url_for("flashcards.generate"))
    kept, problems = [], []
    n = int(request.form.get("n", "0")) if request.form.get("n", "0").isdigit() else 0
    for i in range(n):
        if request.form.get(f"keep-{i}"):
            v, errs = validate_card({k: request.form.get(f"{k}-{i}", "") for k in ("front", "back", "example", "explanation")})
            (problems.append(f"Card {i + 1}: {' '.join(errs)}") if errs else kept.append(v))
    if problems or not kept:
        for p in problems or ["Keep at least one card."]:
            flash(p, "danger")
        return redirect(url_for("flashcards.generate"))
    deck = db.execute("SELECT id FROM decks WHERE user_id = ? AND name = ?", (uid, name)).fetchone()
    deck_id = deck["id"] if deck else db.execute(
        "INSERT INTO decks (user_id, name, description) VALUES (?, ?, ?)",
        (uid, name, "Drafted from notes with templates (no AI). Reviewed by me.")).lastrowid
    for v in kept:
        add_card(db, deck_id, v)
    for nid in request.form.getlist("note_ids"):
        if nid.isdigit() and db.execute("SELECT 1 FROM notes WHERE id = ? AND user_id = ?", (nid, uid)).fetchone():
            db.execute("INSERT OR IGNORE INTO deck_notes (deck_id, note_id) VALUES (?, ?)", (deck_id, int(nid)))
    db.commit()
    flash(f"Saved {len(kept)} card{'' if len(kept) == 1 else 's'}.", "success")
    return redirect(url_for("flashcards.view_deck", deck_id=deck_id))


# ----------------------------------------------------------------- study ----
def build_session(db, deck_id, mode, order, limit):
    uid, today = session["user_id"], local_today()
    where, params = ["d.user_id = ?"], [uid]
    if deck_id:
        where.append("c.deck_id = ?"); params.append(deck_id)
    if mode == "due":
        where.append("c.due_date <= ?"); params.append(today)
    rows = db.execute(f"""SELECT c.id, c.front, c.back, c.example, c.explanation, c.due_date FROM cards c
                          JOIN decks d ON d.id = c.deck_id WHERE {' AND '.join(where)} ORDER BY c.due_date, c.id""", params).fetchall()
    cards = [dict(r) for r in rows]
    if order == "shuffle":
        random.shuffle(cards)
    return cards[:limit]


def study_view(deck, deck_id):
    db = get_db()
    mode = "all" if request.args.get("mode") == "all" else "due"
    order = "shuffle" if request.args.get("order") == "shuffle" else "sequential"
    limit = request.args.get("limit", "10")
    limit = min(max(int(limit), 1), MAX_SESSION) if limit.isdigit() else 10
    cards = build_session(db, deck_id, mode, order, limit)
    return render_template("study.html", deck=deck, cards=cards, mode=mode, order=order, limit=limit)


@bp.route("/study/flashcards/<int:deck_id>/study")
@login_required
def study_deck(deck_id):
    return study_view(get_deck(get_db(), deck_id), deck_id)


@bp.route("/study/review")
@login_required
def daily_queue():
    """Cards due today across every deck (a small batch, default 10)."""
    return study_view(None, None)


@bp.route("/study/cards/<int:card_id>/review", methods=["POST"])
@login_required
def review_card(card_id):
    db, uid = get_db(), session["user_id"]
    card = get_card(db, card_id)
    rating = request.form.get("rating", "")
    if rating not in RATINGS:
        return jsonify(error="Choose difficult, uncertain or easy."), 400
    today = local_today()
    new = schedule(card["interval_days"], card["ease"], card["repetitions"], card["lapses"], rating, today)
    db.execute("""UPDATE cards SET interval_days = ?, ease = ?, repetitions = ?, lapses = ?, due_date = ?,
                  last_reviewed = CURRENT_TIMESTAMP WHERE id = ?""",
               (new["interval_days"], new["ease"], new["repetitions"], new["lapses"], new["due_date"], card_id))
    db.execute("""INSERT INTO card_reviews (card_id, user_id, rating, interval_before, interval_after, due_after)
                  VALUES (?, ?, ?, ?, ?, ?)""", (card_id, uid, rating, card["interval_days"], new["interval_days"], new["due_date"]))
    db.commit()
    return jsonify(ok=True, interval_days=new["interval_days"], due_date=new["due_date"])
